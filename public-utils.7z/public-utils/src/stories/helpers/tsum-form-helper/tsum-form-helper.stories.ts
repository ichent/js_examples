import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { storiesOf, moduleMetadata } from '@storybook/angular';
import { SbDescriptionWrapperModule, TsumCodeHighlighterModule, GlossaryModule, SbUtilsModule, ShortExampleModule } from '@tsum/storybook';
import { TsumTableModule } from '@tsum/ui';
import {
    TsumFormHelpersGlossary,
} from './tsum-form-helper.constant';
import { TsumHelpersGeneralTitle, StoryKind, StoryKindGroup, TsumHelpersFormTitle } from '../../story-kind.constant';
import { TsumFormHelperExampleModule } from './tsum-form-helper.module';

storiesOf(StoryKind[StoryKindGroup.Helpers].form, module)
    .addDecorator(
        moduleMetadata({
            imports: [
                CommonModule,
                HttpClientModule,
                GlossaryModule,
                SbDescriptionWrapperModule,
                SbUtilsModule,
                ShortExampleModule,
                TsumCodeHighlighterModule,
                TsumFormHelperExampleModule,
                TsumTableModule,
            ]
        }))
    .add(TsumHelpersGeneralTitle.Glossary, () => ({
        props: {
            TsumFormHelpersGlossary,
        },
        template: `
            <sb-description-wrapper hideAll>
                <div header-description>Глоссарий general хелперов</div>
                <app-glossary [items]="TsumFormHelpersGlossary" isWithoutGroup></app-glossary>
            </sb-description-wrapper>
        `,
    }))
    .add(TsumHelpersFormTitle.ControlValueObservable, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].general,
                title: TsumHelpersFormTitle.Glossary,
            },

            ts: 'tsum-control-value-observable-example.component.ts',
            html: require('./example/tsum-control-value-observable-example/tsum-control-value-observable-example.component.html'),
            module: 'tsum-form-helper.module.ts'
        },
        template: `
            <sb-description-wrapper
                hideAll
                [backUrl]="backUrl"
                backText="К списку general helpers"
            >
                <div>
                    <app-short-example title="Control value observable" [tsFileName]="ts" [html]="html" [moduleFileName]="module">
                        <tsum-control-value-observable-example></tsum-control-value-observable-example>
                    </app-short-example>
                </div>
            </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersFormTitle.ControlForEach, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].form,
                title: TsumHelpersFormTitle.Glossary,
            },
            ts: 'tsum-control-for-each-example.component.ts',
            html: require('./example/tsum-control-for-each-example/tsum-control-for-each-example.component.html'),
            module: 'tsum-form-helper.module.ts'
        },
        template: `
            <sb-description-wrapper
                hideAll
                [backUrl]="backUrl"
                backText="К списку general helpers"
            >
                <div>
                    <app-short-example title="Control for each" [tsFileName]="ts" [html]="html" [moduleFileName]="module">
                        <app-tsum-control-for-each-example></app-tsum-control-for-each-example>
                    </app-short-example>
                </div>
            </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersFormTitle.AddControlErrors, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].form,
                title: TsumHelpersFormTitle.Glossary,
            },
            ts: 'tsum-add-control-errors.component.ts',
            html: require('./example/tsum-add-control-errors-example/tsum-add-control-errors-example.component.html'),
            module: 'tsum-form-helper.module.ts'
        },
        template: `
            <sb-description-wrapper
                hideAll
                [backUrl]="backUrl"
                backText="К списку general helpers"
            >
                <div>
                    <app-short-example title="Add control errors" [tsFileName]="ts" [html]="html" [moduleFileName]="module">
                        <app-tsum-add-control-errors-example></app-tsum-add-control-errors-example>
                    </app-short-example>
                </div>
            </sb-description-wrapper>
        `
    }));
