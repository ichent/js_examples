import { NgModule } from '@angular/core';
import {
    TsumControlValueObservableExampleComponent
} from './example/tsum-control-value-observable-example/tsum-control-value-observable-example.component';
import { ReactiveFormsModule } from '@angular/forms';
import { ShortExampleModule } from '@tsum/storybook';
import { TsumInputModule, TsumIconsModule, TsumButtonModule } from '@tsum/ui';
import { CommonModule } from '@angular/common';
import { TsumControlForEachExampleComponent } from './example/tsum-control-for-each-example/tsum-control-for-each-example.component';
import { TsumAddControlErrorsComponent } from './example/tsum-add-control-errors-example/tsum-add-control-errors-example.component';

const COMPONENTS = [
    TsumAddControlErrorsComponent,
    TsumControlForEachExampleComponent,
    TsumControlValueObservableExampleComponent,
];


@NgModule({
    declarations: [
        ...COMPONENTS
    ],
    imports: [
        CommonModule,
        ReactiveFormsModule,
        ShortExampleModule,
        TsumInputModule,
        TsumIconsModule,
        TsumButtonModule,
    ],
    exports: [
        ...COMPONENTS
    ],
})
export class TsumFormHelperExampleModule {
}
