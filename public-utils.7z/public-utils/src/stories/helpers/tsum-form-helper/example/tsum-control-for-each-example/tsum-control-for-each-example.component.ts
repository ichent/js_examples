import { Component } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { TsumIcon } from '@tsum/ui';
import { TsumFormHelper } from 'projects/utils/src';

@Component({
    selector: 'app-tsum-control-for-each-example',
    templateUrl: './tsum-control-for-each-example.component.html',
    styleUrls: [ 'tsum-control-for-each-example.component.styl', ],
})
export class TsumControlForEachExampleComponent {

    public color = TsumIcon.Color;

    public form = new FormGroup({
        name: new FormControl(''),
        secondName: new FormControl(''),
    });

    public markAsDirty(event: MouseEvent): void {
        TsumFormHelper.controlForEach(this.form, control => control.markAsDirty(), -1);
    }

}
