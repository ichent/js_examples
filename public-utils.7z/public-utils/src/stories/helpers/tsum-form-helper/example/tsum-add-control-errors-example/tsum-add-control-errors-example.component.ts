import { Component } from '@angular/core';
import { FormControl } from '@angular/forms';
import { TsumIcon } from '@tsum/ui';
import { TsumMathHelper, TsumFormHelper } from 'projects/utils/src';

@Component({
    selector: 'app-tsum-add-control-errors-example',
    templateUrl: './tsum-add-control-errors-example.component.html',
    styleUrls: ['./tsum-add-control-errors-example.component.styl']
})
export class TsumAddControlErrorsComponent {
    public color = TsumIcon.Color;
    public control = new FormControl('');

    public addErrors(event: MouseEvent): void {
        TsumFormHelper.addControlErrors(this.control, { error: `Error: ${TsumMathHelper.getUniqueId()}` });
        this.control.markAsDirty();
    }
}
