import { Component } from '@angular/core';
import { TsumIcon } from '@tsum/ui';
import { FormControl } from '@angular/forms';
import { TsumFormHelper } from 'projects/utils/src';

@Component({
    selector: 'tsum-control-value-observable-example',
    templateUrl: './tsum-control-value-observable-example.component.html',
})
export class TsumControlValueObservableExampleComponent {
    public control = new FormControl('значение');
    public color = TsumIcon.Color;
    public controlValue$ = TsumFormHelper.controlValueObservable(this.control);
}
