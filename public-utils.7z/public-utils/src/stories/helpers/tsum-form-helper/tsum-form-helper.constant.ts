import { Glossary } from '@tsum/storybook';
import {
    StoryKindGroup,
    StoryKind,
    TsumHelpersFormTitle,
} from '../../story-kind.constant';

export const TsumFormHelpersGlossary: Glossary[] = [
    {
        name: 'controlValueObservable',
        description: 'Создает из значения контрола observable',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].form,
            title: TsumHelpersFormTitle.ControlValueObservable,
        },
    },
    {
        name: 'controlForEach',
        description: 'Итерация по вложенным контролам',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].form,
            title: TsumHelpersFormTitle.ControlValueObservable,
        },
    },
    {
        name: 'addControlErrors',
        description: 'Проставление ошибок контролу',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].form,
            title: TsumHelpersFormTitle.AddControlErrors,
        },
    },
];
