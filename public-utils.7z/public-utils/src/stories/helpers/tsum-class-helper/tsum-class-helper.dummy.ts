import { TsumInputBinding } from '@tsum/storybook';

export const sizesRows: TsumInputBinding[] = [
    {
        title: '#-xs',
        description: 'Равняется 4 пикселям. Stylus переменная var(--xs-size), например mr-xs',
    },
    {
        title: '#-sm',
        description: 'Равняется 8 пикселям. Stylus переменная var(--sm-size), например pt-sm',
    },
    {
        title: '#-semi-md',
        description: 'Равняется 12 пикселям. Stylus переменная var(--semi-md-size), например ml-semi-md',
    },
    {
        title: '#-md',
        description: 'Равняется 16 пикселям. Stylus переменная var(--md-size), например pb-md',
    },
    {
        title: '#-lg',
        description: 'Равняется 24 пикселям. Stylus переменная var(--lg-size), например pt-lg',
    },
    {
        title: '#-xlg',
        description: 'Равняется 36 пикселям. Stylus переменная var(--xlg-size), например mt-xlg',
    },
    {
        title: '#-xxlg',
        description: 'Равняется 40 пикселям. Stylus переменная var(--xxlg-size), например mt-xxlg',
    },
    {
        title: '#-mega',
        description: 'Равняется 48 пикселям. Stylus переменная var(--mega-size), например mt-mega',
    },
    {
        title: '#-null',
        description: 'Равняется 0 пикселям, например mt-null',
    },
];

export const directionRows: TsumInputBinding[] = [
    {
        title: '#-t',
        description: 'Направление top, отступы сверху, например mt-sm, pt-md',
    },
    {
        title: '#-r',
        description: 'Направление right, отступы справа, например mr-lg, pr-md',
    },
    {
        title: '#-b',
        description: 'Направление bottom, отступы снизу, например mb-sm, pb-md',
    },
    {
        title: '#-l',
        description: 'Направление left, отступы слева, например ml-sm, pl-md',
    },
    {
        title: '#-h',
        description: 'Направление horizontal, отступы сверху и снизу, например mh-sm, ph-md',
    },
    {
        title: '#-v',
        description: 'Направление vertical, отступы справа и слева, например mv-sm, pv-md',
    },
    {
        title: '#-a',
        description: 'Направление all, отступы со всех сторон, например ma-sm, pa-md',
    },
];

export const typesRows: TsumInputBinding[] = [
    {
        title: 'w/mw/max-w/w-fit',
        description: 'Отвечает за ширину/минимальную ширину/максимальную ширину/fit-content соответственно, например w-100',
    },
    {
        title: 'h/mh/max-h/lh/h-fit',
        description: 'Отвечает за высоту/минимальную высоту/максимальную/line-height/fit-content, например h-16',
    },
    {
        title: 'd/min-d/max-d/d-fit',
        description: 'Отвечает одновременно за высоту и ширину, например d-40',
    },
    {
        title: 'wh/min-wh/max-wh/wh-fit',
        description: 'Отвечает одновременно за высоту и ширину, например wh-100',
    },
];

export const widthHeightSizesRows: TsumInputBinding[] = [
    {
        title: 'xxs',
        description: '2px, например w-xxs/h-xxs/d-xxs/wh-xss',
    },
    {
        title: 'xs',
        description: '4px, например w-xs/h-xs/d-xs/wh-xs',
    },
    {
        title: 'sm',
        description: '8px, например w-sm/h-sm/d-sm/wh-sm',
    },
    {
        title: 'semi-md',
        description: '12px, например w-semi-md/h-semi-md/d-semi-md/wh-semi-md',
    },
    {
        title: 'md',
        description: '16px, например w-md/h-md/d-md/wh-md',
    },
    {
        title: 'semi-lg',
        description: '20px, например w-semi-lg/h-semi-lg/d-semi-lg/wh-semi-lg',
    },
    {
        title: 'lg',
        description: '24px, например w-lg/h-lg/d-lg/wh-lg',
    },
    {
        title: 'xlg',
        description: '32px, например w-xlg/h-xlg/d-xlg/wh-xlg',
    },
];

export const displayRows: TsumInputBinding[] = [
    {
        title: 'd-block',
        description: 'display: block',
    },
    {
        title: 'd-flex',
        description: 'display: flex',
    },
    {
        title: 'd-grid',
        description: 'display: grid',
    },
    {
        title: 'd-inline-block',
        description: 'display: inline-block',
    },
    {
        title: 'd-none',
        description: 'display: none',
    },
];

export const flexRows: TsumInputBinding[] = [
    {
        title: 'f-ai-center',
        description: 'align-items: center',
    },
    {
        title: 'f-ai-start',
        description: 'align-items: flex-start',
    },
    {
        title: 'f-ai-end',
        description: 'align-items: flex-end',
    },
    {
        title: 'f-jc-center',
        description: 'justify-content: center',
    },
    {
        title: 'f-jc-start',
        description: 'justify-content: flex-start',
    },
    {
        title: 'f-jc-end',
        description: 'justify-content: flex-end',
    },
    {
        title: 'f-jc-between',
        description: 'justify-content: space-between',
    },
    {
        title: 'f-jc-around',
        description: 'justify-content: space-around',
    },
];

export const colorHtml: string = `<div class="c-primary">Primary text</div>
<div class="bg-secondary c-white">Secondary bg</div>
<div class="w-120 h-80 bc-danger b-w-1 b-style-solid">Danger border</div>
`;

export const borderHtml: string = `<div class="w-120 h-80 bc-primary b-w-2 b-style-solid">Test border</div>`;

export const marginsHtml: string = `<div>Test margin bottom</div>
<div class="mt-lg">has margin</div>
`;

export const displayHtml: string = `<div class="d-flex">
    <div class="mr-md">Flex 1</div>
    <div>Flex 2</div>
</div>
`;

export const positionHtml: string = `<div class="position-r">
This block is relative
</div>
`;

export const overflowHtml: string = `<div class="w-120 o-hidden ws-nowrap">overflow hidden overflow hidden overflow hidden</div>`;

export const whiteSpaceHtml: string = `<div class="w-120 o-hidden ws-nowrap">text nowrap text nowrap text nowrap text nowrap</div>`;

export const cursorHtml: string = `<div class="w-120 h-100 bg-primary cursor-p">Cursor pointer</div>`;

export const textEllipsis: string = `<div class="w-120">
    <div class="text-ellipsis">Text ellispis test test test</div>
</div>`;

export const heightWidthHtml: string = `<div class="h-80 w-200 bc-primary b-w-1 b-style-solid">h-80 w-200</div>
<div class="w-50-p h-100 bg-primary">Width 50%</div>`;

export const typography: string = `
<div>Для типографии используются класс helpers</div>

<div class="mt-lg">
    <p class="main-big-black">Main Big Black</p>
    <p class="main-big-dark-gray">Main Big Dark Gray</p>
    <p class="main-big-red">Main Big Red</p>
    <p class="main-big-white bg-gray">Main Big White</p>
</div>

<div class="mt-lg">
    <p class="main-small-black">Main Medium Black</p>
    <p class="main-medium-dark-gray">Main Medium Dark Gray</p>
    <p class="main-medium-red">Main Medium Red</p>
    <p class="main-medium-white bg-gray">Main Medium White</p>
    <p class="main-medium-blue">Main Medium Blue</p>
    <p class="main-medium-orange">Main Medium Orange</p>
    <p class="main-medium-green">Main Medium Green</p>
</div>

<div class="mt-lg">
    <p class="main-medium-black">Main Small Black</p>
    <p class="main-medium-dark-gray">Main Small Dark Gray</p>
    <p class="main-medium-red">Main Small Red</p>
    <p class="main-medium-white bg-gray">Main Small White</p>
    <p class="main-medium-blue">Main Small Blue</p>
</div>
`;
