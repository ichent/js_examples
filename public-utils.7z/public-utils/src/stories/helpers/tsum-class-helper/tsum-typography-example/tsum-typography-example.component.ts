import { Component } from '@angular/core';

@Component({
    selector: 'app-tsum-typography-example',
    templateUrl: './tsum-typography-example.component.html',
})
export class TsumTypographyExampleComponent {
}
