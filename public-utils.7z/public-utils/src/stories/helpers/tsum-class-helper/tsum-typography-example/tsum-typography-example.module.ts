import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumTypographyExampleComponent } from './tsum-typography-example.component';

const COMPONENTS = [
    TsumTypographyExampleComponent,
];

@NgModule({
    imports: [
        CommonModule
    ],
    declarations: [
        COMPONENTS,
    ],
    exports: [
        COMPONENTS,
    ]
})
export class TsumTypographyExampleModule { }
