import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TsumColorHelperExampleComponent } from './tsum-color-helper-example.component';

const COMPONENTS = [
    TsumColorHelperExampleComponent,
];

@NgModule({
    imports: [
        CommonModule
    ],
    declarations: [
        COMPONENTS,
    ],
    exports: [
        COMPONENTS,
    ]
})
export class TsumColorHelperExampleModule { }
