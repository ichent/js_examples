import { Component } from '@angular/core';

interface ColorParam {
    className: string;
    classBgName: string;
    classBorderName: string;
    stylVariable: string;
    hexColor: string;
    hexFontColor?: string;
    rgbBorderColor?: string;
}

@Component({
    selector: 'app-tsum-color-helper-example',
    templateUrl: './tsum-color-helper-example.component.html',
    styleUrls: ['./tsum-color-helper-example.component.styl']
})
export class TsumColorHelperExampleComponent {
    public colors: ColorParam[] = [
        {
            className: 'class .c-primary',
            classBgName: 'class .bg-primary',
            classBorderName: 'class .bc-primary',
            stylVariable: 'css: var(--primary)',
            hexColor: '#ed722d',
        },
        {
            className: 'class .c-secondary',
            classBgName: 'class .bg-secondary',
            classBorderName: 'class .bc-secondary',
            stylVariable: 'css: var(--secondary)',
            hexColor: '#1b1b1b',
            hexFontColor: '#ffffff',
        },
        {
            className: 'class .c-success',
            classBgName: 'class .bg-success',
            classBorderName: 'class .bc-success',
            stylVariable: 'css: var(--success)',
            hexColor: '#00ad17',
        },
        {
            className: 'class .c-danger',
            classBgName: 'class .bg-danger',
            classBorderName: 'class .bc-danger',
            stylVariable: 'css: var(--danger)',
            hexColor: '#d30000',
        },
        {
            className: 'class .c-warning',
            classBgName: 'class .bg-warning',
            classBorderName: 'class .bc-warning',
            stylVariable: 'css: var(--warning)',
            hexColor: '#ed722d',
        },
        {
            className: 'class .c-info',
            classBgName: 'class .bg-info',
            classBorderName: 'class .bc-info',
            stylVariable: 'css: var(--info)',
            hexColor: '#3478b0',
        },
        {
            className: 'class .c-primary-active',
            classBgName: 'class .bg-primary-active',
            classBorderName: 'class .bc-primary-active',
            stylVariable: 'css: var(--primary-active)',
            hexColor: '#cb5411',
        },
        {
            className: 'class .c-gray',
            classBgName: 'class .bg-gray',
            classBorderName: 'class .bc-gray',
            stylVariable: 'css: var(--gray)',
            hexColor: '#dadce1',
        },
        {
            className: 'class .c-light-gray',
            classBgName: 'class .bg-light-gray',
            classBorderName: 'class .bc-light-gray',
            stylVariable: 'css: var(--light-gray)',
            hexColor: '#fafafa',
            rgbBorderColor: 'rgb(218, 220, 225)',
        },
        {
            className: 'class .c-light-white',
            classBgName: 'class .bg-light-white',
            classBorderName: 'class .bc-light-white',
            stylVariable: 'css: var(--light-white)',
            hexColor: '#fefefe',
            rgbBorderColor: 'rgb(218, 220, 225)',
        },
    ];
}
