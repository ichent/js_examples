import { Glossary } from '@tsum/storybook';
import { StoryKind, StoryKindGroup, TsumHelpersClassesTitle } from '../../story-kind.constant';

export const TsumClassHelpers: Glossary[] = [
    {
        name: 'Padding & Margin',
        description: 'С помощью их можно регулировать отступы не правя css',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].classes,
            title: TsumHelpersClassesTitle.PaddingsMargins,
        },
    },
    {
        name: 'Width & Height',
        description: 'Хелперы для ширины и высоты, максимальная, минимальная, проценты и значения',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].classes,
            title: TsumHelpersClassesTitle.HeightWeight,
        },
    },
    {
        name: 'Colors',
        description: 'Содержат хелперы для цвета шрифта, цвета фона и цвета бордера',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].classes,
            title: TsumHelpersClassesTitle.Colors,
        },
    },
    {
        name: 'General helpers',
        description: 'Общие хелперы, которые не входят ни в одну категорию',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].classes,
            title: TsumHelpersClassesTitle.General,
        },
    },
    {
        name: 'Borders',
        description: 'Все что связано с бордерами, можно детально настроить',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].classes,
            title: TsumHelpersClassesTitle.Borders,
        },
    },
    {
        name: 'Layout',
        description: 'Хелперы для layout-like свойств, например display, flex-align, grid-gap',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].classes,
            title: TsumHelpersClassesTitle.Layout,
        },
    },
    {
        name: 'Position',
        description: 'Хелперы для свойства position',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].classes,
            title: TsumHelpersClassesTitle.Position,
        },
    },
    {
        name: 'Overflow',
        description: 'Хелперы для свойства overflow',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].classes,
            title: TsumHelpersClassesTitle.Overflow,
        },
    },
    {
        name: 'Whitespace',
        description: 'Хелперы для свойства whitespace',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].classes,
            title: TsumHelpersClassesTitle.WhiteSpace,
        },
    },
    {
        name: 'Cursor',
        description: 'Хелперы для свойства cursor',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].classes,
            title: TsumHelpersClassesTitle.Cursor,
        },
    },
    {
        name: 'Typography',
        description: 'Типография для заголовков',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].classes,
            title: TsumHelpersClassesTitle.Typography,
        },
    },
];
