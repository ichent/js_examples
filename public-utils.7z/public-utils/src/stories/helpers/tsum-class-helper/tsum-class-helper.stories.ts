import {
    sizesRows,
    colorHtml,
    borderHtml,
    marginsHtml,
    displayHtml,
    heightWidthHtml,
    positionHtml,
    overflowHtml,
    whiteSpaceHtml,
    cursorHtml,
    textEllipsis,
    typography,
    typesRows,
    widthHeightSizesRows,
    displayRows,
    flexRows,
} from './tsum-class-helper.dummy';
import { storiesOf, moduleMetadata } from '@storybook/angular';
import { TsumClassHelpers } from './tsum-class-helper.constant';
import { TsumTableModule } from '@tsum/ui';
import { TsumColorHelperExampleModule } from './tsum-color-helper-example/tsum-color-helper-example.module';
import { TsumTypographyExampleModule } from './tsum-typography-example/tsum-typography-example.module';
import { SbDescriptionWrapperModule, TsumCodeHighlighterModule, ShortExampleModule, GlossaryModule } from '@tsum/storybook';
import { TsumColumnsDefault } from '../../../constants/tsum-columns.constant';
import { StoryKind, StoryKindGroup, TsumHelpersClassesTitle } from '../../story-kind.constant';

storiesOf(StoryKind[StoryKindGroup.Helpers].classes, module)
    .addDecorator(
        moduleMetadata({
            imports: [
                SbDescriptionWrapperModule,
                TsumTableModule,
                TsumColorHelperExampleModule,
                TsumCodeHighlighterModule,
                GlossaryModule,
                ShortExampleModule,
                TsumTypographyExampleModule,
            ]
        }))
    .add(TsumHelpersClassesTitle.Glossary, () => ({
        props: {
            classHelpers: TsumClassHelpers,
        },
        template: `
                <sb-description-wrapper hideAll>
                    <div header-description>Глоссарий class хелперов</div>

                    <app-glossary [items]="classHelpers" isWithoutGroup></app-glossary>
                </sb-description-wrapper>
            `,
    }))
    .add(TsumHelpersClassesTitle.General, () => ({
        props: {
            textEllipsis,
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].classes,
                title: TsumHelpersClassesTitle.Glossary,
            },
        },
        template: `
            <sb-description-wrapper hideBindings hideStyles [backUrl]="backUrl" backText="К списку хелперов">
                <div header-description>Общие хелперы</div>
                <div description tsumCodeHighlighter>
                    <div>*text-ellipsis* обрезает текст и добавляет в него троеточие</div>
                    <div>*ta-%direction%* - где *direction* это позиционирование, варианты - *center*, *left*, *right*, *justify*</div>
                </div>

                <app-short-example title="Общие хелперы" [html]="textEllipsis" examples>
                    <div class="h2 mb-md">text-ellipsis - троеточие для текста</div>
                    <div class="w-120 b-w-2 b-style-solid bc-primary">
                        <div class="text-ellipsis">Text ellipsis test test test</div>
                    </div>

                    <div class="h2 mb-md">*ta-%direction%* - Позиционирование текста</div>
                    <div class="w-120">
                        <div class="ta-center">Centered Text</div>
                    </div>
                    <div class="w-120">
                        <div class="ta-left">Left Text</div>
                    </div>
                    <div class="w-120">
                        <div class="ta-right">Right Text</div>
                    </div>
                </app-short-example>
            </sb-description-wrapper>
            `
    }))
    .add(TsumHelpersClassesTitle.PaddingsMargins, () => ({
        props: {
            sizesRows,
            columnsDefault: TsumColumnsDefault,
            marginsHtml,
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].classes,
                title: TsumHelpersClassesTitle.Glossary,
            },
        },
        template: `
            <sb-description-wrapper hideBindings hideStyles [backUrl]="backUrl" backText="К списку хелперов">
                <div header-description>Class helpers для margin и padding</div>
                <div description tsumCodeHighlighter>
                    <div class="h2 mb-md">Описание</div>
                    <div>Классы строятся по структуре: *(m/p)(direction)-(size)*</div>
                    <div>*m/p* является *margin* или *padding*</div>
                    <div>*direction* является направлением, всего их 4 - *t*(top), *r*(right), *b*(bottom), *l*(left)</div>
                    <div>
                        Так же есть дополнительные три направления: *h(horizontal)*(например mh-md) - отвечает за отступы по вертикали
                    </div>
                    <div>*v(vertical)* - отступы по вертикали и есть *a(all)* - отвечает за отступы со всех сторон</div>
                    <div>*size* является размером, ниже представлена таблица размеров</div>
                    <div>По итогу вы может комбинировать довольно много комбинаций, не прибегая к исправлению стилей</div>
                </div>

                <app-short-example title="Margin & Paddings" [html]="marginsHtml" examples>
                    <tsum-table
                        title="Таблица размеров"
                        [rows]="sizesRows"
                        [columns]="columnsDefault"
                        class="mb-lg"></tsum-table>
                </app-short-example>
            </sb-description-wrapper>
            `,
    }), { notes: 'Стандартный чекбокс, базируется на директиве tsum-checkbox' })
    .add(TsumHelpersClassesTitle.Colors, () => ({
        props: {
            colorHtml,
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].classes,
                title: TsumHelpersClassesTitle.Glossary,
            },
        },
        template: `
            <sb-description-wrapper hideBindings hideStyles [backUrl]="backUrl" backText="К списку хелперов">
                <div header-description>Цвета</div>
                <div description tsumCodeHighlighter>
                    <div>
                        Классы строятся по структуре *(colorType)-(color)*
                    </div>
                    <div>
                        *colorType* - То, где цвет будет применяться, сейчас таких три варианта:
                    </div>
                    <div>
                        *c*(color) - Отвечает за цвет текста
                    </div>
                    <div>
                        *bc*(background-color) - Отвечает за цвет фона
                    </div>
                    <div>
                        *bc*(border-color) - Отвечает за цвет бордера
                    </div>
                </div>

                <app-short-example title="Цвета" [html]="colorHtml" examples>
                    <app-tsum-color-helper-example></app-tsum-color-helper-example>
                </app-short-example>
            </sb-description-wrapper>
            `
    }))
    .add(TsumHelpersClassesTitle.Borders, () => ({
        props: {
            borderHtml,
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].classes,
                title: TsumHelpersClassesTitle.Glossary,
            },
        },
        template: `
            <sb-description-wrapper hideBindings hideStyles [backUrl]="backUrl" backText="К списку хелперов">
                <div header-description>Borders</div>
                <div description tsumCodeHighlighter>
                    <div>Для borders существует несколько хелперов:</div>
                    <div>1. Радиусы: строятся по структуре *(br)-(size)*</div>
                    <div>2. Ширине бордера: строятся по структуре *(b-w)-(size)*</div>
                    <div>3. Стиль бордера: готовые классы *b-style-solid*, *b-style-dashed*</div>
                    <div>
                        *size* - Размеры, на данный момент это 1, 2, 4, 6, 8, 10, full(100%)
                    </div>
                </div>

                <app-short-example title="Borders" [html]="borderHtml" examples>
                    <div class="w-104 h-104">
                        <div class="br-4 b-w-2 b-style-solid bc-primary">Test</div>
                    </div>
                </app-short-example>
            </sb-description-wrapper>
            `
    }))
    .add(TsumHelpersClassesTitle.Layout, () => ({
        props: {
            displayHtml,
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].classes,
                title: TsumHelpersClassesTitle.Glossary,
            },
            columnsDefault: TsumColumnsDefault,
            displayRows,
            flexRows,
        },
        template: `
            <sb-description-wrapper hideBindings hideStyles [backUrl]="backUrl" backText="К списку хелперов">
                <div header-description>Layout</div>
                <div description>
                    <div>Список хелперов для упрощения работы с layout like css свойствами</div>

                    <tsum-table
                        title="Display helpers"
                        [rows]="displayRows"
                        [columns]="columnsDefault"
                        class="mb-lg"></tsum-table>

                    <tsum-table
                        title="Flex helpers"
                        [rows]="flexRows"
                        [columns]="columnsDefault"
                        class="mb-lg"></tsum-table>
                </div>

                <app-short-example title="Display" [html]="displayHtml" examples>
                    <div class="w-104 h-104">
                        <div class="d-flex">Flex</div>
                        <div class="d-flex">Flex 2</div>
                    </div>
                </app-short-example>
            </sb-description-wrapper>
            `
    }))
    .add(TsumHelpersClassesTitle.Position, () => ({
        props: {
            positionHtml,
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].classes,
                title: TsumHelpersClassesTitle.Glossary,
            },
        },
        template: `
            <sb-description-wrapper hideBindings hideStyles [backUrl]="backUrl" backText="К списку хелперов">
                <div header-description>Position</div>
                <div description tsumCodeHighlighter>
                    <div>Для *position* есть следующие хелперы, служат для того, чтоб работать с css свойством *position*</div>
                    <div>*position-a* - Эквивалентен стилю *position: absolute*</div>
                    <div>*position-r* - Эквивалентен стилю *position: relative*</div>
                    <div>*position-f* - Эквивалентен стилю *position: fixed*</div>
                    <div>*position-static* - Эквивалентен стилю *position: static*</div>
                    <div>*position-sticky* - Эквивалентен стилю *position: sticky*</div>
                </div>

                <app-short-example title="Position" [html]="positionHtml" examples>
                    <div class="position-r">relative block</div>
                </app-short-example>
            </sb-description-wrapper>
            `
    }))
    .add(TsumHelpersClassesTitle.Overflow, () => ({
        props: {
            overflowHtml,
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].classes,
                title: TsumHelpersClassesTitle.Glossary,
            },
        },
        template: `
            <sb-description-wrapper hideBindings hideStyles [backUrl]="backUrl" backText="К списку хелперов">
                <div header-description>Overflow</div>
                <div description tsumCodeHighlighter>
                    <div>Для *overflow* есть следующие хелперы, служат для того, чтоб работать с css свойством *overflow*</div>
                    <div>*o-hidden* - Эквивалентен стилю *overflow: hidden*</div>
                    <div>*o-x-hidden* - Эквивалентен стилю *overflow-x: hidden*</div>
                    <div>*o-y-hidden* - Эквивалентен стилю *overflow-x: hidden*</div>
                    <div>*o-visible* - Эквивалентен стилю *overflow: visible*</div>
                    <div>*o-x-visible* - Эквивалентен стилю *overflow-x: visible*</div>
                    <div>*o-y-visible* - Эквивалентен стилю *overflow-y: visible*</div>
                </div>

                <app-short-example title="Overflow" [html]="overflowHtml" examples>
                    <div class="w-120 o-hidden ws-nowrap">overflow hidden overflow hidden overflow hidden</div>
                </app-short-example>
            </sb-description-wrapper>
            `
    }))
    .add(TsumHelpersClassesTitle.WhiteSpace, () => ({
        props: {
            whiteSpaceHtml,
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].classes,
                title: TsumHelpersClassesTitle.Glossary,
            },
        },
        template: `
            <sb-description-wrapper hideBindings hideStyles [backUrl]="backUrl" backText="К списку хелперов">
                <div header-description>White space</div>
                <div description tsumCodeHighlighter>
                    <div>Для *white-space* есть следующие хелперы, служат для того, чтоб работать с css свойством *white-space*</div>
                    <div>*ws-nowrap* - Эквивалентен стилю *white-space: nowrap*</div>
                    <div>*ws-pre* - Эквивалентен стилю *white-space: pre*</div>
                    <div>*ws-pre-wrap* - Эквивалентен стилю *white-space: pre-wrap*</div>
                    <div>*ws-pre-line* - Эквивалентен стилю *white-space: pre-line*</div>
                </div>

                <app-short-example title="Whitespace" [html]="whiteSpaceHtml" examples>
                    <div class="w-120 o-hidden ws-nowrap">text nowrap text nowrap text nowrap text nowrap</div>
                </app-short-example>
            </sb-description-wrapper>
            `
    }))
    .add(TsumHelpersClassesTitle.Cursor, () => ({
        props: {
            cursorHtml,
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].classes,
                title: TsumHelpersClassesTitle.Glossary,
            },
        },
        template: `
            <sb-description-wrapper hideBindings hideStyles [backUrl]="backUrl" backText="К списку хелперов">
                <div header-description>White space</div>
                <div description tsumCodeHighlighter>
                    <div>Для *cursor* есть следующие хелперы, служат для того, чтоб работать с css свойством *cursor*</div>
                    <div>*p* - Эквивалентен стилю *cursor: pointer*</div>
                    <div>*d* - Эквивалентен стилю *cursor: default*</div>
                    <div>*t* - Эквивалентен стилю *cursor: text*</div>
                </div>

                <app-short-example title="Cursor" [html]="cursorHtml" examples>
                    <div class="w-120 h-100 bg-primary cursor-p">Cursor pointer</div>
                </app-short-example>
            </sb-description-wrapper>
            `
    }))
    .add(TsumHelpersClassesTitle.HeightWeight, () => ({
        props: {
            heightWidthHtml,
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].classes,
                title: TsumHelpersClassesTitle.Glossary,
            },
            columnsDefault: TsumColumnsDefault,
            typesRows,
            widthHeightSizesRows,
        },
        template: `
            <sb-description-wrapper hideBindings hideStyles [backUrl]="backUrl" backText="К списку хелперов">
                <div header-description>Height & Width</div>
                <div description>
                    <div class="h2 mb-md">Описание</div>
                    <div tsumCodeHighlighter>Для ширины и высоты есть следующие хелперы, структура хелпера *%type%-%size%-%percent%*</div>
                    <div tsumCodeHighlighter class="mv-md">*type* комбинируется из направления и типа</div>

                    <tsum-table
                        title="Список вариантов type"
                        [rows]="typesRows"
                        [columns]="columnsDefault"
                        class="mb-lg"></tsum-table>

                    <div tsumCodeHighlighter>*size* - Размер, ниже представлен список. Все размеры кратны 8</div>
                    <div class="h2 mb-md">Доступные варианты размеров:</div>

                    <tsum-table
                        title="Список размеров"
                        [rows]="widthHeightSizesRows"
                        [columns]="columnsDefault"
                        class="mb-lg"></tsum-table>

                    <div>А так же список доступных размеров кратных 8</div>
                    <div
                        tsumCodeHighlighter
                    >*4, 8, 12, 16, 24, 32, 40, 48, 56, 64, 72, 80, 88, 96, 104, 112, 120, 160, 200, 240, 272, 320, 400, 600.*</div>
                    <div
                        tsumCodeHighlighter
                    >*128, 136, 144, 152, 168, 176, 184, 192, 208, 216, 224, 232, от 248 до 312, от 328 до 392.*</div>
                    <div tsumCodeHighlighter>Например *w-32/h-56/d-72/wh-104*</div>

                    <div tsumCodeHighlighter class="mt-md">
                        *percent* - Опциональный параметр, отвечает за проценты, доступные параметры *100*, *50*, *25*, *10*
                    </div>
                    <div tsumCodeHighlighter>Например *w-25-p/h-100-p/d-10-p/wh-50-p*</div>
                </div>

                <app-short-example title="Height & Weight" [html]="heightWidthHtml" examples>
                    <div class="h-80 w-200 bc-primary b-w-1 b-style-solid mb-md">h-80 w-200 bc-primary b-w-1 b-style-solid mb-md</div>
                    <div class="w-50-p h-100 bg-primary">w-50-p h-100 bg-primary</div>
                    <div class="d-104 bg-info pa-md">d-104 bg-info pa-md</div>
                </app-short-example>
            </sb-description-wrapper>
            `
    }))
    .add(TsumHelpersClassesTitle.Typography, () => ({
        props: {
            heightWidthHtml,
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].classes,
                title: TsumHelpersClassesTitle.Glossary,
            },
            html: typography,
        },
        template: `
            <sb-description-wrapper hideBindings hideStyles [backUrl]="backUrl" backText="К списку хелперов">
                <div header-description>Типография</div>
                <div description tsumCodeHighlighter class="w-fit">
                    Смотрите примеры
                </div>

                <app-short-example title="Примеры типографии" [html]="html" examples>
                    <app-tsum-typography-example></app-tsum-typography-example>
                </app-short-example>
            </sb-description-wrapper>
            `
    }));
