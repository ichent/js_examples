import { Glossary } from '@tsum/storybook';
import {
    TsumHelpersGeneralTitle,
    StoryKindGroup,
    StoryKind,
} from '../../story-kind.constant';

export const TsumGeneralHelpersGlossary: Glossary[] = [
    {
        name: 'isPropertyActive',
        description: 'Используется для инпутов, проверяет активен ли инпут',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].general,
            title: TsumHelpersGeneralTitle.IsPropertyActive,
        },
    },
    {
        name: 'invertNumber',
        description: 'Используется для инвертирования числа',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].general,
            title: TsumHelpersGeneralTitle.InvertNumber,
        },
    },
    {
        name: 'rangeArray',
        description: 'Используется для получения массива с заданными интервальными цифрами',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].general,
            title: TsumHelpersGeneralTitle.RangeArray,
        },
    },
    {
        name: 'isNotNull',
        description: 'Используется для проверки на null',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].general,
            title: TsumHelpersGeneralTitle.IsNotNull,
        },
    },
    {
        name: 'isObject',
        description: 'Используется для проверки на object',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].general,
            title: TsumHelpersGeneralTitle.IsObject,
        },
    },
    {
        name: 'isEqual',
        description: 'Используется для проверки на одинаковые значения',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].general,
            title: TsumHelpersGeneralTitle.IsEqual,
        },
    },
    {
        name: 'isMatch',
        description: 'Проверяет вхождение объекта Б в объект А',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].general,
            title: TsumHelpersGeneralTitle.IsMatch,
        },
    },
    {
        name: 'pipe',
        description: 'Последовательно применяет функции к переданному аргументу',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].general,
            title: TsumHelpersGeneralTitle.Pipe,
        },
    },
    {
        name: 'isInString',
        description: 'Проверяет является ли строка числом',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].general,
            title: TsumHelpersGeneralTitle.IsIntString,
        },
    },
    {
        name: 'IsArrayLike',
        description: 'Проверяет является ли значение массиво подобным',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].general,
            title: TsumHelpersGeneralTitle.IsArrayLike,
        },
    },
    {
        name: 'IsEmpty',
        description: 'Проверяет является ли значение пуст массивом, массиво подобным, set, map, oject, строкой',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].general,
            title: TsumHelpersGeneralTitle.IsEmpty,
        },
    },
    {
        name: 'defaultTo',
        description: 'При отсутствующем значении возвращает дефолтное',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].general,
            title: TsumHelpersGeneralTitle.DefaultTo,
        },
    },
    {
        name: 'OmitBy',
        description: 'Удаление из объекта значений удовлетворяющих предикату, возвращает новый объект',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].general,
            title: TsumHelpersGeneralTitle.OmitBy,
        },
    },
    {
        name: 'OmitUndefined',
        description: 'Удаление из объекта значений являющихся undefined, возвращает новый объект',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].general,
            title: TsumHelpersGeneralTitle.OmitBy,
        },
    },
];
