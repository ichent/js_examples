import { storiesOf, moduleMetadata } from '@storybook/angular';
import {
    TsumGeneralHelpersGlossary,
} from './tsum-general-helper.constant';
import { TsumTableModule } from '@tsum/ui';
import { SbDescriptionWrapperModule, TsumCodeHighlighterModule, GlossaryModule, SbUtilsModule } from '@tsum/storybook';
import { TsumHelpersGeneralTitle, StoryKind, StoryKindGroup } from '../../story-kind.constant';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';

storiesOf(StoryKind[StoryKindGroup.Helpers].general, module)
    .addDecorator(
        moduleMetadata({
            imports: [
                CommonModule,
                HttpClientModule,
                SbDescriptionWrapperModule,
                SbUtilsModule,
                TsumTableModule,
                TsumCodeHighlighterModule,
                GlossaryModule,
            ]
        }))
    .add(TsumHelpersGeneralTitle.Glossary, () => ({
        props: {
            TsumGeneralHelpersGlossary,
        },
        template: `
            <sb-description-wrapper hideAll>
                <div header-description>Глоссарий general хелперов</div>

                <app-glossary [items]="TsumGeneralHelpersGlossary" isWithoutGroup></app-glossary>
            </sb-description-wrapper>
        `,
    }))
    .add(TsumHelpersGeneralTitle.IsPropertyActive, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].general,
                title: TsumHelpersGeneralTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку general helpers"
        >
            <div header-description>isPropertyActive</div>
            <div>
                <div tsumCodeHighlighter>Используется для проверки значения в *input*</div>

                <sb-code language="typescript" [template]="template"></sb-code>

                <ng-template #template>
                    <div>TsumGeneralHelper.isPropertyActive(''); // returns true</div>
                    <div>TsumGeneralHelper.isPropertyActive('test'); // returns false</div>
                    <div>TsumGeneralHelper.isPropertyActive(true); // returns true</div>
                    <div>TsumGeneralHelper.isPropertyActive(false); // returns false</div>
                </ng-template>
            </div>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersGeneralTitle.InvertNumber, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].general,
                title: TsumHelpersGeneralTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку general helpers"
        >
            <div header-description>invertNumber</div>
            <div>
                <div>Используется для инвертирования цифры</div>

                <sb-code language="typescript" [template]="template"></sb-code>

                <ng-template #template>
                    <div>TsumGeneralHelper.invertNumber(1) // returns -1</div>
                    <div>TsumGeneralHelper.invertNumber(-1); // returns 1</div>
                </ng-template>
            </div>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersGeneralTitle.RangeArray, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].general,
                title: TsumHelpersGeneralTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку general helpers"
        >
            <div header-description>rangeArray</div>
            <div>
                <div>Используется для получения ренжа в массиве</div>

                <sb-code language="typescript" [template]="template"></sb-code>

                <ng-template #template>
                    <div>TsumGeneralHelper.rangeArray(1, 3); // returns [1, 2]</div>
                    <div>TsumGeneralHelper.rangeArray(3); // returns [0, 1, 2]</div>
                    <div>TsumGeneralHelper.rangeArray(0, 4); // returns [0, 1, 2, 3]</div>
                    <div>TsumGeneralHelper.rangeArray(0, -4); // returns [0, -1, -2, -3]</div>
                    <div>TsumGeneralHelper.rangeArray(-4); // returns [0, -1, -2, -3]</div>
                </ng-template>
            </div>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersGeneralTitle.IsNotNull, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].general,
                title: TsumHelpersGeneralTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку general helpers"
        >
            <div header-description>isNotNull</div>
            <div>
                <div>Используется для проверки на null</div>

                <sb-code language="typescript" [template]="template"></sb-code>

                <ng-template #template>
                    <div>TsumGeneralHelper.isNotNull(1); // returns false</div>
                    <div>TsumGeneralHelper.isNotNull('1'); // returns false</div>
                    <div>TsumGeneralHelper.isNotNull(null); // returns true</div>
                </ng-template>
            </div>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersGeneralTitle.IsObject, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].general,
                title: TsumHelpersGeneralTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку general helpers"
        >
            <div header-description>isObject</div>
            <div>
                <div>Используется для проверки на object</div>
                <sb-code language="typescript" [template]="template"></sb-code>

                <ng-template #template>
                    <div>TsumGeneralHelper.isObject(1); // returns false</div>
                    <div>TsumGeneralHelper.isObject('1'); // returns false</div>
                    <div>TsumGeneralHelper.isObject({{ '{' }}{{ '}' }}); // returns true</div>
                </ng-template>
            </div>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersGeneralTitle.IsEqual, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].general,
                title: TsumHelpersGeneralTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку general helpers"
        >
            <div header-description>isEqual</div>
            <div>
                <div>Используется для сравнения двух переменных</div>

                <sb-code language="typescript" [template]="template"></sb-code>

                <ng-template #template>
                    <div>TsumGeneralHelper.isEqual(1, 2); // returns false</div>
                    <div>TsumGeneralHelper.isEqual('1', '1'); // returns true</div>
                    <div>TsumGeneralHelper.isEqual({{ '{' }}a: 1{{ '}' }}, {{ '{' }}a: 1{{ '}' }}); // returns true</div>
                    <div>TsumGeneralHelper.isEqual({{ '{' }}a: 1{{ '}' }}, {{ '{' }}a: 2{{ '}' }}); // returns false</div>
                    <div>TsumGeneralHelper.isEqual([1], [1]]); // returns true</div>
                </ng-template>
            </div>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersGeneralTitle.IsMatch, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].general,
                title: TsumHelpersGeneralTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку general helpers"
        >
            <div header-description>isMatch</div>
            <div>
                <div>Проверяет вхождение объекта А в объект Б</div>

                <sb-code language="typescript" [template]="template"></sb-code>

                <ng-template #template>
                    <div>TsumGeneralHelper.isMatch({{ '{' }}a: 1, b: 2, c: 3{{ '}' }}, {{ '{' }}b: 2, c: 3{{ '}' }}); // returns true</div>
                    <div>TsumGeneralHelper.isMatch({{ '{' }}a: 1, b: 2, c: 3{{ '}' }}, {{ '{' }}d: 4{{ '}' }}); // returns false</div>
                    <div>TsumGeneralHelper.isMatch({{ '{' }}a: 1, b: 2, c: 3{{ '}' }}, {{ '{' }}c: 3, d: 4{{ '}' }}); // returns false</div>
                </ng-template>
            </div>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersGeneralTitle.Pipe, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].general,
                title: TsumHelpersGeneralTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку general helpers"
        >
            <div header-description>pipe</div>
            <div>
                <div>Последовательно применяет функции к переданному аргументу</div>

                <sb-code language="typescript" [template]="template"></sb-code>

                <ng-template #template>
                    <div>const f = TsumGeneralHelper.pipe(Math.ceil, Math.pow);</div>
                    <div>f(3.2, 2); // returns 4^2</div>
                </ng-template>
            </div>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersGeneralTitle.IsIntString, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].general,
                title: TsumHelpersGeneralTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку general helpers"
        >
            <div header-description>isIntString</div>
            <div>
                <div>Проверяет является ли строка числом</div>

                <sb-code language="typescript" [template]="template"></sb-code>

                <ng-template #template>
                    <div>TsumGeneralHelper.isIntString('12'); // returns true</div>
                    <div>TsumGeneralHelper.isIntString('девять'); // returns false</div>
                </ng-template>
            </div>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersGeneralTitle.IsArrayLike, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].general,
                title: TsumHelpersGeneralTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку general helpers"
        >
            <div header-description>isArrayLike</div>
            <div>
                <div>Проверяет является ли значение массиво подобным</div>

                <sb-code language="typescript" [template]="template"></sb-code>

                <ng-template #template>
                    <div>function testArguments() {{ '{' }}
                        return TsumGeneralHelper.isArrayLike(arguments)
                        {{ '}' }}
                    </div>
                    <div>testArguments() //return true</div>

                    <div>  TsumGeneralHelper.isArrayLike(new Set()) // returns false </div>
                </ng-template>
            </div>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersGeneralTitle.IsEmpty, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].general,
                title: TsumHelpersGeneralTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку general helpers"
        >
            <div header-description>isEmpty</div>
            <div>
                <div>Проверяет является ли значение пуст массивом, массиво подобным, set, map, oject, строкой</div>

                <sb-code language="typescript" [template]="template"></sb-code>

                <ng-template #template>
                    <div>TsumGeneralHelper.isEmpty('массив'); // returns false</div>
                    <div>TsumGeneralHelper.isEmpty([]); // returns true</div>
                    <div>TsumGeneralHelper.isEmpty({{'{'}}x: 17{{'}'}}); // returns false</div>
                    <div>TsumGeneralHelper.isEmpty(new Set()); // returns true</div>
                    <div>TsumGeneralHelper.isEmpty(new Map()); // returns true</div>
                </ng-template>
            </div>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersGeneralTitle.DefaultTo, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].general,
                title: TsumHelpersGeneralTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку general helpers"
        >
            <div header-description>defaultTo</div>
            <div>
                <div>При отсутствующем значении возвращает дефолтное</div>

                <sb-code language="typescript" [template]="template"></sb-code>

                <ng-template #template>
                    <div>let someOne;</div>
                    <div>TsumGeneralHelper.defaultTo(defaultTo, 'default); // returns 'default'</div>
                    <div>someOne = 16;</div>
                    <div>TsumGeneralHelper.defaultTo(someOne, 'default'); // returns 16</div>
                </ng-template>
            </div>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersGeneralTitle.OmitBy, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].general,
                title: TsumHelpersGeneralTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку general helpers"
        >
            <div header-description>omitBy</div>
            <div>
                <div>Удаление из объекта значений удовлетворяющих предикату, возвращает новый объект</div>

                <sb-code language="typescript" [template]="template"></sb-code>

                <ng-template #template>
                    <div>let someOne;</div>
                    <div>const src = { a: undefined; b: 13 };</div>
                    <div>omitBy(src, value => value === undefined); //  returns { b: 13 }</div>
                </ng-template>
            </div>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersGeneralTitle.OmitUndefined, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].general,
                title: TsumHelpersGeneralTitle.OmitUndefined,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку general helpers"
        >
            <div header-description>omitUndefined</div>
            <div>
                <div>Удаление из объекта значений являющихся undefined, возвращает новый объект</div>

                <sb-code language="typescript" [template]="template"></sb-code>

                <ng-template #template>
                    <div>const src = { a: undefined; b: 13 };</div>
                    <div>omitUndefined(src); //  returns { b: 13 }</div>
                </ng-template>
            </div>
        </sb-description-wrapper>
        `
    }));
