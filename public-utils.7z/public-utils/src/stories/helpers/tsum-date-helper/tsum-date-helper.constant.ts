import { Glossary } from '@tsum/storybook';
import { TsumHelpersDateTitle, StoryKind, StoryKindGroup } from '../../story-kind.constant';

export const TsumDateHelpersGlossary: Glossary[] = [
    {
        name: 'General',
        description: 'Основной хелпер, преобразует js дату в нужный инстанс, с которым можно полноценно работать',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].date,
            title: TsumHelpersDateTitle.General,
        },
    },
    {
        name: 'realMonthNumber',
        description: 'Возвращает номер месяца от переданной даты',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].date,
            title: TsumHelpersDateTitle.RealMonthNumber,
        },
    },
    {
        name: 'completeDate',
        description: 'Вернет строку с текущем днем, с добавлением нуля, в случае если число меньше 10',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].date,
            title: TsumHelpersDateTitle.CompleteDate,
        },
    },
    {
        name: 'format',
        description: 'Форматирование даты',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].date,
            title: TsumHelpersDateTitle.Format,
        },
    },
    {
        name: 'isSame',
        description: 'Проверяет, что конкретная дата равна переданной, можно передавать точность(например проверять по месяцу)',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].date,
            title: TsumHelpersDateTitle.IsSame,
        },
    },
    {
        name: 'isAfter',
        description: 'Проверяет, что переданная дата после текущей(которая в инстансе)',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].date,
            title: TsumHelpersDateTitle.IsAfter,
        },
    },
    {
        name: 'isBefore',
        description: 'Проверяет, что переданная до текущей(которая в инстансе)',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].date,
            title: TsumHelpersDateTitle.IsBefore,
        },
    },
    {
        name: 'isBetween',
        description: 'Проверяет что дата в инстансе находиться между переданными',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].date,
            title: TsumHelpersDateTitle.IsBetween,
        },
    },
    {
        name: 'getPrevFullYear',
        description: 'Возвращает предыдущий год(js date) от текущего в инстансе, может возвращать с оффсетом',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].date,
            title: TsumHelpersDateTitle.GetPrevFullYear,
        },
    },
    {
        name: 'getNextFullYear',
        description: 'Возвращает следующий год(js date) от текущего в инстансе, может возвращать с оффсетом',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].date,
            title: TsumHelpersDateTitle.GetNextFullYear,
        },
    },
    {
        name: 'getFirstMonthByYear',
        description: 'Возвращает первый месяц(js date object) в году',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].date,
            title: TsumHelpersDateTitle.GetFirstMonthByYear,
        },
    },
    {
        name: 'getYear',
        description: 'Возвращает цифру с текущим годом',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].date,
            title: TsumHelpersDateTitle.GetYear,
        },
    },
    {
        name: 'getNextMonth',
        description: 'Возвращает следующий месяц от даты в инстансе, принимает оффсет',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].date,
            title: TsumHelpersDateTitle.GetNextMonth,
        },
    },
    {
        name: 'getPrevMonth',
        description: 'Возвращает пред. месяц от даты в инстансе, принимает оффсет',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].date,
            title: TsumHelpersDateTitle.GetPrevMonth,
        },
    },
    {
        name: 'getFirstDayByMonth',
        description: 'Возвращает js date с первым днем месяца от текущей даты в инстансе',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].date,
            title: TsumHelpersDateTitle.GetFirstMonthByYear,
        },
    },
    {
        name: 'getLastDayByMonth',
        description: 'Возвращает js date с последним днем месяца от текущей даты в инстансе',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].date,
            title: TsumHelpersDateTitle.GetLastDayByMonth,
        },
    },
    {
        name: 'getMonthName',
        description: 'Вернет название месяца от текущего в инстансе',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].date,
            title: TsumHelpersDateTitle.GetMonthName,
        },
    },
    {
        name: 'getShortMonthName',
        description: 'Возвращает короткое название месяца от текущей даты в инстансе',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].date,
            title: TsumHelpersDateTitle.GetShortMonthName,
        },
    },
    {
        name: 'getNextDay',
        description: 'Возвращает js date со следующим днем от текущей даты в инстансе, принимает оффсет',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].date,
            title: TsumHelpersDateTitle.GetNextDay,
        },
    },
    {
        name: 'getPrevDay',
        description: 'Возвращает js date с пред. днем от текущей даты в инстансе, принимает оффсет',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].date,
            title: TsumHelpersDateTitle.GetPrevDay,
        },
    },
    {
        name: 'getDayName',
        description: 'Возвращает название дня недели',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].date,
            title: TsumHelpersDateTitle.GetDayName,
        },
    },
    {
        name: 'getDate',
        description: 'Возвращает текущий день месяца',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].date,
            title: TsumHelpersDateTitle.GetDate,
        },
    },
];
