import { HttpClientModule } from '@angular/common/http';
import { storiesOf, moduleMetadata } from '@storybook/angular';
import { TsumTableModule } from '@tsum/ui';
import {
    TsumInputBinding,
    SbDescriptionWrapperModule,
    TsumCodeHighlighterModule,
    GlossaryModule,
    SbUtilsModule,
} from '@tsum/storybook';

import {
    TsumHelpersDateTitle,
    StoryKind,
    StoryKindGroup,
} from '../../story-kind.constant';
import { TsumColumnsDefault } from './../../../constants/tsum-columns.constant';
import { TsumDateHelpersGlossary } from './tsum-date-helper.constant';

const isSameRows: TsumInputBinding[] = [
    {
        title: 'date',
        description: 'Вернет true если date совпадает',
    },
    {
        title: 'month',
        description: 'Вернет true если month совпадает',
    },
    {
        title: 'year',
        description: 'Вернет true если year совпадает',
    },
    {
        title: 'full',
        description: 'Вернет true если даты полностью совпадают(до мс)',
    },
    {
        title: 'monthAndDate',
        description: 'Вернет true если совпадает месяц и день',
    },
    {
        title: 'monthAndDateAndYear',
        description: 'Вернет true если совпадает год, месяц и день',
    },
];

const isAfterRows: TsumInputBinding[] = [
    {
        title: 'full',
        description: 'Проверяет по timestamp',
    },
    {
        title: 'monthAndDateAndYear',
        description: 'Проверяет по году, месяцу и дню',
    },
];

const isBetweenRows: TsumInputBinding[] = [
    {
        title: 'full',
        description: 'Проверяет по timestamp',
    },
    {
        title: 'monthAndDateAndYear',
        description: 'Проверяет по году, месяцу и дню',
    },
];

const isBeforeRows: TsumInputBinding[] = [
    {
        title: 'full',
        description: 'Проверяет по timestamp',
    },
    {
        title: 'monthAndDateAndYear',
        description: 'Проверяет по году, месяцу и дню',
    },
];

const formatRows: TsumInputBinding[] = [
    {
        title: 'mm/dd/yyyy',
        description: 'Приводит дату к данному формату, например "10/20/2000"',
    },
    {
        title: 'dd/mm/yyyy',
        description: 'Приводит дату к данному формату, например "20/01/2000"',
    },
];

storiesOf(StoryKind[StoryKindGroup.Helpers].date, module)
    .addDecorator(
        moduleMetadata({
            imports: [
                HttpClientModule,
                SbDescriptionWrapperModule,
                SbUtilsModule,
                TsumTableModule,
                TsumCodeHighlighterModule,
                GlossaryModule,
            ]
        }))
    .add(TsumHelpersDateTitle.Glossary, () => ({
        props: {
            TsumDateHelpersGlossary,
        },
        template: `
            <sb-description-wrapper hideAll>
                <div header-description>Глоссарий date хелперов</div>

                <app-glossary [items]="TsumDateHelpersGlossary" isWithoutGroup></app-glossary>
            </sb-description-wrapper>
        `,
    }))
    .add(TsumHelpersDateTitle.General, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].date,
                title: TsumHelpersDateTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку date helpers"
        >
            <div header-description>Date helper</div>
            <div>
                <div class="h2 mv-md">How to</div>
                <div tsumCodeHighlighter>Для работы с датами имеется специальный хелпер - *TsumDate*</div>
                <div>Что бы с ним работать в него нужно передать нужную вам дату</div>
                <div tsumCodeHighlighter>В виде *js date* или *timestamp*</div>
                <div>После этого вы можете пользоваться всеми методами</div>

                <div class="h2 mv-md">Examples</div>

                <sb-code language="typescript" [template]="template"></sb-code>

                <ng-template #template>
                    <div>TsumDate(new Date()).getPrevDay()</div>
                </ng-template>
            </div>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersDateTitle.RealMonthNumber, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].date,
                title: TsumHelpersDateTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку date helpers"
        >
            <div header-description>realMonthNumber</div>
            <div>
                <div>
                    Вернет месяц, который равен нашему номеру месяцу, ибо js возвращает номер месяца - 1
                </div>

                <sb-code language="typescript" [template]="template"></sb-code>

                <ng-template #template>
                    <div>TsumDate(new Date()).realMonthNumber() - вернет 5(если сейчас май)</div>
                </ng-template>
            </div>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersDateTitle.CompleteDate, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].date,
                title: TsumHelpersDateTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку date helpers"
        >
            <div header-description>completeDate</div>
            <div>
                <div>
                    Вернет строку с датой, в которой будет добавлен 0, если он необходим, например вернет 01, вместо 1
                </div>

                <sb-code language="typescript" [template]="template"></sb-code>

                <ng-template #template>
                    <div>TsumDate(new Date()).completeDate() - вернет 05(если сейчас пятое число)</div>
                </ng-template>
            </div>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersDateTitle.Format, () => ({
        props: {
            formatRows,
            TsumColumnsDefault,
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].date,
                title: TsumHelpersDateTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку date helpers"
        >
            <div header-description>format</div>
            <div>
                <div>
                    Форматирование даты, принимает аргументом формат
                </div>

                <sb-code language="typescript" [template]="template"></sb-code>

                <ng-template #template>
                    <div>TsumDate(new Date()).format('dd/mm/yyyy') - 20/01/2019</div>
                </ng-template>

                <tsum-table
                    title="Format arguments"
                    [rows]="formatRows"
                    [columns]="TsumColumnsDefault"
                    class="mh-md"></tsum-table>
            </div>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersDateTitle.IsSame, () => ({
        props: {
            isSameRows,
            TsumColumnsDefault,
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].date,
                title: TsumHelpersDateTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку date helpers"
        >
            <div header-description>isSame</div>
            <div>
                <div>Данный метод помогает сравнить даты</div>
                <div tsumCodeHighlighter>Возвращает boolean, принимает аргументом *accuracy*, который определяет точность</div>

                <sb-code language="typescript" [template]="template"></sb-code>

                <ng-template #template>
                    <div>TsumDate(new Date()).isSame(new Date()) - true</div>
                </ng-template>

                <tsum-table
                    title="Accuracy level isSame"
                    [rows]="isSameRows"
                    [columns]="TsumColumnsDefault"
                    class="mh-md"></tsum-table>
            </div>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersDateTitle.IsAfter, () => ({
        props: {
            isAfterRows,
            TsumColumnsDefault,
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].date,
                title: TsumHelpersDateTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку date helpers"
        >
            <div header-description>isAfter</div>
            <div>
                <div>Данный метод помогает узнать, текущая дата после переданной</div>
                <div tsumCodeHighlighter>Возвращает boolean, принимает аргументом *accuracy*, который определяет точность</div>

                <sb-code language="typescript" [template]="template"></sb-code>

                <ng-template #template>
                    <div>TsumDate(new Date()).isAfter(TsumDate().getPrevDay()) - true</div>
                </ng-template>

                <tsum-table
                    title="Accuracy level isAfter"
                    [rows]="isAfterRows"
                    [columns]="TsumColumnsDefault"
                    class="mh-md"></tsum-table>
            </div>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersDateTitle.IsBefore, () => ({
        props: {
            isBeforeRows,
            TsumColumnsDefault,
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].date,
                title: TsumHelpersDateTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку date helpers"
        >
            <div header-description>isAfter</div>
            <div>
                <div>Данный метод помогает узнать, текущая дата до переданной</div>
                <div tsumCodeHighlighter>Возвращает boolean, принимает аргументом *accuracy*, который определяет точность</div>

                <sb-code language="typescript" [template]="template"></sb-code>

                <ng-template #template>
                    <div>TsumDate(new Date()).isBefore(TsumDate().getNextDay()) - true</div>
                </ng-template>

                <tsum-table
                    title="Accuracy level isBefore"
                    [rows]="isBeforeRows"
                    [columns]="TsumColumnsDefault"
                    class="mh-md"></tsum-table>
            </div>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersDateTitle.IsBetween, () => ({
        props: {
            isBetweenRows,
            TsumColumnsDefault,
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].date,
                title: TsumHelpersDateTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку date helpers"
        >
            <div header-description>isAfter</div>
            <div>
                <div>Данный метод помогает узнать, что текущая дата находиться между переданными</div>
                <div tsumCodeHighlighter>Возвращает boolean, принимает аргументом *accuracy*, который определяет точность</div>

                <sb-code language="typescript" [template]="template"></sb-code>

                <ng-template #template>
                    <div>TsumDate(new Date()).isBetween(TsumDate().getPrevDay(), TsumDate().getNextDay()) - true</div>
                </ng-template>

                <tsum-table
                    title="Accuracy level isBetween"
                    [rows]="isBetweenRows"
                    [columns]="TsumColumnsDefault"
                    class="mh-md"></tsum-table>
            </div>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersDateTitle.GetPrevFullYear, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].date,
                title: TsumHelpersDateTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку date helpers"
        >
            <div header-description>getPrevFullYear</div>
            <div>
                <div>Данный js date с пред. годом</div>
                <div tsumCodeHighlighter>Принимает *offset*, который по умолчанию - *1*, и если хотим получить 10 лет назад можем передать *10*</div>

                <sb-code language="typescript" [template]="template"></sb-code>

                <ng-template #template>
                    <div>TsumDate(new Date()).getPrevFullYear() - Текущий год - 1</div>
                </ng-template>
            </div>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersDateTitle.GetNextFullYear, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].date,
                title: TsumHelpersDateTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку date helpers"
        >
            <div header-description>getNextFullYear</div>
            <div>
                <div>Данный js date с след. годом</div>
                <div tsumCodeHighlighter>Принимает *offset*, который по умолчанию - *1*, и если хотим получить 10 лет вперед можем передать *10*</div>

                <sb-code language="typescript" [template]="template"></sb-code>

                <ng-template #template>
                    <div>TsumDate(new Date()).getNextFullYear() - Текущий год + 1</div>
                </ng-template>
            </div>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersDateTitle.GetFirstMonthByYear, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].date,
                title: TsumHelpersDateTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку date helpers"
        >
            <div header-description>getFirstMonthByYear</div>
            <div>Возвращает js date с первым днем текущего года</div>

            <sb-code language="typescript" [template]="template"></sb-code>

            <ng-template #template>
                <div>TsumDate(new Date()).getFirstMonthByYear() - Первое января текущего года</div>
            </ng-template>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersDateTitle.GetYear, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].date,
                title: TsumHelpersDateTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку date helpers"
        >
            <div header-description>getYear</div>
            <div>Возвращает число с текущим годом</div>

            <sb-code language="typescript" [template]="template"></sb-code>

            <ng-template #template>
                <div>TsumDate(new Date()).getYear() - вернет цифру с текущим годом</div>
            </ng-template>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersDateTitle.GetNextMonth, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].date,
                title: TsumHelpersDateTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку date helpers"
        >
            <div header-description>getNextMonth</div>
            <div>Возвращает js date со след. месяцем</div>
            <div tsumCodeHighlighter>Принимает *offset*, который по умолчанию - *1*, и если хотим получить 5 месяцев вперед можем передать *5*</div>

            <sb-code language="typescript" [template]="template"></sb-code>

            <ng-template #template>
                <div>TsumDate(new Date()).getNextMonth() - вернет текущий месяц + 1</div>
            </ng-template>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersDateTitle.GetPrevMonth, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].date,
                title: TsumHelpersDateTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку date helpers"
        >
            <div header-description>getPrevMonth</div>
            <div>Возвращает js date со пред. месяцем</div>
            <div tsumCodeHighlighter>Принимает *offset*, который по умолчанию - *1*, и если хотим получить 5 месяцев назад можем передать *5*</div>

            <sb-code language="typescript" [template]="template"></sb-code>

            <ng-template #template>
                <div>TsumDate(new Date()).getPrevMonth() - вернет текущий месяц - 1</div>
            </ng-template>
        </sb-description-wrapper>
        `
    }))
    .add('getFirstDayByMonth', () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].date,
                title: TsumHelpersDateTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку date helpers"
        >
            <div header-description>getFirstDayByMonth</div>
            <div>Возвращает js date с первым днем месяца</div>

            <sb-code language="typescript" [template]="template"></sb-code>

            <ng-template #template>
                <div>TsumDate(new Date()).getFirstDayByMonth() - первое число текущего месяца</div>
            </ng-template>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersDateTitle.GetLastDayByMonth, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].date,
                title: TsumHelpersDateTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку date helpers"
        >
            <div header-description>getLastDayByMonth</div>
            <div>Возвращает js date с последним днем месяца</div>

            <sb-code language="typescript" [template]="template"></sb-code>

            <ng-template #template>
                <div>TsumDate(new Date()).getLastDayByMonth() - последнее число текущего месяца</div>
            </ng-template>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersDateTitle.GetMonthName, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].date,
                title: TsumHelpersDateTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку date helpers"
        >
            <div header-description>getMonthName</div>
            <div>Возвращает название текущего месяца</div>
            <div>Так же можно передать список месяцев, по умолчанию список месяцев на русском</div>
            <div>Список месяцев(нужно передавать строго в этом порядке, массивом):</div>
            <div>Январь</div>
            <div>Февраль</div>
            <div>Март</div>
            <div>Апрель</div>
            <div>Май</div>
            <div>Июнь</div>
            <div>Июль</div>
            <div>Август</div>
            <div>Сентябрь</div>
            <div>Октябрь</div>
            <div>Ноябрь</div>
            <div>Декабрь</div>

            <sb-code language="typescript" [template]="template"></sb-code>

            <ng-template #template>
                <div>TsumDate(new Date()).getMonthName() - название текущего месяца</div>
            </ng-template>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersDateTitle.GetShortMonthName, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].date,
                title: TsumHelpersDateTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку date helpers"
        >
            <div header-description>getShortMonthName</div>
            <div>Возвращает короткую версию названия текущего месяца</div>
            <div>Так же можно передать список месяцев, по умолчанию список месяцев на русском</div>
            <div>Список месяцев(нужно передавать строго в этом порядке, массивом):</div>
            <div>Янв</div>
            <div>Февр</div>
            <div>Март</div>
            <div>Апр</div>
            <div>Май</div>
            <div>Июнь</div>
            <div>Июль</div>
            <div>Авг</div>
            <div>Сент</div>
            <div>Окт</div>
            <div>Нояб</div>
            <div>Дек</div>

            <sb-code language="typescript" [template]="template"></sb-code>

            <ng-template #template>
                <div>TsumDate(new Date()).getShortMonthName() - короткую версию названия текущего месяца</div>
            </ng-template>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersDateTitle.GetNextDay, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].date,
                title: TsumHelpersDateTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку date helpers"
        >
            <div header-description>getNextDay</div>
            <div>Возвращает js date со следующим днем</div>
            <div tsumCodeHighlighter>Принимает *offset*, который по умолчанию - *1*, и если хотим получить 5 дней вперед можем передать *5*</div>

            <sb-code language="typescript" [template]="template"></sb-code>

            <ng-template #template>
                <div>TsumDate(new Date()).getNextDay() - следующий день</div>
            </ng-template>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersDateTitle.GetPrevDay, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].date,
                title: TsumHelpersDateTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку date helpers"
        >
            <div header-description>getPrevDay</div>
            <div>Возвращает js date со пред. днем</div>
            <div tsumCodeHighlighter>Принимает *offset*, который по умолчанию - *1*, и если хотим получить 5 дней назад можем передать *5*</div>

            <sb-code language="typescript" [template]="template"></sb-code>

            <ng-template #template>
                <div>TsumDate(new Date()).getPrevDay() - пред. день</div>
            </ng-template>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersDateTitle.GetDayName, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].date,
                title: TsumHelpersDateTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку date helpers"
        >
            <div header-description>getDayName</div>
            <div>Возвращает название дня недели</div>
            <div>Так же можно передать список дней недели, по умолчанию список месяцев на русском</div>
            <div>Список месяцев(нужно передавать строго в этом порядке, массивом):</div>
            <div>Воскресенье</div>
            <div>Понедельник</div>
            <div>Вторник</div>
            <div>Среда</div>
            <div>Четверг</div>
            <div>Пятница</div>
            <div>Суббота</div>

            <sb-code language="typescript" [template]="template"></sb-code>

            <ng-template #template>
                <div>TsumDate(new Date()).getDayName()</div>
            </ng-template>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersDateTitle.GetDate, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].date,
                title: TsumHelpersDateTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку date helpers"
        >
            <div header-description>getDate</div>
            <div>Возвращает текущий день</div>

            <sb-code language="typescript" [template]="template"></sb-code>

            <ng-template #template>
                <div>TsumDate(new Date()).getDate() - вернет день</div>
            </ng-template>
        </sb-description-wrapper>
        `
    }));
