import { mathHelpersGlossary } from './tsum-math-helper.constant';
import { storiesOf, moduleMetadata } from '@storybook/angular';
import { TsumTableModule } from '@tsum/ui';
import {
    SbDescriptionWrapperModule,
    TsumCodeHighlighterModule,
    GlossaryModule,
} from '@tsum/storybook';
import {
    TsumHelpersMathTitle,
    StoryKindGroup,
    StoryKind,
} from '../../story-kind.constant';

storiesOf(StoryKind[StoryKindGroup.Helpers].math, module)
    .addDecorator(
        moduleMetadata({
            imports: [
                SbDescriptionWrapperModule,
                TsumTableModule,
                TsumCodeHighlighterModule,
                GlossaryModule,
            ]
        }))
    .add(TsumHelpersMathTitle.Glossary, () => ({
        props: {
            mathHelpersGlossary,
        },
        template: `
            <sb-description-wrapper hideAll>
                <div header-description>Глоссарий math хелперов</div>

                <app-glossary [items]="mathHelpersGlossary" isWithoutGroup></app-glossary>
            </sb-description-wrapper>
        `,
    }))
    .add(TsumHelpersMathTitle.RandomNumber, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].math,
                title: TsumHelpersMathTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку math helpers"
        >
            <div header-description>randomNumber</div>
            <div>
                <div tsumCodeHighlighter>
                    <div>Используется для получения случайного значения</div>
                    <div>*TsumMath.randomNumber(1, 9)* // returns случайное число от 1 до 9</div>
                </div>
            </div>
        </sb-description-wrapper>
        `
    }))
    .add(TsumHelpersMathTitle.GetUniqueId, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].math,
                title: TsumHelpersMathTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку math helpers"
        >
            <div header-description>getUniqueId</div>
            <div>
                <div tsumCodeHighlighter>
                    <div>Используется для получения уникальной строки</div>
                    <div>*TsumMath.getUniqueId()* // returns получим уникальную строку</div>
                </div>
            </div>
        </sb-description-wrapper>
        `
    }));
