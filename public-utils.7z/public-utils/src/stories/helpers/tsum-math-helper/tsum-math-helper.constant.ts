import { Glossary } from '@tsum/storybook';
import { TsumHelpersMathTitle, StoryKindGroup, StoryKind } from '../../story-kind.constant';

export const mathHelpersGlossary: Glossary[] = [
    {
        name: 'randomNumber',
        description: 'Используется для получения случайного числа от и до',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].math,
            title: TsumHelpersMathTitle.RandomNumber,
        },
    },
    {
        name: 'getUniqueId',
        description: 'Используется для получения уникального id',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].math,
            title: TsumHelpersMathTitle.GetUniqueId,
        },
    },
];
