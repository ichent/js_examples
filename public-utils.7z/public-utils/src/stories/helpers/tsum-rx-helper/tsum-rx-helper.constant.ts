import { Glossary } from '@tsum/storybook';
import { TsumHelpersRxTitle, StoryKindGroup, StoryKind } from '../../story-kind.constant';

export const rxHelpersGlossary: Glossary[] = [
    {
        name: 'loadingTo',
        description: 'Используется для изменения сабжектов по загрузке',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].rx,
            title: TsumHelpersRxTitle.LoadingTo,
        },
    },
];
