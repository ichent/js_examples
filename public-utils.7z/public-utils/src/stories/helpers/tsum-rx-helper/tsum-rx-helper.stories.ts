
import { storiesOf, moduleMetadata } from '@storybook/angular';
import { HttpClientModule } from '@angular/common/http';
import { TsumTableModule } from '@tsum/ui';
import {
    SbDescriptionWrapperModule,
    TsumCodeHighlighterModule,
    GlossaryModule,
    SbUtilsModule,
} from '@tsum/storybook';
import {
    StoryKindGroup,
    StoryKind,
    TsumHelpersRxTitle,
} from '../../story-kind.constant';

import { rxHelpersGlossary } from './tsum-rx-helper.constant';

storiesOf(StoryKind[StoryKindGroup.Helpers].rx, module)
    .addDecorator(
        moduleMetadata({
            imports: [
                GlossaryModule,
                HttpClientModule,
                SbDescriptionWrapperModule,
                SbUtilsModule,
                TsumTableModule,
                TsumCodeHighlighterModule,
            ]
        }))
    .add(TsumHelpersRxTitle.Glossary, () => ({
        props: {
            rxHelpersGlossary,
        },
        template: `
            <sb-description-wrapper hideAll>
                <div header-description>Глоссарий rx хелперов</div>

                <app-glossary [items]="rxHelpersGlossary" isWithoutGroup></app-glossary>
            </sb-description-wrapper>
        `,
    }))
    .add(TsumHelpersRxTitle.LoadingTo, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].rx,
                title: TsumHelpersRxTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку math helpers"
        >
            <div header-description>loadingTo</div>
            <div>Используется для изменения сабжектов по загрузке</div>

            <sb-code language="typescript" [template]="template"></sb-code>
            <ng-template #template>
                <div>this.getCard
                            .pipe(
                                loadingTo(this.visiblePreloader$)
                            ).subscribe() // при завершении загрузки изменится статус отображения карточки прелоадера.
                </div>
            </ng-template>
        </sb-description-wrapper>
        `
    }));
