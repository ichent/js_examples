import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TsumTableModule } from '@tsum/ui';
import {
    SbDescriptionWrapperModule,
    ShortExampleModule,
    TsumCodeHighlighterModule,
    SbUtilsModule,
} from '@tsum/storybook';

import {
    TsumPositioningDescriptionComponent
} from './components/tsum-browser-event-description/tsum-browser-event-description.component';
import {
    TsumBrowserEventExampleComponent
} from './examples/tsum-browser-event-example.component';

const COMPONENTS = [
    TsumPositioningDescriptionComponent,
    TsumBrowserEventExampleComponent,
];

@NgModule({
    imports: [
        CommonModule,
        SbDescriptionWrapperModule,
        ShortExampleModule,
        SbUtilsModule,
        TsumTableModule,
        TsumCodeHighlighterModule,
    ],
    declarations: COMPONENTS,
    exports: COMPONENTS,
})
export class TsumBrowserEventServiceModule {}
