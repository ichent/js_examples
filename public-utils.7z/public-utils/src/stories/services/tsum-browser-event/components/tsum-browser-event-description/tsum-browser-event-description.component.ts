import { ChangeDetectionStrategy, Component } from '@angular/core';
import { TsumTable } from '@tsum/ui';

function getTableColumns(titles: string[]): TsumTable.Column<string>[] {
    return titles.map((title, index) => ({
        title,
        render: row => row[index],
    }));
}

@Component({
    selector: 'app-tsum-browser-event-description',
    templateUrl: './tsum-browser-event-description.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumPositioningDescriptionComponent {
    readonly serviceTable = {
        title: 'Интерфейс сервиса TsumPositioningDescriptionStoryComponent',
        columns: getTableColumns(['Свойство', 'Тип', 'Описание']),
        rows: [
            ['scroll$', 'Observable<Event>', 'Событие прокрутки окна'],
            ['resize$', 'Observable<Event>', 'Событие изменения размеров окна'],
            ['delayScroll$', 'Observable<Event>', 'Событие прокрутки окна с установленной задержкой'],
            ['delayResize$', 'Observable<Event>', 'Событие изменения размеров окна с установленной задержкой'],
        ],
    };

    readonly exampleFileName = 'tsum-browser-event-example.component.ts';
}
