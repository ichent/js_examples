import { ChangeDetectionStrategy, Component } from '@angular/core';

import { TsumPlatformEventListenerService } from '@tsum/utils';

import { filter } from 'rxjs/operators';



@Component({
    selector: 'app-tsum-browser-event-example',
    templateUrl: `tsum-browser-event-example.component.html`,
    changeDetection: ChangeDetectionStrategy.OnPush,
})

export class TsumBrowserEventExampleComponent {

    constructor(private browserEventListener: TsumPlatformEventListenerService) {}

    public scroll$ = this.browserEventListener.scroll$.pipe(filter(e => Boolean(e)));
    public resize$ = this.browserEventListener.resize$.pipe(filter(e => Boolean(e)));
}
