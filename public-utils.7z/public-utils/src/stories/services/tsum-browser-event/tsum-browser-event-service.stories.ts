import { storiesOf, moduleMetadata } from '@storybook/angular';
import { TsumBrowserEventServiceModule } from './tsum-browser-event-service.module';
import { StoryKindGroup, StoryKind, BrowserEventTitle } from '../../story-kind.constant';

storiesOf(StoryKind[StoryKindGroup.Services].browserEvent, module)
    .addDecorator(
        moduleMetadata({
            imports: [
                TsumBrowserEventServiceModule,
            ],
        })
    )
    .add(BrowserEventTitle.description, () => ({
        template: `<app-tsum-browser-event-description></app-tsum-browser-event-description>`,
    }));
