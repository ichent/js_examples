import { storiesOf, moduleMetadata } from '@storybook/angular';
import { TsumDeviceOrientationStoriesModule } from './tsum-device-orientation-stories.module';
import { StoryKind, StoryKindGroup, DeviceOrientationTitle } from '../../story-kind.constant';

storiesOf(StoryKind[StoryKindGroup.Services].deviceOrientation, module)
    .addDecorator(
        moduleMetadata({
            imports: [
                TsumDeviceOrientationStoriesModule,
            ],
        })
    )
    .add(DeviceOrientationTitle.description, () => ({
        template: `<app-tsum-device-orientation-description-story></app-tsum-device-orientation-description-story>`,
    }));
