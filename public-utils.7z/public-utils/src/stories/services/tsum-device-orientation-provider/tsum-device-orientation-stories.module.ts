import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TsumTableModule } from '@tsum/ui';
import {
    SbDescriptionWrapperModule,
    ShortExampleModule,
    SbUtilsModule,
    TsumCodeHighlighterModule,
} from '@tsum/storybook';

import {
    TsumDeviceOrientationDescriptionStoryComponent,
} from './components/tsum-device-orientation-description-story/tsum-device-orientation-description-story.component';
import {
    TsumDeviceOrientationBasicExampleComponent,
} from './components/tsum-device-orientation-basic-example/tsum-device-orientation-basic-example.component';


const COMPONENTS = [
    TsumDeviceOrientationDescriptionStoryComponent,
    TsumDeviceOrientationBasicExampleComponent,
];

@NgModule({
    imports: [
        CommonModule,
        SbDescriptionWrapperModule,
        ShortExampleModule,
        SbUtilsModule,
        TsumTableModule,
        TsumCodeHighlighterModule,
    ],
    declarations: COMPONENTS,
    exports: COMPONENTS,
})
export class TsumDeviceOrientationStoriesModule {}
