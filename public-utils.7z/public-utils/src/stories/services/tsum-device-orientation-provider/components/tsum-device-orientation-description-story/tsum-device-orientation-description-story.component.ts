import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
    selector: 'app-tsum-device-orientation-description-story',
    templateUrl: './tsum-device-orientation-description-story.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumDeviceOrientationDescriptionStoryComponent {
    readonly exampleFileName = 'tsum-device-orientation-basic-example.component.ts';
    readonly moduleFileName = 'tsum-device-orientation-stories.module.ts';
}
