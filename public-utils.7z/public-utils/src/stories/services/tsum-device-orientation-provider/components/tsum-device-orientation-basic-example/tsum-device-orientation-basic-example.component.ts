import { fromEvent, Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { ChangeDetectionStrategy, Component, Inject } from '@angular/core';
import {
    TSUM_DEVICE_ORIENTATION_PROVIDER,
    TsumDeviceOrientationProvider,
    TsumDeviceOrientation,
} from '@tsum/utils';

@Component({
    selector: 'app-tsum-device-orientation-basic-example',
    changeDetection: ChangeDetectionStrategy.OnPush,
    template: `Current device orientation is <code>{{ orientation$ | async }}</code>`,
})
export class TsumDeviceOrientationBasicExampleComponent {
    public orientation$: Observable<string> = fromEvent(window, 'orientationchange').pipe(
        map(() => this.getOrientation()),
        startWith(this.getOrientation()),
    );

    constructor(
        @Inject(TSUM_DEVICE_ORIENTATION_PROVIDER)
        private deviceOrientationProvider: TsumDeviceOrientationProvider,
    ) {}

    private getOrientation(): string {
        const value: TsumDeviceOrientation = this.deviceOrientationProvider.get();

        return `TsumDeviceOrientation.${TsumDeviceOrientation[value]}`;
    }
}
