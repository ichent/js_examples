// @ts-nocheck
// tslint:disable
import { NgModule, Optional, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser, isPlatformServer } from '@angular/common';

import { Request } from 'express';
import { REQUEST } from '@nguniversal/express-engine/tokens';

import {
    TSUM_USER_AGENT_PROVIDER,
    TsumUserAgentProviders,
} from '@tsum/utils';

@NgModule({
    providers: [
        {
            provide: TSUM_USER_AGENT_PROVIDER,
            deps: [PLATFORM_ID, [new Optional(), REQUEST]],
            useFactory: (platformId: Object, request?: Request) => {
                if (isPlatformBrowser(platformId)) {
                    return TsumUserAgentProviders.createBrowserProvider();
                } else if (isPlatformServer(platformId)) {
                    return TsumUserAgentProviders.createStaticProvider(request.headers['user-agent'] || '');
                } else {
                    return TsumUserAgentProviders.createStaticProvider('');
                }
            },
        },
    ],
})
export class AppModule {}
