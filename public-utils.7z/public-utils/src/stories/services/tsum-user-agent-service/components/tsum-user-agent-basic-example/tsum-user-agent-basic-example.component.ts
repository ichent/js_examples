import { Component } from '@angular/core';

import {
    TsumUserAgentService,
    TsumUserAgentBrowser,
    TsumUserAgentDevice,
    TsumUserAgentOS,
} from '@tsum/utils';
import { TsumTable } from '@tsum/ui';

type TableRow = [string, string];

@Component({
    selector: 'app-tsum-user-agent-basic-example',
    template: `
        <tsum-table
            [title]="title"
            [columns]="columns"
            [rows]="rows"
        ></tsum-table>
    `,
})
export class TsumUserAgentBasicExampleComponent {
    readonly title = 'Текущий User-Agent';

    readonly columns: TsumTable.Column<TableRow>[] = [
        {
            title: '#',
            render: (row: TableRow) => row[0],
        },
        {
            title: 'Value',
            render: (row: TableRow) => row[1],
        },
    ];

    readonly rows: TableRow[] = [
        ['User-Agent', this.getUserAgent()],
        ['OS', this.getOSDetection()],
        ['Device', this.getDeviceDetection()],
        ['Browser', this.getBrowserDetection()],
    ];

    constructor(
        private userAgentService: TsumUserAgentService,
    ) {}

    public getUserAgent(): string {
        return this.userAgentService.userAgent;
    }

    public getOSDetection(): string {
        const value = this.userAgentService.os.value;

        return value in TsumUserAgentOS
            ? `TsumUserAgentOS.${TsumUserAgentOS[value]}`
            : 'undetected';
    }

    public getDeviceDetection(): string {
        const value = this.userAgentService.device.value;

        return value in TsumUserAgentDevice
            ? `TsumUserAgentDevice.${TsumUserAgentDevice[value]}`
            : 'undetected';
    }

    public getBrowserDetection(): string {
        const value = this.userAgentService.browser.value;

        return value in TsumUserAgentBrowser
            ? `TsumUserAgentBrowser.${TsumUserAgentBrowser[value]}`
            : 'undetected';
    }
}
