import { ChangeDetectionStrategy, Component } from '@angular/core';
import { TsumTable } from '@tsum/ui';

function getTableColumns(titles: string[]): TsumTable.Column<string>[] {
    return titles.map((title, index) => ({
        title,
        render: row => row[index],
    }));
}

@Component({
    selector: 'app-tsum-user-agent-description-story',
    templateUrl: './tsum-user-agent-description-story.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumUserAgentDescriptionStoryComponent {
    readonly serviceTable = {
        title: 'Интерфейс сервиса TsumUserAgentService',
        columns: getTableColumns(['Свойство', 'Тип', 'Описание']),
        rows: [
            ['state', 'TsumUserAgentState', 'Состояние текущего User-Agent'],
            ['userAgent', 'string', 'Псевдоним state.userAgent'],
            ['os', 'TsumUserAgentOSDetection', 'Псевдоним state.os'],
            ['device', 'TsumUserAgentDeviceDetection', 'Псевдоним state.device'],
            ['browser', 'TsumUserAgentBrowserDetection', 'Псевдоним state.browser'],
        ],
    };

    readonly stateTable = {
        title: 'Интерфейс состояния TsumUserAgentState',
        columns: getTableColumns(['Свойство', 'Тип', 'Описание']),
        rows: [
            ['userAgent', 'string', 'Значение User-Agent'],
            ['os', 'TsumUserAgentOSDetection', 'Операционная система (enum TsumUserAgentOS)'],
            ['device', 'TsumUserAgentDeviceDetection', 'Устройство (enum TsumUserAgentDevice)'],
            ['browser', 'TsumUserAgentBrowserDetection', 'Браузер (enum TsumUserAgentBrowser)'],
        ],
    };

    readonly exampleFileName = 'tsum-user-agent-basic-example.component.ts';
    readonly moduleFileName = 'tsum-user-agent-service-stories.module.ts';
}
