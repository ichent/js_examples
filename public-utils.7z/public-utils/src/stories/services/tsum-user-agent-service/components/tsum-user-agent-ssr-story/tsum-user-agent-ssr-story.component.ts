import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
    selector: 'app-tsum-user-agent-ssr-story',
    templateUrl: './tsum-user-agent-ssr-story.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumUserAgentSsrStoryComponent {
    readonly exampleFileName = 'tsum-user-agent-ssr.example.ts';
}
