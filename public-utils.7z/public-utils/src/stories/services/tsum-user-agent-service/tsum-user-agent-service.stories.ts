import { storiesOf, moduleMetadata } from '@storybook/angular';
import { TsumUserAgentServiceStoriesModule } from './tsum-user-agent-service-stories.module';
import { StoryKind, StoryKindGroup, UserAgentTitle } from '../../story-kind.constant';

storiesOf(StoryKind[StoryKindGroup.Services].userAgent, module)
    .addDecorator(
        moduleMetadata({
            imports: [
                TsumUserAgentServiceStoriesModule,
            ],
        })
    )
    .add(UserAgentTitle.description, () => ({
        template: `<app-tsum-user-agent-description-story></app-tsum-user-agent-description-story>`,
    }))
    .add(UserAgentTitle.settingSsr, () => ({
        template: `<app-tsum-user-agent-ssr-story></app-tsum-user-agent-ssr-story>`,
    }));
