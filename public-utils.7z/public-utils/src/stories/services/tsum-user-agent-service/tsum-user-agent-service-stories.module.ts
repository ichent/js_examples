import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TsumTableModule } from '@tsum/ui';

import {
    TsumUserAgentDescriptionStoryComponent,
} from './components/tsum-user-agent-description-story/tsum-user-agent-description-story.component';
import {
    TsumUserAgentBasicExampleComponent,
} from './components/tsum-user-agent-basic-example/tsum-user-agent-basic-example.component';
import {
    TsumUserAgentSsrStoryComponent,
} from './components/tsum-user-agent-ssr-story/tsum-user-agent-ssr-story.component';
import {
    SbDescriptionWrapperModule,
    ShortExampleModule,
    SbUtilsModule,
    TsumCodeHighlighterModule,
} from '@tsum/storybook';


const COMPONENTS = [
    TsumUserAgentDescriptionStoryComponent,
    TsumUserAgentSsrStoryComponent,
    TsumUserAgentBasicExampleComponent,
];

@NgModule({
    imports: [
        CommonModule,
        SbDescriptionWrapperModule,
        ShortExampleModule,
        SbUtilsModule,
        TsumTableModule,
        TsumCodeHighlighterModule,
    ],
    declarations: COMPONENTS,
    exports: COMPONENTS,
})
export class TsumUserAgentServiceStoriesModule {}
