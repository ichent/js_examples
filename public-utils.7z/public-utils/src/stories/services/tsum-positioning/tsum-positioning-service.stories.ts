import { storiesOf, moduleMetadata } from '@storybook/angular';
import { TsumPositioningServiceModule } from './tsum-positioning-service.module';
import { StoryKind, StoryKindGroup, PositioningTitle } from '../../story-kind.constant';

storiesOf(StoryKind[StoryKindGroup.Services].positioning, module)
    .addDecorator(
        moduleMetadata({
            imports: [
                TsumPositioningServiceModule,
            ],
        })
    )
    .add(PositioningTitle.description, () => ({
        template: `<app-tsum-positioning-description></app-tsum-positioning-description>`,
    }));
