export namespace TsumPositioningPopup {
    export type Direction = 'top' | 'bottom' | 'left' | 'right';
    export type Align = 'auto' | 'fixed';
    export interface Config  {
        offset: number;
        borderRadius: number;
        arrowWidth: number;
        preferablePosition: Direction;
        align: Align;
        component: any;
        props?: { [id: string]: any };
    }
}
