import { DOCUMENT } from '@angular/common';
import {
    Directive,
    ElementRef,
    ComponentRef,
    ViewContainerRef,
    HostListener,
    OnDestroy,
    Input,
    Inject,
} from '@angular/core';

import {
    TsumPlatformEventListenerService,
    TsumPositioningService,
    TsumPositioning,
    TsumBrowserEvents,
} from '@tsum/utils';

import { Subject, Observable, combineLatest, merge, fromEvent } from 'rxjs';
import { takeUntil, map } from 'rxjs/operators';

import { TsumPositioningPopup } from './positioning.namespace';
import { TsumDynamicComponentsService } from '@tsum/utils';

/** @Todo взять компонент из приватного кита */

@Directive({
    selector: '[appDynamicPositioningPopup]',
})
export class TsumDynamicPositioningPopupDirective implements OnDestroy {
    @Input('appDynamicPositioningPopup')
    public config: TsumPositioningPopup.Config;
    private destroyed$ = new Subject<void>();
    private componentRef: ComponentRef<any>;
    private alignedPosition: TsumPositioning.Direction;

    private browserScreenEvents$: Observable<[Event, TsumBrowserEvents.ScrollEvent]> = combineLatest([
        this.tsumEventEmitterService.delayResize$,
        this.tsumEventEmitterService.delayScroll$.pipe(
            map(
                e => {

                    const boundingClientRect: DOMRect = this.document.body.getBoundingClientRect() as DOMRect;
                    return {
                        scrollTop: boundingClientRect.top,
                        width: boundingClientRect.width,
                        height: boundingClientRect.height,
                    };
                })
        ),
    ]);

    @HostListener('click', ['$event'])
    public clickByDirective(event: MouseEvent): void {
        if (!this.componentRef) {
            this.openDownload();
            return;
        }

        if (event.target === this.el.nativeElement) {
            this.destroyDownload();
        }
    }

    constructor(
        private el: ElementRef,
        private tsumDynamicComponentsService: TsumDynamicComponentsService,
        private viewContainer: ViewContainerRef,
        private tsumUtilsPositioningService: TsumPositioningService,
        @Inject(DOCUMENT) private document: any,
        private tsumEventEmitterService: TsumPlatformEventListenerService,
    ) { }

    private openDownload(): void {
        this.componentRef = this.tsumDynamicComponentsService.createChildComponent(
            this.config.component,
            this.viewContainer,
        );

        this.el.nativeElement.style.position = 'relative';
        this.componentRef.location.nativeElement.style.position = 'absolute';

        this.setPosition();
        this.setProps();

        merge(
            this.browserScreenEvents$,
            fromEvent(this.componentRef.location.nativeElement, 'click'),
        )
            .pipe(takeUntil(this.destroyed$))
            .subscribe(() => this.setPosition());

        this.componentRef.instance.closeDownload$
            .pipe(takeUntil(this.destroyed$))
            .subscribe(() => this.destroyDownload());
    }

    private destroyDownload(): void {
        if (this.componentRef) {
            this.componentRef.destroy();
            this.componentRef = undefined;
        }
    }

    public ngOnDestroy(): void {
        this.destroyDownload();

        this.destroyed$.next();
        this.destroyed$.complete();
    }

    private setPosition(): void {
        const isElementsExists: boolean = (this.componentRef && this.componentRef.location.nativeElement);
        const isTooltipCanAligned: boolean = (this.config.align !== 'fixed');

        if (isElementsExists && isTooltipCanAligned) {
            this.tsumUtilsPositioningService.positioning({
                offset: this.config.offset,
                preferablePosition: this.config.preferablePosition,
                arrowWidth: this.config.arrowWidth,
                borderRadius: this.config.borderRadius,
                popup: this.componentRef.location.nativeElement,
                parent: this.el.nativeElement,
                after: side => this.alignedPosition = side,
            });
        }
    }

    private setProps(): void {
        if (this.config.hasOwnProperty('props')) {
            Object.keys(this.config.props).forEach(key => this.componentRef.instance[key] = this.config.props[key]);
        }
    }
}
