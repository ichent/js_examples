import { ChangeDetectionStrategy, Component } from '@angular/core';
import { TsumDynamicExampleComponent } from '../../components/tsum-dynamic/tsum-dynamic-example.component';
import { TsumPositioningPopup } from '../../directives/positioning.namespace';

@Component({
    selector: 'app-tsum-positioning-example',
    templateUrl: `tsum-positioning-example.component.html`,
    styleUrls: [`tsum-positioning-example.component.scss`],
    changeDetection: ChangeDetectionStrategy.OnPush,
})

export class TsumPositioningExampleComponent {

    public config: TsumPositioningPopup.Config = {
        offset: 0,
        preferablePosition: 'bottom',
        arrowWidth: 0,
        borderRadius: 0,
        component: TsumDynamicExampleComponent,
        align: 'auto',
    };
}
