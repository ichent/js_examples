import { Component } from '@angular/core';
import { TsumPositioningPopup } from '../../directives/positioning.namespace';
import {
    TsumDynamicFixComponentComponent
} from '../../components/tsum-dynamic-fix-component/tsum-dynamic-fix-component.component';

@Component({
    selector: 'app-tsum-fix-positioning-example',
    templateUrl: './tsum-fix-positioning-example.component.html',
    styleUrls: ['./tsum-fix-positioning-example.component.scss']
})
export class TsumDecorPositioningExampleComponent {
    public config: TsumPositioningPopup.Config = {
        offset: 30,
        preferablePosition: 'top',
        arrowWidth: 0,
        borderRadius: 0,
        component: TsumDynamicFixComponentComponent,
        align: 'fixed',
    };
}
