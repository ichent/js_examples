import { ElementRef } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { skip, delay } from 'rxjs/operators';

/** @Todo взять компонент из приватного кита */

export class TsumDynamicBaseComponent {

    constructor(public el: ElementRef) { }
    private closeDownloadSubject$ = new BehaviorSubject<void>(null);
    public closeDownload$: Observable<void> = this.closeDownloadSubject$.asObservable()
        .pipe(
            skip(1),
            delay(100),
        );

}
