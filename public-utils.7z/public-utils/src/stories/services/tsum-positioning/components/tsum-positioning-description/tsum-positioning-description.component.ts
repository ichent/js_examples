import { ChangeDetectionStrategy, Component } from '@angular/core';
import { TsumTable } from '@tsum/ui';

function getTableColumns(titles: string[]): TsumTable.Column<string>[] {
    return titles.map((title, index) => ({
        title,
        render: row => row[index],
    }));
}

@Component({
    selector: 'app-tsum-positioning-description',
    templateUrl: './tsum-positioning-description.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumPositioningDescriptionComponent {
    readonly serviceTable = {
        title: 'Интерфейс сервиса TsumPositioningService',
        columns: getTableColumns(['Свойство', 'Тип', 'Описание']),
        rows: [
            ['positioning', 'TsumPositioning.PositionSetup', 'Метод для установки позиции']
        ],
    };

    readonly exampleFileName = 'tsum-dynamic-example.directive.ts';
}
