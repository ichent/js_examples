import { Component, ElementRef } from '@angular/core';
import { TsumDynamicBaseComponent } from '../../tsum-dynamic-base/tsum-dynamic-base.component';

@Component({
    selector: 'app-tsum-dynamic-fix-component',
    templateUrl: './tsum-dynamic-fix-component.component.html',
    styleUrls: ['./tsum-dynamic-fix-component.component.styl']
})
export class TsumDynamicFixComponentComponent extends TsumDynamicBaseComponent {
    constructor(public el: ElementRef) {
        super(el);
    }
}
