import { ChangeDetectionStrategy, Component, ElementRef } from '@angular/core';
import { TsumDynamicBaseComponent } from '../../tsum-dynamic-base/tsum-dynamic-base.component';

@Component({
    selector: 'app-dynamic-example',
    templateUrl: './tsum-dynamic-example.component.html',
    styleUrls: ['./tsum-dynamic-example.component.styl'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumDynamicExampleComponent extends TsumDynamicBaseComponent {
    constructor(public el: ElementRef){
        super(el);
    }
}
