import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TsumTableModule } from '@tsum/ui';
import {
    SbDescriptionWrapperModule,
    ShortExampleModule,
    SbUtilsModule,
    TsumCodeHighlighterModule,
} from '@tsum/storybook';

import {
    TsumPositioningDescriptionComponent
} from './components/tsum-positioning-description/tsum-positioning-description.component';
import {
    TsumPositioningExampleComponent
} from './examples/tsum-positioning-example.component/tsum-positioning-example.component';
import {
    TsumDecorPositioningExampleComponent
} from './examples/tsum-fix-positioning-example/tsum-fix-positioning-example.component';

import { TsumDynamicExampleComponent } from './components/tsum-dynamic/tsum-dynamic-example.component';
import { TsumDynamicPositioningPopupDirective } from './directives/tsum-dynamic-example.directive';
import { TsumDynamicFixComponentComponent } from './components/tsum-dynamic-fix-component/tsum-dynamic-fix-component.component';
import { TsumDynamicComponentsService } from '@tsum/utils';

const COMPONENTS = [
    TsumDecorPositioningExampleComponent,
    TsumPositioningDescriptionComponent,
    TsumPositioningExampleComponent,
    TsumDynamicExampleComponent,
    TsumDynamicFixComponentComponent,
    TsumDynamicPositioningPopupDirective,
];

@NgModule({
    imports: [
        CommonModule,
        SbDescriptionWrapperModule,
        ShortExampleModule,
        SbUtilsModule,
        TsumTableModule,
        TsumCodeHighlighterModule,
    ],
    declarations: COMPONENTS,
    exports: COMPONENTS,
    entryComponents: [
        TsumDynamicExampleComponent,
        TsumDynamicFixComponentComponent,
    ],
    providers: [ TsumDynamicComponentsService ],
})
export class TsumPositioningServiceModule {}
