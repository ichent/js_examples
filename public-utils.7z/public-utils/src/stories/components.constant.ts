import { UserAgentTitle } from './story-kind.constant';
import { Glossary } from '@tsum/storybook';
import {
    StoryKind,
    StoryKindGroup,
    BrowserEventTitle,
    DeviceOrientationTitle,
    PositioningTitle,
} from './story-kind.constant';
import { TsumClassHelpers } from './helpers/tsum-class-helper/tsum-class-helper.constant';
import { TsumDateHelpersGlossary } from './helpers/tsum-date-helper/tsum-date-helper.constant';
import { TsumGeneralHelpersGlossary } from './helpers/tsum-general-helper/tsum-general-helper.constant';
import { mathHelpersGlossary } from './helpers/tsum-math-helper/tsum-math-helper.constant';
import { TsumDecoratorsGlossary } from './decorators/tsum-decorators.constant';

export const glossaryComponents: Glossary[] = [
    /**
     * Start services
     */
    {
        name: 'tsum-browser-event',
        description: 'Сервис для подписки на скролл/ресайз и других глобальных событий',
        link: {
            kind: StoryKind[StoryKindGroup.Services].browserEvent,
            title: BrowserEventTitle.description,
        },
    },
    {
        name: 'tsum-device-orientation',
        description: 'Сервис для определения ориентации устройства',
        link: {
            kind: StoryKind[StoryKindGroup.Services].browserEvent,
            title: DeviceOrientationTitle.description,
        },
    },
    {
        name: 'tsum-positioning',
        description: 'Сервис для определения расположения элемента относительно текущего',
        link: {
            kind: StoryKind[StoryKindGroup.Services].positioning,
            title: PositioningTitle.description,
        },
    },
    {
        name: 'tsum-user-agent',
        description: 'Описание сервиса для разбора User-Agent',
        link: {
            kind: StoryKind[StoryKindGroup.Services].userAgent,
            title: UserAgentTitle.description,
        },
    },
    /**
     * End services
     */

    ...TsumClassHelpers,
    ...TsumDateHelpersGlossary,
    ...TsumGeneralHelpersGlossary,
    ...mathHelpersGlossary,
    ...TsumDecoratorsGlossary,
];
