import { TsumDecoratorsGlossary } from './tsum-decorators.constant';
import { storiesOf, moduleMetadata } from '@storybook/angular';
import { HttpClientModule } from '@angular/common/http';
import { TsumTableModule } from '@tsum/ui';
import {
    SbDescriptionWrapperModule,
    TsumCodeHighlighterModule,
    GlossaryModule,
    SbUtilsModule,
} from '@tsum/storybook';
import { TsumDecoratorsTitle, StoryKindGroup, StoryKind } from '../story-kind.constant';

storiesOf(StoryKind[StoryKindGroup.Helpers].decorator, module)
    .addDecorator(
        moduleMetadata({
            imports: [
                HttpClientModule,
                SbDescriptionWrapperModule,
                SbUtilsModule,
                TsumTableModule,
                TsumCodeHighlighterModule,
                GlossaryModule,
            ]
        }))
    .add(TsumDecoratorsTitle.Glossary, () => ({
        props: {
            TsumDecoratorsGlossary,
        },
        template: `
            <sb-description-wrapper hideAll>
                <div header-description>Глоссарий декораторов</div>

                <app-glossary [items]="TsumDecoratorsGlossary" isWithoutGroup></app-glossary>
            </sb-description-wrapper>
        `,
    }))
    .add(TsumDecoratorsTitle.Input, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].decorator,
                title: TsumDecoratorsTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку декораторов"
        >
            <div header-description>TsumInputDecorator</div>
            <div>
                <div class="h2 mv-md">About</div>
                <div>Данный декоратор используется для angular input</div>
                <div>Он проверяет на наличие инпута в вашем компоненте, и возвращает флаг</div>
                <div>Используется когда вы хотите добавить к компоненту инпут без квадратных скобок, декоратор вернет true</div>

                <div class="h2 mv-md">How to</div>
                <div>@TsumInputDecorator() пишем перед @Input</div>

                <div class="h2 mv-md">Examples</div>
                <sb-code language="typescript" [template]="template"></sb-code>

                <ng-template #template>
                    <div>@TsumInputDecorator()</div>
                    <div>@Input()</div>
                    <div>@public isSmall = false</div>
                </ng-template>
            </div>
        </sb-description-wrapper>
        `
    }))
    .add(TsumDecoratorsTitle.Delay, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].decorator,
                title: TsumDecoratorsTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку декораторов"
        >
            <div header-description>TsumDelayDecorator</div>
            <div>
                <div class="h2 mv-md">TsumDelayDecorator</div>
                <div>Данный декоратор используется для задержки вызова функции</div>
                <div>Принимает количество милисекунд на входе, по умолчанию 300</div>

                <div class="h2 mv-md">Examples</div>

                <sb-code language="typescript" [template]="template"></sb-code>

                <ng-template #template>
                    <div>@TsumDelayDecorator()</div>
                    <div>@HostListener('click')</div>
                    <div>@public handleClick()</div>
                </ng-template>
            </div>
        </sb-description-wrapper>
        `
    }))
    .add(TsumDecoratorsTitle.Debounce, () => ({
        props: {
            backUrl: {
                kind: StoryKind[StoryKindGroup.Helpers].decorator,
                title: TsumDecoratorsTitle.Glossary,
            },
        },
        template: `
        <sb-description-wrapper
            hideAll
            [backUrl]="backUrl"
            backText="К списку декораторов"
        >
            <div header-description>TsumDebounceDecorator</div>
            <div>
                <div>Данный декоратор используется для debounce вызова функции</div>
                <div>Принимает количество милисекунд на входе, по умолчанию 300</div>

                <div class="h2 mv-md">Examples</div>

                <sb-code language="typescript" [template]="template"></sb-code>

                <ng-template #template>
                    <div>@TsumDebounceDecorator(10)</div>
                    <div>@HostListener('click')</div>
                    <div>@public handleClick()</div>
                </ng-template>
            </div>
        </sb-description-wrapper>
        `
    }));
