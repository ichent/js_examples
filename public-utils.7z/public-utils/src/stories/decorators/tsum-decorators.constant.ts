import { Glossary } from '@tsum/storybook';
import {
    TsumDecoratorsTitle,
    StoryKindGroup,
    StoryKind,
} from '../story-kind.constant';

export const TsumDecoratorsGlossary: Glossary[] = [
    {
        name: 'TsumInputDecorator',
        description: 'Используется для инпутов, проверяет активен ли инпут, возвращает true/false в зависимости от аттрибута',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].decorator,
            title: TsumDecoratorsTitle.Input,
        },
    },
    {
        name: 'TsumDelayDecorator',
        description: 'Используется для задержки вызова функции',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].decorator,
            title: TsumDecoratorsTitle.Delay,
        },
    },
    {
        name: 'Debounce',
        description: 'Используется для debounce вашей функции',
        link: {
            kind: StoryKind[StoryKindGroup.Helpers].decorator,
            title: TsumDecoratorsTitle.Debounce,
        },
    },
];
