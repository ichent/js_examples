import { glossaryComponents } from './components.constant';
import { storiesOf, moduleMetadata } from '@storybook/angular';
import { SbDescriptionWrapperModule, GlossaryModule } from '@tsum/storybook';

import { StoryKind, StoryKindGroup, AwesomeStartTitle } from './story-kind.constant';

storiesOf(StoryKind[StoryKindGroup.AwesomeStart].intro, module)
    .addDecorator(
        moduleMetadata({
            imports: [
                SbDescriptionWrapperModule,
                GlossaryModule,
            ],
        })
    )
    .add(AwesomeStartTitle.Glossary, () => ({
        props: {
            glossaryComponents,
        },
        template: `
            <sb-description-wrapper hideAll>
                <div header-description>Глоссарий компонентов</div>

                <app-glossary [items]="glossaryComponents"></app-glossary>
            </sb-description-wrapper>
        `,
    }));
