export enum StoryKindGroup {
    Utils = 'Utils',
    Services = 'Services',
    AwesomeStart = 'Awesome Start',
    Helpers = 'Helpers',
}

export const StoryKind = {
    [StoryKindGroup.Utils]: {
        badge: `${StoryKindGroup.Utils}|Badge`,
        descriptionWrapper: `${StoryKindGroup.Utils}|Description wrapper`,
    },
    [StoryKindGroup.AwesomeStart]: {
        intro: `${StoryKindGroup.AwesomeStart}|Intro`,
        instruction: `${StoryKindGroup.AwesomeStart}|Intro`,
    },
    [StoryKindGroup.Services]: {
        browserEvent: `${StoryKindGroup.Services}|Broswer Event`,
        deviceOrientation: `${StoryKindGroup.Services}|Device orientation`,
        positioning: `${StoryKindGroup.Services}|Positioning`,
        userAgent: `${StoryKindGroup.Services}|User-Agent`,
    },
    [StoryKindGroup.Helpers]: {
        classes: `${StoryKindGroup.Helpers}|Classes`,
        date: `${StoryKindGroup.Helpers}|Date`,
        general: `${StoryKindGroup.Helpers}|General`,
        math: `${StoryKindGroup.Helpers}|Math`,
        decorator: `${StoryKindGroup.Helpers}|Decorator`,
        form: `${StoryKindGroup.Helpers}|Form`,
        rx: `${StoryKindGroup.Helpers}|Rx`,
    },
};

export enum AwesomeStartTitle {
    Glossary = 'Glossary',
    Testing = 'Testing',
}

export const DefaultTitle = {
    default: 'Default',
};

export const CodeTitle = {
    default: 'Default',
};

export const BadgeTitle = {
    single: 'single',
    list: 'list',
};

export const BrowserEventTitle = {
    description: 'Description',
};

export const DeviceOrientationTitle = {
    description: 'Description',
};

export const PositioningTitle = {
    description: 'Description',
};

export const UserAgentTitle = {
    description: 'Description',
    settingSsr: 'Setting SSR',
};

export enum TsumHelpersClassesTitle {
    Glossary = 'Glossary',
    General = 'General',
    PaddingsMargins = 'Paddings and Margins',
    Colors = 'Colors',
    Borders = 'Borders',
    Layout = 'Layout',
    Position = 'Position',
    Overflow = 'Overflow',
    WhiteSpace = 'White space',
    Cursor = 'Cursor',
    HeightWeight = 'Height & Width',
    Typography = 'Typography',
}

export enum TsumHelpersDateTitle {
    Glossary = 'Glossary',
    General = 'General',
    RealMonthNumber = 'Real Month Number',
    CompleteDate = 'Complete Date',
    Format = 'Format',
    IsSame = 'Is Same',
    IsAfter = 'Is After',
    IsBefore = 'Is Before',
    IsBetween = 'Is Between',
    GetPrevFullYear = 'Get prev full year',
    GetNextFullYear = 'Get next full year',
    GetFirstMonthByYear = 'Get First Month By Year',
    GetYear = 'Get Year',
    GetNextMonth = 'Get Next Month',
    GetPrevMonth = 'Get Prev Month',
    GetLastDayByMonth = 'Get Last Day By Month',
    GetMonthName = 'Get Month Name',
    GetShortMonthName = 'Get Short Month Name',
    GetNextDay = 'Get Next Day',
    GetPrevDay = 'Get Prev Day',
    GetDayName = 'Get Day Name',
    GetDate = 'Get Date',
}

export enum TsumHelpersGeneralTitle {
    Glossary = 'glossary',
    IsPropertyActive = 'isPropertyActive',
    InvertNumber = 'invertNumber',
    RangeArray = 'rangeArray',
    IsNotNull = 'isNotNull',
    IsObject = 'isObject',
    IsEqual = 'isEqual',
    IsMatch = 'isMatch',
    Pipe = 'pipe',
    IsIntString = 'isIntString',
    IsArrayLike = 'isArrayLike',
    IsEmpty = 'isEmpty',
    DefaultTo = 'defaultTo',
    OmitBy = 'omitBy',
    OmitUndefined = 'omitUndefined',
}

export enum TsumHelpersMathTitle {
    Glossary = 'glossary',
    RandomNumber = 'randomNumber',
    GetUniqueId = 'getUniqueId',
}

export enum TsumHelpersRxTitle {
    Glossary = 'glossary',
    LoadingTo = 'loadingTo',
}

export enum TsumHelpersFormTitle {
    Glossary = 'glossary',
    ControlValueObservable = 'controlValueObservable',
    ControlForEach = 'controlForEach',
    AddControlErrors = 'addControlErrors',
}

export enum TsumDecoratorsTitle {
    Glossary = 'Glossary',
    Input = 'Input',
    Delay = 'Delay',
    Debounce = 'Debounce',
}
