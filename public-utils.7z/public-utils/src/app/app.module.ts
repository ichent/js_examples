import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { TsumDynamicComponentsService, TsumIconDefinitionsComponent } from '@tsum/ui';
import { STORY_KIND, STORY_KIND_GROUP, TITLE } from '@tsum/storybook';

import { AppComponent } from './app.component';
import { StoryKind, StoryKindGroup, DefaultTitle } from 'src/stories/story-kind.constant';

@NgModule({
    declarations: [
        AppComponent
    ],
    imports: [
        BrowserModule,
    ],
    providers: [
        {
            provide: STORY_KIND,
            useValue: StoryKind,
        },
        {
            provide: STORY_KIND_GROUP,
            useValue: StoryKindGroup,
        },
        {
            provide: TITLE,
            useValue: DefaultTitle,
        },
    ],
    bootstrap: [AppComponent],
    entryComponents: [
        TsumIconDefinitionsComponent,
    ],
})
export class AppModule {
    constructor(
        private tsumDynamicComponentsService: TsumDynamicComponentsService,
    ) {
        this.tsumDynamicComponentsService.createComponent(TsumIconDefinitionsComponent);
    }
}
