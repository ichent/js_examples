import { TsumTable } from '@tsum/ui';
import { TsumInputBinding } from '@tsum/storybook';

export const tsumColumns: TsumTable.Column<TsumInputBinding>[] = [
    {
        title: 'Название инпута',
        name: 'title',
        render: (row: TsumInputBinding) => row.title || ''
    },
    {
        title: 'Описание',
        name: 'description',
        render: (row: TsumInputBinding) => row.description || ''
    },
];

export const TsumColumnsDefault: TsumTable.Column<TsumInputBinding>[] = [
    {
        title: 'Название',
        name: 'title',
        render: (row: TsumInputBinding) => row.title || ''
    },
    {
        title: 'Описание',
        name: 'description',
        render: (row: TsumInputBinding) => row.description || ''
    },
];
