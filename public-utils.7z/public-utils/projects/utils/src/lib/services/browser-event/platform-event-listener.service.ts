import {
    PLATFORM_ID,
    Injectable,
} from '@angular/core';

import { Observable } from 'rxjs';
import { TsumBrowserEvents } from './platform-event-listener.namespace';
import { TSUM_BROWSER_EVENTS_DELAY_TIME, TsumBrowserEventsService } from './browser-events.service';
import { isPlatformBrowser } from '@angular/common';
import { TsumDummyBrowserEventsService } from './dummy-browser-events.service';

export function browserEventsFactory(platformId: any, delay: number): TsumBrowserEvents.ServiceInterface {

    return isPlatformBrowser(platformId)
        ? new TsumBrowserEventsService(delay)
        : new TsumDummyBrowserEventsService();
}

@Injectable({
    providedIn: 'root',
    deps: [ PLATFORM_ID, TSUM_BROWSER_EVENTS_DELAY_TIME ],
    useFactory: browserEventsFactory,
})
/** Сервис взаимодействия с событиями окна браузера */
export class TsumPlatformEventListenerService implements TsumBrowserEvents.ServiceInterface {
    public readonly scroll$: Observable<Event>;
    public readonly resize$: Observable<Event>;
    public readonly delayScroll$: Observable<Event>;
    public readonly delayResize$: Observable<Event>;
}
