import { Inject, InjectionToken } from '@angular/core';
import { fromEvent, Observable } from 'rxjs';
import { debounceTime, share } from 'rxjs/operators';
import { TsumBrowserEvents } from './platform-event-listener.namespace';

/**
 * @description Наличие export и функций вида Function Declaration обуславливается
 * https://angular.io/guide/aot-metadata-errors#function-calls-are-not-supported
 */

export function browserEventsDelayTimeFactory() {
    return 200;
}

export const TSUM_BROWSER_EVENTS_DELAY_TIME = new InjectionToken('tsum.browser-events.delay-time', {
    providedIn: 'root',
    factory: browserEventsDelayTimeFactory
});

export class TsumBrowserEventsService implements TsumBrowserEvents.ServiceInterface {
    public readonly scroll$: Observable<Event> = fromEvent(window, 'scroll');
    public readonly resize$: Observable<Event> = fromEvent(window, 'resize');
    public readonly delayScroll$: Observable<Event> = this.delayed(this.scroll$);
    public readonly delayResize$: Observable<Event> = this.delayed(this.resize$);
    public constructor(
        @Inject(TSUM_BROWSER_EVENTS_DELAY_TIME) private delayTime: number
    ) { }

    private delayed<T>(observable: Observable<T>): Observable<T> {
        return observable.pipe(
            debounceTime(this.delayTime),
            share(),
        );
    }
}
