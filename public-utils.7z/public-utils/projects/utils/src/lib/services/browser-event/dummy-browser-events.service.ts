import { TsumBrowserEvents } from './platform-event-listener.namespace';
import { Observable, EMPTY } from 'rxjs';

/** Сервис взаимодействия с событиями других платформ */
export class TsumDummyBrowserEventsService implements TsumBrowserEvents.ServiceInterface {
    public readonly scroll$: Observable<Event> = EMPTY;
    public readonly resize$: Observable<Event> = EMPTY;
    public readonly delayScroll$: Observable<Event> = EMPTY;
    public readonly delayResize$: Observable<Event> = EMPTY;
}
