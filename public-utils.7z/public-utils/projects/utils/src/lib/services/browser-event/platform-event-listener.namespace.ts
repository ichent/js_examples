import { Observable } from 'rxjs';

export namespace TsumBrowserEvents {
    export interface ScrollEvent {
        scrollTop: number;
        width: number;
        height: number;
    }

    export interface ServiceInterface {
        readonly scroll$: Observable<Event>;
        readonly resize$: Observable<Event>;
        readonly delayScroll$: Observable<Event>;
        readonly delayResize$: Observable<Event>;
    }
}
