export namespace TsumPositioning {
    /** Направления в которых может быть выровнен элемент */
    export enum Direction {
        Top = 'top',
        TopRight = 'topRight',
        TopLeft = 'topLeft',
        Bottom = 'bottom',
        BottomRight = 'bottomRight',
        BottomLeft = 'bottomLeft',
        Left = 'left',
        LeftCorner = 'leftCorner',
        Right = 'right',
        RightCorner = 'rightCorner',
    }

    /** Тип выравнивания, auto - выравнивает если не влезает элемент, fixed - всегда статично */
    export type AlignType = 'auto' | 'fixed';

    /** Список необходимого для выравнивания */
    export interface PositionSetup {
        popup: HTMLElement;
        parent: HTMLElement;
        offset: number;
        borderRadius?: number;
        arrowWidth?: number;
        alignType?: AlignType;
        preferablePositions: Direction[];
        after: (direction: Direction) => void;
    }

    function isHasBottomPlace(tooltipRect: ClientRect, parentRect: ClientRect, offset: number): boolean {
        return (parentRect.bottom + offset + tooltipRect.height) < window.innerHeight;
    }

    function isHasBottomRightPlace(tooltipRect: ClientRect, parentRect: ClientRect, offset: number): boolean {
        return isHasBottomPlace(tooltipRect, parentRect, offset)
            && isHasRightPlace(tooltipRect, parentRect, offset);
    }

    function isHasBottomLeftPlace(tooltipRect: ClientRect, parentRect: ClientRect, offset: number): boolean {
        return isHasBottomPlace(tooltipRect, parentRect, offset)
            && isHasLeftPlace(tooltipRect, parentRect, offset);
    }

    function isHasTopPlace(tooltipRect: ClientRect, parentRect: ClientRect, offset: number): boolean {
        return parentRect.top > (tooltipRect.height + offset);
    }

    function isHasTopRightPlace(tooltipRect: ClientRect, parentRect: ClientRect, offset: number): boolean {
        return isHasTopPlace(tooltipRect, parentRect, offset)
            && isHasRightPlace(tooltipRect, parentRect, offset);
    }

    function isHasTopLeftPlace(tooltipRect: ClientRect, parentRect: ClientRect, offset: number): boolean {
        return isHasTopPlace(tooltipRect, parentRect, offset)
            && isHasLeftPlace(tooltipRect, parentRect, offset);
    }

    function isHasLeftPlace(tooltipRect: ClientRect, parentRect: ClientRect, offset: number): boolean {
        return parentRect.left > (tooltipRect.width + offset);
    }

    function isHasRightPlace(tooltipRect: ClientRect, parentRect: ClientRect, offset: number): boolean {
        return (parentRect.right + tooltipRect.width + offset) < window.innerWidth;
    }

    /** Набор методов для определения направления выравнивания */
    export const DIRECTION_ADJUSTMENT = {
        bottom(tooltipRect: ClientRect, parentRect: ClientRect, offset: number): boolean {
            return isHasBottomPlace(tooltipRect, parentRect, offset)
                && isHasLeftPlace(tooltipRect, parentRect, offset)
                && isHasRightPlace(tooltipRect, parentRect, offset);
        },

        top(tooltipRect: ClientRect, parentRect: ClientRect, offset: number): boolean {
            return isHasTopPlace(tooltipRect, parentRect, offset)
                && isHasLeftPlace(tooltipRect, parentRect, offset)
                && isHasRightPlace(tooltipRect, parentRect, offset);
        },

        bottomRight(tooltipRect: ClientRect, parentRect: ClientRect, offset: number): boolean {
            return isHasBottomPlace(tooltipRect, parentRect, offset)
                && isHasBottomRightPlace(tooltipRect, parentRect, offset);
        },

        bottomLeft(tooltipRect: ClientRect, parentRect: ClientRect, offset: number): boolean {
            return isHasBottomPlace(tooltipRect, parentRect, offset)
                && isHasBottomLeftPlace(tooltipRect, parentRect, offset);
        },

        topRight(tooltipRect: ClientRect, parentRect: ClientRect, offset: number): boolean {
            return isHasTopPlace(tooltipRect, parentRect, offset)
                && isHasTopRightPlace(tooltipRect, parentRect, offset);
        },

        topLeft(tooltipRect: ClientRect, parentRect: ClientRect, offset: number): boolean {
            return isHasTopPlace(tooltipRect, parentRect, offset)
                && isHasTopLeftPlace(tooltipRect, parentRect, offset);
        },

        right(tooltipRect: ClientRect, parentRect: ClientRect, offset: number): boolean {
            return isHasRightPlace(tooltipRect, parentRect, offset);
        },

        rightCorner(tooltipRect: ClientRect, parentRect: ClientRect, offset: number): boolean {
            return isHasRightPlace(tooltipRect, parentRect, offset);
        },

        left(tooltipRect: ClientRect, parentRect: ClientRect, offset: number): boolean {
            return isHasLeftPlace(tooltipRect, parentRect, offset);
        },

        leftCorner(tooltipRect: ClientRect, parentRect: ClientRect, offset: number): boolean {
            return isHasLeftPlace(tooltipRect, parentRect, offset);
        },
    };

    /** Константа сводит к минимуму вероятность появления зазора между декоративным псевдоэлементом и блоком */
    const TRIM_SIZE = 2;

    /** Обрабатывает исключение, когда элемент находится слева/справа и его нужно сдвинуть по вертикали */
    const initTopPositionForRightLeftCase = function(positionData: TsumPositioning.PositionSetup): void {
        const { popup, parent, arrowWidth, borderRadius, offset } = positionData;

        const tooltipRect: ClientRect = popup.getBoundingClientRect();
        const parentRect: ClientRect = parent.getBoundingClientRect();

        const halfedTooltipHeight = tooltipRect.height / 2;
        const halfedParentHeight = parentRect.height / 2;

        const hasPlaceInBottom: boolean = isHasBottomPlace(tooltipRect, parentRect, offset);
        const hasPlaceInTop: boolean = isHasTopPlace(tooltipRect, parentRect, offset);
        const additionalOffset = (arrowWidth / 2 + TRIM_SIZE) + (2 * borderRadius) + offset;

        /** Есть место и сверху и снизу, отображаем по середине */
        if (hasPlaceInTop && hasPlaceInBottom) {
            popup.style.top = `${parentRect.bottom - halfedParentHeight - halfedTooltipHeight + offset}px`;
        }
        /** Есть место сверху, но нет снизу */
        else if (hasPlaceInTop && !hasPlaceInBottom) {
            popup.style.top = `${parentRect.top - tooltipRect.height - additionalOffset}px`;
        }
        /** Есть место снизу, но нет сверху */
        else if (hasPlaceInBottom && !hasPlaceInTop) {
            popup.style.top = `${parentRect.bottom + additionalOffset}px`;
        }
        /** Нет места не сверху, ни снизу */
        else if (!hasPlaceInBottom && !hasPlaceInTop) {
            const neededHeight = window.innerHeight - (parentRect.bottom + additionalOffset + tooltipRect.height);
            popup.style.top = `${parentRect.bottom - halfedParentHeight - halfedTooltipHeight - neededHeight}px`;
        }

        popup.style.bottom = 'inherit';
    };

    /** Набор методов для выравнивания по соответствующему направлению */
    export const ALIGN_BY = {
        bottom(positionData: TsumPositioning.PositionSetup): void {
            const { popup, parent, offset, arrowWidth, borderRadius } = positionData;
            const additionalOffset = (arrowWidth / 2 + TRIM_SIZE) + (2 * borderRadius) + offset;

            const tooltipRect: ClientRect = popup.getBoundingClientRect();
            const parentRect: ClientRect = parent.getBoundingClientRect();

            popup.style.left = `${parentRect.left + (parentRect.width / 2) - (tooltipRect.width / 2) + offset}px`;
            popup.style.top = `${parentRect.bottom + additionalOffset}px`;
            popup.style.bottom = 'inherit';
        },

        bottomRight(positionData: TsumPositioning.PositionSetup): void {
            const { popup, parent, offset, arrowWidth, borderRadius } = positionData;
            const additionalOffset = (arrowWidth / 2 + TRIM_SIZE) + (2 * borderRadius) + offset;

            const tooltipRect: ClientRect = popup.getBoundingClientRect();
            const parentRect: ClientRect = parent.getBoundingClientRect();

            popup.style.left = `${parentRect.right + offset}px`;
            popup.style.top = `${parentRect.bottom + additionalOffset}px`;
            popup.style.bottom = 'inherit';
        },

        bottomLeft(positionData: TsumPositioning.PositionSetup): void {
            const { popup, parent, offset, arrowWidth, borderRadius } = positionData;
            const additionalOffset = (arrowWidth / 2 + TRIM_SIZE) + (2 * borderRadius) + offset;

            const tooltipRect: ClientRect = popup.getBoundingClientRect();
            const parentRect: ClientRect = parent.getBoundingClientRect();

            popup.style.left = `${parentRect.left - tooltipRect.width - offset}px`;
            popup.style.top = `${parentRect.bottom + additionalOffset}px`;
            popup.style.bottom = 'inherit';
        },

        top(positionData: TsumPositioning.PositionSetup): void {
            const { popup, parent, offset, arrowWidth, borderRadius } = positionData;
            const additionalOffset = (arrowWidth / 2 + TRIM_SIZE) + (2 * borderRadius) + offset;

            const tooltipRect: ClientRect = popup.getBoundingClientRect();
            const parentRect: ClientRect = parent.getBoundingClientRect();

            popup.style.left = `${parentRect.left + (parentRect.width / 2) - (tooltipRect.width / 2) + offset}px`;
            popup.style.top = `${parentRect.top - tooltipRect.height - additionalOffset}px`;
            popup.style.bottom = 'inherit';
        },

        topRight(positionData: TsumPositioning.PositionSetup): void {
            const { popup, parent, offset, arrowWidth, borderRadius } = positionData;
            const additionalOffset = (arrowWidth / 2 + TRIM_SIZE) + (2 * borderRadius) + offset;

            const tooltipRect: ClientRect = popup.getBoundingClientRect();
            const parentRect: ClientRect = parent.getBoundingClientRect();

            popup.style.left = `${parentRect.right + offset}px`;
            popup.style.top = `${parentRect.top - tooltipRect.height - additionalOffset}px`;
            popup.style.bottom = 'inherit';
        },

        topLeft(positionData: TsumPositioning.PositionSetup): void {
            const { popup, parent, offset, arrowWidth, borderRadius } = positionData;
            const additionalOffset = (arrowWidth / 2 + TRIM_SIZE) + (2 * borderRadius) + offset;

            const tooltipRect: ClientRect = popup.getBoundingClientRect();
            const parentRect: ClientRect = parent.getBoundingClientRect();

            popup.style.left = `${parentRect.left - tooltipRect.width - offset}px`;
            popup.style.top = `${parentRect.top - tooltipRect.height - additionalOffset}px`;
            popup.style.bottom = 'inherit';
        },

        right(positionData: TsumPositioning.PositionSetup): void {
            const { popup, parent, offset } = positionData;

            const parentRect: ClientRect = parent.getBoundingClientRect();

            popup.style.left = `${parentRect.right + offset}px`;
            initTopPositionForRightLeftCase(positionData);
        },

        rightCorner(positionData: TsumPositioning.PositionSetup): void {
            const { popup, parent, offset, arrowWidth, borderRadius } = positionData;
            const additionalOffset = (arrowWidth / 2 + TRIM_SIZE) + (2 * borderRadius) + offset;

            const tooltipRect: ClientRect = popup.getBoundingClientRect();
            const parentRect: ClientRect = parent.getBoundingClientRect();

            popup.style.left = `${parentRect.right - tooltipRect.width + offset}px`;
            popup.style.top = `${parentRect.bottom + additionalOffset}px`;
        },

        left(positionData: TsumPositioning.PositionSetup): void {
            const { popup, offset, parent } = positionData;

            const tooltipRect: ClientRect = popup.getBoundingClientRect();
            const parentRect: ClientRect = parent.getBoundingClientRect();

            popup.style.left = `${parentRect.left - tooltipRect.width - offset}px`;
            initTopPositionForRightLeftCase(positionData);
        },

        leftCorner(positionData: TsumPositioning.PositionSetup): void {
            const { popup, offset, parent, arrowWidth, borderRadius } = positionData;
            const additionalOffset = (arrowWidth / 2 + TRIM_SIZE) + (2 * borderRadius) + offset;

            const tooltipRect: ClientRect = popup.getBoundingClientRect();
            const parentRect: ClientRect = parent.getBoundingClientRect();

            popup.style.left = `${parentRect.left  - offset}px`;
            popup.style.top = `${parentRect.bottom + additionalOffset}px`;
        },
    };
}
