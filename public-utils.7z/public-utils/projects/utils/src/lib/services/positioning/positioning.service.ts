import { Injectable } from '@angular/core';
import { TsumPositioning } from './positioning.namespace';

/**
 * @description Задача сервиса позиционировать один элемент(условный tooltip) относительно другого (условный parent)
 */
@Injectable({
    providedIn: 'root',
})
export class TsumPositioningService {

    private directionAdjustment = TsumPositioning.DIRECTION_ADJUSTMENT;

    /** Выравнивает tooltip в указанную сторону от parent */
    private readonly alignBy = TsumPositioning.ALIGN_BY;

    /**
     * @description Вычисляет сторону, где поместится tooltip, после чего помещает tooltip в направлении этой стороны
     * @param positionData необходимые данные для вычисления конечной позиции и ее последующей обработки
     */
    public positioning(positionData: TsumPositioning.PositionSetup): void {
        const { popup, parent, offset, preferablePositions, alignType } = positionData;
        const tooltipRect: ClientRect = popup.getBoundingClientRect();
        const parentRect: ClientRect = parent.getBoundingClientRect();

        /** Для фиксированного типа мы берем первую предпочтительную страницу */
        if (alignType === 'fixed') {
            if (!preferablePositions[0]) {
                throw Error('For type "fixed" you should pass "preferablePositions"');
            }

            this.alignBySide(positionData, preferablePositions[0]);
        } else {
            let isAligned: boolean = false;

            /** Сначала смотрим предпочтительные позиции */
            if (preferablePositions && Array.isArray(preferablePositions) && preferablePositions.length > 0) {
                preferablePositions.forEach((position: TsumPositioning.Direction) => {
                    if (this.hasPlaceInPreferablePosition(tooltipRect, parentRect, offset, position) && !isAligned) {
                        this.alignBySide({...positionData }, position);

                        isAligned = true;
                    }
                });
            }

            /** Если не нашли предпочтительных или они не влезают, тогда проходимся по всем позициям */
            if (!isAligned) {
                for (const direction in this.directionAdjustment) {
                    if (direction !== 'left-corner' && direction !== 'right-corner') {
                        if (this.directionAdjustment[direction](tooltipRect, parentRect, offset) && !isAligned) {
                            this.alignBySide({...positionData }, direction as TsumPositioning.Direction);

                            isAligned = true;
                        }
                    }
                }
            }
        }
    }

    /**
     * @description Проверяет достаточно ли места в предпочтительном направлении
     * @param tooltipRect - ClientRect подсказки
     * @param parentRect - ClientRect элемента, относительно которого выравнивается подсказка
     * @param offset - Расстояние между parent и tooltip при выравнивании
     * @param preferablePosition - Приоритетная позиция
     */
    private hasPlaceInPreferablePosition(
        tooltipRect: ClientRect,
        parentRect: ClientRect,
        offset: number,
        preferablePosition: TsumPositioning.Direction,
    ): boolean {
        if (this.directionAdjustment[preferablePosition]) {
            return this.directionAdjustment[preferablePosition](tooltipRect, parentRect, offset);
        } else {
            this.throwPositionError([preferablePosition]);
        }
    }

    /**
     * @description Выравнивает HTML элементы в соответствии с параметрами
     * @description После выравнивания вызвает функцию after с аргументом направления выравнивания
     */
    private alignBySide(positionData: TsumPositioning.PositionSetup, preferablePosition: TsumPositioning.Direction): void {
        const { after } = positionData;

        if (this.alignBy[preferablePosition]) {
            this.alignBy[preferablePosition](positionData);

            after(preferablePosition);
        } else {
            this.throwPositionError([preferablePosition]);
        }
    }

    /**
     * @param side Нераспознаваемая сервисом строка или undefined
     */
    private throwPositionError(directions: TsumPositioning.Direction[]): never {
        const isArray = Boolean(directions) && Array.isArray(directions) && directions.length > 0;

        throw Error(`Value ${isArray ? directions.join(',') : directions} is not exists in type TsumPubTip.Position`);
    }
}
