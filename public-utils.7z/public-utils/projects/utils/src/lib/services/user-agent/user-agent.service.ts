import { Inject, Injectable } from '@angular/core';

import { TsumGeneralHelper } from '../../helpers/general';

import { TSUM_USER_AGENT_PROVIDER, TsumUserAgentProvider } from './user-agent.provider';
import { TsumUserAgentParser } from './user-agent.parser';
import {
    TsumUserAgentState,
    TsumUserAgentOSDetection,
    TsumUserAgentDeviceDetection,
    TsumUserAgentBrowserDetection,
} from './user-agent.state';

import isNullish = TsumGeneralHelper.isNullish;

/**
 * Сервис для определения различных состояний в User-Agent.
 * Определяет тип ОС, тип устройства и браузер.
 *
 * <code>
 * User-Agent: <product> / <product-version> <comment>
 * Common format for web browsers:
 * User-Agent: Mozilla/<version> (<system-information>) <platform> (<platform-details>) <extensions>
 * </code>
 *
 * @example
 * service.state.device.isMobile();
 * service.device.isMobile();
 * service.browser.isSafariBased();
 * service.os.is(TsumUserAgentOS.iOS);
 * service.os.oneOf([TsumUserAgentOS.iOS, TsumUserAgentOS.MacOS]);
 *
 * @see https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/User-Agent
 */
@Injectable({
    providedIn: 'root',
})
export class TsumUserAgentService {
    private parser = new TsumUserAgentParser();
    private lastState: TsumUserAgentState;

    /** Текущее состояние определений User-Agent */
    public get state(): TsumUserAgentState {
        return this.getCurrentState();
    }

    /** Текущий User-Agent */
    public get userAgent(): string {
        return this.userAgentProvider.get();
    }

    /** Текущая ОС */
    public get os(): TsumUserAgentOSDetection {
        return this.getCurrentState().os;
    }

    /** Текущее устройство */
    public get device(): TsumUserAgentDeviceDetection {
        return this.getCurrentState().device;
    }

    /** Текущий браузер */
    public get browser(): TsumUserAgentBrowserDetection {
        return this.getCurrentState().browser;
    }

    constructor(
        @Inject(TSUM_USER_AGENT_PROVIDER) private userAgentProvider: TsumUserAgentProvider,
    ) {}

    private getCurrentState(): TsumUserAgentState {
        const userAgent: string = this.userAgentProvider.get();

        if (isNullish(this.lastState) || this.lastState.userAgent !== userAgent) {
            this.lastState = this.parse(userAgent);
        }

        return this.lastState;
    }

    private parse(userAgent: string): TsumUserAgentState {
        return {
            userAgent,
            os: new TsumUserAgentOSDetection(this.parser.parseOS(userAgent)),
            device: new TsumUserAgentDeviceDetection(this.parser.parseDevice(userAgent)),
            browser: new TsumUserAgentBrowserDetection(this.parser.parseBrowser(userAgent)),
        };
    }
}
