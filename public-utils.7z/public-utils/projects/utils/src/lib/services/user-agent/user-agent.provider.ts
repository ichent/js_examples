import { PLATFORM_ID, inject, InjectionToken } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

/**
 * Получает значение User-Agent
 */
export interface TsumUserAgentProvider {
    get(): string;
}

/**
 * Предопределённые поставщики User-Agent
 */
export namespace TsumUserAgentProviders {
    /**
     * Создаёт поставщика постоянного значения
     */
    export function createStaticProvider(userAgent: string): TsumUserAgentProvider {
        if (typeof userAgent !== 'string') {
            throw new TypeError(`Expected type of User-Agent is string. Got ${typeof userAgent}.`);
        }

        return {
            get(): string {
                return userAgent;
            }
        };
    }

    /**
     * Создаёт поставщика для браузера
     */
    export function createBrowserProvider(): TsumUserAgentProvider {
        if (typeof navigator === 'undefined' || typeof navigator.userAgent === 'undefined') {
            return {
                get(): string {
                    return '';
                }
            };
        }

        return {
            get(): string {
                return navigator.userAgent;
            }
        };
    }
}

/**
 * Токен для получения значение User-Agent
 */
export const TSUM_USER_AGENT_PROVIDER = new InjectionToken<TsumUserAgentProvider>('tsum.user-agent.provider', {
    providedIn: 'root',
    factory: function tsumUserAgentProviderFactory(): TsumUserAgentProvider {
        const platformId: Object = inject(PLATFORM_ID);

        if (isPlatformBrowser(platformId)) {
            return TsumUserAgentProviders.createBrowserProvider();
        } else {
            return TsumUserAgentProviders.createStaticProvider('');
        }
    },
});
