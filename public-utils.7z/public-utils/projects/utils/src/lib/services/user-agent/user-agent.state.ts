/**
 * Определяемые ОС
 */
export enum TsumUserAgentOS {
    Windows,
    Linux,
    MacOS,
    iOS,
    Android,
    WindowsPhone,
}

/**
 * Определяемые устройства
 */
export enum TsumUserAgentDevice {
    Phone,
    Tablet,
    Desktop,
}

/**
 * Определяемые браузеры
 */
export enum TsumUserAgentBrowser {
    Chrome,
    Safari,
    Firefox,
    Opera,
    Edge,
    IE,
    YandexBrowser,
    CriOS,
    Android,
    MobileSafari
}

/**
 * Определённые состояния
 */
export interface TsumUserAgentState {
    readonly userAgent: string;
    readonly os: TsumUserAgentOSDetection;
    readonly device: TsumUserAgentDeviceDetection;
    readonly browser: TsumUserAgentBrowserDetection;
}

/**
 * Определённое в User-Agent состояние
 */
abstract class UserAgentDetection<T> {
    /** Определённое состояние */
    public readonly value: T;

    constructor(value: T) {
        this.value = value;
    }

    /**
     * Сверяет состояние с ожидаемым
     */
    public is(value: T): boolean {
        return value === this.value;
    }

    /**
     * Сверяет состояние с множеством ожидаемых
     */
    public oneOf(values: Array<T>): boolean {
        return -1 !== values.indexOf(this.value);
    }
}

/**
 * Тип ОС, определённый в User-Agent
 */
export class TsumUserAgentOSDetection extends UserAgentDetection<TsumUserAgentOS> {
    public isIOS(): boolean {
        return this.value === TsumUserAgentOS.iOS;
    }

    public isAndroid(): boolean {
        return this.value === TsumUserAgentOS.Android;
    }

    public isWindows(): boolean {
        return this.value === TsumUserAgentOS.Windows;
    }

    public isMacOs(): boolean {
        return this.value === TsumUserAgentOS.MacOS;
    }
}

/**
 * Тип устройства, определённого из User-Agent
 */
export class TsumUserAgentDeviceDetection extends UserAgentDetection<TsumUserAgentDevice> {
    public isDesktop(): boolean {
        return this.value === TsumUserAgentDevice.Desktop;
    }

    public isPhone(): boolean {
        return this.value === TsumUserAgentDevice.Phone;
    }

    public isTablet(): boolean {
        return this.value === TsumUserAgentDevice.Tablet;
    }

    public isMobile(): boolean {
        return this.value === TsumUserAgentDevice.Phone || this.value === TsumUserAgentDevice.Tablet;
    }
}

/**
 * Браузер, определённый в User-Agent
 */
export class TsumUserAgentBrowserDetection extends UserAgentDetection<TsumUserAgentBrowser> {
    public isChrome(): boolean {
        return this.value === TsumUserAgentBrowser.Chrome;
    }

    public isFirefox(): boolean {
        return this.value === TsumUserAgentBrowser.Firefox;
    }

    public isSafari(): boolean {
        return this.value === TsumUserAgentBrowser.Safari;
    }

    public isMobileSafari(): boolean {
        return this.value === TsumUserAgentBrowser.MobileSafari;
    }

    public isCriOS(): boolean {
        return this.value === TsumUserAgentBrowser.CriOS;
    }

    public isSafariBased(): boolean {
        return (
            this.value === TsumUserAgentBrowser.Safari
            || this.value === TsumUserAgentBrowser.MobileSafari
        );
    }

    public isChromiumBased(): boolean {
        return (
            this.value === TsumUserAgentBrowser.Chrome
            || this.value === TsumUserAgentBrowser.Opera
            || this.value === TsumUserAgentBrowser.YandexBrowser
        );
    }
}
