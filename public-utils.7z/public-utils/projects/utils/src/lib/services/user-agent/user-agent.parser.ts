import { TsumGeneralHelper } from '../../helpers/general';
import { TsumUserAgentBrowser, TsumUserAgentDevice, TsumUserAgentOS } from './user-agent.state';
import isNullish = TsumGeneralHelper.isNullish;

const OS_DETECTIONS: Array<[TsumUserAgentOS, RegExp]> = [
    [TsumUserAgentOS.iOS, /\b(iPhone|iPad|iPod)\b/],
    [TsumUserAgentOS.Android, /\bAndroid\b/],
    [TsumUserAgentOS.WindowsPhone, /\bWindows Phone\b/],
    [TsumUserAgentOS.MacOS, /\bMacintosh\b/],
    [TsumUserAgentOS.Windows, /\bWindows\b/],
    [TsumUserAgentOS.Linux, /\bLinux\b/],
];

const DEVICE_DETECTIONS: Array<[TsumUserAgentDevice, RegExp]> = [
    [TsumUserAgentDevice.Phone, /^[^(]+(\(.*?\b(iPhone|iPod|Windows Phone)\b.*?\)|\(.*?\bAndroid\b.*?\).*?Mobile)/i],
    [TsumUserAgentDevice.Tablet, /^[^(]+\(.*?\b(iPad|Android)\b.*?\)/i],
    [TsumUserAgentDevice.Desktop, /^[^(]+\(.*\b(Windows|Macintosh|Linux)\b.*?\)/i],
];

const BROWSER_DETECTIONS: Array<[TsumUserAgentBrowser, RegExp]> = [
    [TsumUserAgentBrowser.Firefox, /Firefox\/([0-9\.]+)(?:\s|$)/],
    [TsumUserAgentBrowser.Opera, /Opera\/([0-9\.]+)(?:\s|$)/],
    [TsumUserAgentBrowser.Opera, /OPR\/([0-9\.]+)(:?\s|$)$/],
    [TsumUserAgentBrowser.Edge, /Edge\/([0-9\._]+)/],
    [TsumUserAgentBrowser.IE, /Trident\/7\.0.*rv\:([0-9\.]+)\).*Gecko$/],
    [TsumUserAgentBrowser.IE, /MSIE\s([0-9\.]+);.*Trident\/[4-7].0/],
    [TsumUserAgentBrowser.IE, /MSIE\s(7\.0)/],
    [TsumUserAgentBrowser.YandexBrowser, /YaBrowser\/([0-9\._]+)/],
    [TsumUserAgentBrowser.Chrome, /(?!Chrom.*OPR)Chrom(?:e|ium)\/([0-9\.]+)(:?\s|$)/],
    [TsumUserAgentBrowser.CriOS, /CriOS\/([0-9\.]+)(:?\s|$)/],
    [TsumUserAgentBrowser.Android, /Android\s([0-9\.]+)/],
    [TsumUserAgentBrowser.MobileSafari, /Version\/([0-9\._]+).*Mobile.*Safari.*/],
    [TsumUserAgentBrowser.Safari, /Version\/([0-9\._]+).*Safari/],
];

const SYSTEM_INFO_REGEXP = /^[^(]+\((.+?)\)/; // `<product>/<version> (<system-information>) ...`

export class TsumUserAgentParser {
    public parseOS(userAgent: string): TsumUserAgentOS {
        const systemInfo: string = this.parseSystemInfo(userAgent);

        return !isNullish(systemInfo)
            ? this.detectState(systemInfo, OS_DETECTIONS)
            : null;
    }

    public parseDevice(userAgent: string): TsumUserAgentDevice {
        return this.detectState(userAgent, DEVICE_DETECTIONS);
    }

    public parseBrowser(userAgent: string): TsumUserAgentBrowser {
        return this.detectState(userAgent, BROWSER_DETECTIONS);
    }

    private parseSystemInfo(userAgent: string): string {
        const systemInfoMatch: RegExpMatchArray = userAgent.match(SYSTEM_INFO_REGEXP);

        if (systemInfoMatch === null) {
            return null;
        }

        return systemInfoMatch[1];
    }

    private detectState<T>(source: string, detections: Array<[T, RegExp]>): T {
        let detected: T = null;

        for (const [state, regexp] of detections) {
            if (regexp.test(source)) {
                detected = state;
                break;
            }
        }

        return detected;
    }
}

