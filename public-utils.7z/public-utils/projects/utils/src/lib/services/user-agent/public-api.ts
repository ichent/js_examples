export { TsumUserAgentService } from './user-agent.service';
export {
    TsumUserAgentProvider,
    TsumUserAgentProviders,
    TSUM_USER_AGENT_PROVIDER,
} from './user-agent.provider';
export {
    TsumUserAgentOS,
    TsumUserAgentDevice,
    TsumUserAgentBrowser,
    TsumUserAgentState,
    TsumUserAgentOSDetection,
    TsumUserAgentDeviceDetection,
    TsumUserAgentBrowserDetection,
} from './user-agent.state';
