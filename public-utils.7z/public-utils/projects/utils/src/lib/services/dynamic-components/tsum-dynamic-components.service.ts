import {
    ApplicationRef,
    ComponentFactory,
    ComponentFactoryResolver,
    ComponentRef,
    EmbeddedViewRef,
    EventEmitter,
    Inject,
    Injectable,
    Injector,
    Renderer2,
    RendererFactory2,
    Type,
    ViewContainerRef,
    ElementRef,
} from '@angular/core';
import { DOCUMENT } from '@angular/common';

export interface BaseComponent {
    el: ElementRef;
}

export interface DynamicComponentConfig {
    viewContainer?: ViewContainerRef;
    positionInBody?: 'before' | 'after';
}

/**
 * @description This service uses for dynamic create components
 * @description for create component call createComponent method and send component
 * @description by default this method append your component to body
 * @description If you wanna insert as sibling, pass viewContainer in config(second argument)
 * @description Also you can create component in child, use method createChildComponent
 * @description And do not forget delete component, when you leave your component
 * @example const ref = tsumDynamicComponentsService.createComponent(TestComponent);
 */
@Injectable()
export class TsumDynamicComponentsService {

    private renderer: Renderer2;

    public constructor(
        protected resolver: ComponentFactoryResolver,
        @Inject(DOCUMENT) private document: any,
        protected appRef: ApplicationRef,
        protected injector: Injector,
        protected rendererFactory: RendererFactory2,
    ) {
        this.renderer = rendererFactory.createRenderer(null, null);
    }

    /**
     * @description Created dynamically component
     * Just send component and config, you can pass viewContainer to config for add component to current place
     */
    public createComponent<C extends any>(component: Type<C>, config?: DynamicComponentConfig): ComponentRef<C> {
        const componentFactory: ComponentFactory<C> = this.resolver.resolveComponentFactory(component);
        const viewContainerRef = config ? config.viewContainer : null;
        const insertBefore: boolean = config ? config.positionInBody === 'before' : false;

        let componentRef: ComponentRef<C>;

        if (viewContainerRef) {
            componentRef = viewContainerRef.createComponent(componentFactory);
        } else {
            componentRef = componentFactory.create(this.injector);
            const DOMElem: HTMLElement = (componentRef.hostView as EmbeddedViewRef<any>).rootNodes[0] as HTMLElement;

            this.appRef.attachView(componentRef.hostView);

            if (!insertBefore) {
                this.document.body.appendChild(DOMElem);
            } else {
                this.document.body.insertBefore(DOMElem, this.document.body.firstChild);
            }
        }

        return componentRef;
    }

    /**
     * @description Created dynamically component and pass it as child
     * Just send component and config, you can pass viewContainer to config for add component to current place
     */
    public createChildComponent<C extends BaseComponent>(component: Type<C>, viewContainer: ViewContainerRef): ComponentRef<C> {
        const componentRef: ComponentRef<C> = this.createComponent(component, { viewContainer });

        this.renderer.appendChild(viewContainer.element.nativeElement, componentRef.instance.el.nativeElement);

        return componentRef;
    }

    /**
     * @description Delete component from DOM and unsubscribe
     */
    public deleteComponent<C extends any>(componentRef: ComponentRef<C>, viewContainerRef?: ViewContainerRef): void {
        if (componentRef) {
            this.unsubscribeFromComponent(componentRef);

            if (viewContainerRef) {
                const index: number = viewContainerRef.indexOf(componentRef.hostView);
                viewContainerRef.remove(index);
                componentRef.destroy();
            } else {
                componentRef.destroy();
                this.appRef.detachView(componentRef.hostView);
            }
        }
    }

    private unsubscribeFromComponent<C extends any>(componentRef: ComponentRef<C>): void {
        if (componentRef) {
            const instance = componentRef.instance;

            for (const key in instance) {
                if (instance[key] && instance.hasOwnProperty(key)) {
                    if (instance[key] as any instanceof EventEmitter) {
                        const eventEmitter = instance[key] as any;

                        eventEmitter.complete();
                    }
                }
            }
        }
    }

}
