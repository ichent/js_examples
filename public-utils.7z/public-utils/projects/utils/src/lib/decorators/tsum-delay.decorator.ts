/**
 * @description
 * Декоратор для задержки вызова, ваш метод будет вызван с задержкой, которую вы укажите
 * @example
 * @TsumDelayDecorator
 * @HostListener('click')
 * public handleClick(): void { ... }
 */
export function TsumDelayDecorator(milliseconds: number = 300): MethodDecorator {
    return function(target: any, propertyKey: string, descriptor: PropertyDescriptor) {
            const originalMethod = descriptor.value;

            descriptor.value = function(...args) {
                setTimeout(() => {
                    originalMethod.apply(this, args);
                }, milliseconds);
            };

            return descriptor;
      };
}
