import { TsumGeneralHelper } from '../helpers/general/tsum-general.helper';

/**
 * @description This decorator can return true/false, when you add just html attribute as input(without set data)
 * @description When need to set attribute value via PropertyBinding [true/false] or set needed attribute without value
 */
export function TsumInputBoolean(): PropertyDecorator {
    return function(target: object, defaultKey: string): void {
        const privateKey = `_${defaultKey}`;

        // Для getter и setter this это конкрентный инстанс,
        // а методы getter и setter (как и их скоп) общие для всех инстансов
        function getter(): boolean {
            return this[privateKey];
        }

        function setter(value: boolean | string): void {
            this[privateKey] = (TsumGeneralHelper.isPropertyActive(value));
        }

        Object.defineProperty(
            target,
            defaultKey,
            {
                get: getter,
                set: setter,
                configurable: true,
                enumerable: true,
            }
        );
    };
}
