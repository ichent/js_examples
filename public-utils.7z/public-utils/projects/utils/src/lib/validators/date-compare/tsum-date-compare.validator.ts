import { ValidationErrors, AbstractControl } from '@angular/forms';

export namespace TsumDateCompareValidator {
    const isAnyInvalidDate = (rangeFromAdaptJsDate: string, rangeToAdaptJsDate: string): boolean => {
        const fromTime: number = Date.parse(rangeFromAdaptJsDate);
        const toTime: number = Date.parse(rangeToAdaptJsDate);

        if (isNaN(fromTime) || isNaN(toTime)) {
            return true;
        }

        return false;
    };

    const getReadyJsDate = (defaultFormatDate: string): string => {
        const dd: string = defaultFormatDate.slice(0, 2);
        const mm: string = defaultFormatDate.slice(5, 7);
        const yyyy: string = defaultFormatDate.slice(10, 14);

        return `${mm}/${dd}/${yyyy}`;
    };

    /**
     * @description Default date validator
     */
    export const tsumDateCompareValidator = (
        fromControl: AbstractControl,
        toControl: AbstractControl,
    ): ValidationErrors | null => {
        const countSymbolsForCorrectDate = 14;
        const errorObject: ValidationErrors =  {};
        const fromValue: string = fromControl.value || '';
        const toValue: string = toControl.value || '';

        if (!fromControl.value || !toControl.value) {
            return errorObject;
        }

        if (fromValue.length === countSymbolsForCorrectDate && toValue.length === countSymbolsForCorrectDate) {
            const rangeFromAdaptJsDate: string = getReadyJsDate(fromValue);
            const rangeToAdaptJsDate: string = getReadyJsDate(toValue);

            if (!isAnyInvalidDate(rangeFromAdaptJsDate, rangeToAdaptJsDate)) {
                const fromTime = +new Date(rangeFromAdaptJsDate);
                const toTime = +new Date(rangeToAdaptJsDate);

                if (toTime < fromTime) {
                    errorObject.range = { invalid: true };
                }
            }
        } else {
            errorObject.range = { invalid: true };
        }

        return errorObject;
    };
}
