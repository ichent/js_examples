import { ValidationErrors, AbstractControl } from '@angular/forms';

export namespace TsumNumericCompareValidator {
    export const tsumNumericCompareValidator = (
        fromControl: AbstractControl,
        toControl: AbstractControl,
    ): ValidationErrors | null => {
        const errorObject: ValidationErrors =  {};

        const numericFrom = parseInt(fromControl.value, 10);
        const numericTo = parseInt(toControl.value, 10);

        if (numericFrom > numericTo) {
            errorObject.range = { invalid: true };
        }

        return errorObject;
    };
}
