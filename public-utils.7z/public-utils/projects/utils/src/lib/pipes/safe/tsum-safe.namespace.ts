export namespace TsumSafe {
    export type SafeType = 'html' | 'style' | 'script' | 'url' | 'resourceUrl';
}
