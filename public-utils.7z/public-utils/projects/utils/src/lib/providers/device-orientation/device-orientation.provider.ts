import { inject, InjectionToken, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

type MatchMediaFn = (mediaQuery: string) => MediaQueryList;

declare global {
    interface Window {
        readonly msMatchMedia?: MatchMediaFn;
    }

    interface Screen {
        readonly msOrientation?: string;
        readonly mozOrientation?: string;
    }
}

/**
 * Ориентация экрана устройства
 */
export enum TsumDeviceOrientation {
    Landscape,
    Portrait,
}

/**
 * Определяет ориентацию экрана
 */
export interface TsumDeviceOrientationProvider {
    get(): TsumDeviceOrientation;
}

/**
 * Преднастроенные провайдеры ориентации экрана
 */
export namespace TsumDeviceOrientationProviders {
    /**
     * Создаёт провайдер ориентации экрана с постоянным значением
     */
    export function createStaticProvider(orientation: TsumDeviceOrientation): TsumDeviceOrientationProvider {
        return {
            get(): TsumDeviceOrientation {
                return orientation;
            }
        };
    }

    /**
     * Создаёт провайдер ориентации экрана на основе доступных возможностей браузера
     */
    export function createBrowserProvider(): TsumDeviceOrientationProvider {
        return byScreenOrientation()
            || byWindowOrientation()
            || byMatchMedia()
            || byWindowSize();
    }

    /**
     * Позволяет определить ориентацию экрана по свойству `screen.orientation`
     * Это экспериментальная технология.
     *
     * @see https://developer.mozilla.org/en-US/docs/Web/API/Screen/orientation
     */
    function byScreenOrientation(): TsumDeviceOrientationProvider | null {
        if (typeof screen === 'undefined') {
            return null;
        }

        let getValue: () => string;

        if (screen.orientation && typeof screen.orientation.type === 'string') {
            getValue = () => screen.orientation.type;
        } else if (typeof screen.msOrientation === 'string') {
            getValue = () => screen.msOrientation;
        } else if (typeof screen.mozOrientation === 'string') {
            getValue = () => screen.mozOrientation;
        }

        if (getValue) {
            return {
                get(): TsumDeviceOrientation {
                    const orientation: string = getValue();

                    return (orientation === 'portrait-primary' || orientation === 'portrait-secondary')
                        ? TsumDeviceOrientation.Portrait
                        : TsumDeviceOrientation.Landscape;
                }
            };
        } else {
            return null;
        }
    }

    /**
     * Позволяет определить ориентацию экрана по свойству `browser-globals.orientation`
     * Это устаревшее свойство, которое удалено из стандартов, но всё ещё поддерживается некоторыми браузерами (Safari).
     *
     * @see https://developer.mozilla.org/en-US/docs/Web/API/ScreenOrientation
     */
    function byWindowOrientation(): TsumDeviceOrientationProvider | null {
        // tslint:disable-next-line:deprecation
        if (typeof window.orientation !== 'number') {
            return null;
        }

        return {
            get(): TsumDeviceOrientation {
                // tslint:disable-next-line:deprecation
                return (window.orientation === 90 || window.orientation === -90 || window.orientation === 270)
                    ? TsumDeviceOrientation.Portrait
                    : TsumDeviceOrientation.Landscape;
            }
        };
    }

    /**
     * Определяет ориентацию экрана по CSS медиа-запросу `(orientation: portrait)`
     *
     * @see https://developer.mozilla.org/ru/docs/Web/API/Window/matchMedia
     */
    function byMatchMedia(): TsumDeviceOrientationProvider | null {
        const matchMedia: MatchMediaFn = window.matchMedia || window.msMatchMedia;

        if (matchMedia) {
            return {
                get(): TsumDeviceOrientation {
                    return matchMedia('(orientation: portrait)').matches
                        ? TsumDeviceOrientation.Portrait
                        : TsumDeviceOrientation.Landscape;
                }
            };
        }
    }

    /**
     * Определяет ориентацию экрана по соотношению сторон окна
     */
    function byWindowSize(): TsumDeviceOrientationProvider {
        return {
            get(): TsumDeviceOrientation {
                return window.innerWidth < window.innerHeight
                    ? TsumDeviceOrientation.Portrait
                    : TsumDeviceOrientation.Landscape;
            }
        };
    }
}

/**
 * Токен для провайдера ориентации экрана
 */
export const TSUM_DEVICE_ORIENTATION_PROVIDER = new InjectionToken<TsumDeviceOrientationProvider>('tsum.device-orientation.provider', {
    providedIn: 'root',
    factory: function tsumDeviceOrientationProviderFactory(): TsumDeviceOrientationProvider {
        const platformId: Object = inject(PLATFORM_ID);

        if (isPlatformBrowser(platformId)) {
            return TsumDeviceOrientationProviders.createBrowserProvider();
        } else {
            return TsumDeviceOrientationProviders.createStaticProvider(TsumDeviceOrientation.Landscape);
        }
    },
});
