export namespace TsumScrollHelper {
    /**
     * @description Check if has space in bottom place
     */
    export function isNotHavePlaceInBottom(nativeElement: Element, height: number): boolean {
        const selectRect = nativeElement.getBoundingClientRect();
        const bottomOfSelect: number = selectRect.bottom;
        const freeBottomSpace: number = window.innerHeight - bottomOfSelect;
        const offset = 16;

        const autocompleteOptionsHeight = height + offset;

        return autocompleteOptionsHeight > freeBottomSpace;
    }

    /**
     * @description Check if has space in ещз place
     */
    export function isNotHavePlaceInTop(nativeElement: Element, height: number): boolean {
        const selectRect = nativeElement.getBoundingClientRect();
        const offset = 16;
        const topOfSelect: number = selectRect.top + offset;

        return height > topOfSelect;
    }
}
