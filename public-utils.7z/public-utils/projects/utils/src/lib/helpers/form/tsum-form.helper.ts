import { AbstractControl, FormArray, FormGroup, ValidationErrors } from '@angular/forms';
import { Observable, Subscriber } from 'rxjs';

export namespace TsumFormHelper {
    export type ControlIteratee = (control: AbstractControl) => void;

    /**
     * Observable из значения контрола
     * @example
     *  const control = new FormControl;
     *  TsumFormHelper.controlValueObservable(control) // return Observable
     */
    export function controlValueObservable<T>(control: AbstractControl): Observable<T> {
        return new Observable((subscriber: Subscriber<T>) => {
            subscriber.next(control.value);
            return control.valueChanges.subscribe(subscriber);
        });
    }

    /**
     * Позволяет перебирать контролы на любом уровне вложенности и применять к ним метод
     *
     * @example
     *  TsumFormHelper.controlForEach(this.form, control => control.markAsDirty(), -1);
     */
    export function controlForEach(control: AbstractControl, iteratee: ControlIteratee, deep: number = 0): void {
        if (control instanceof FormGroup) {
            Object.values(control.controls).forEach((subControl: AbstractControl) => {
                iteratee(subControl);

                if (deep !== 0) {
                    controlForEach(subControl, iteratee, deep - 1);
                }
            });
        } else if (control instanceof FormArray) {
            control.controls.forEach((subControl: AbstractControl) => {
                iteratee(subControl);

                if (deep !== 0) {
                    controlForEach(subControl, iteratee, deep - 1);
                }
            });
        }
    }

    /**
     * Добавляет ошибки к контролам при доп валидации
     *
     * @example
     * TsumFormHelper.addControlErrors(this.control, { error: `Error: ${TsumMathHelper.getUniqueId()}` });
     */
    export function addControlErrors(control: AbstractControl, errors: ValidationErrors | null): void {
        if (errors === null) {
            return;
        }

        control.setErrors(Object.assign({}, control.errors, errors));
    }
}
