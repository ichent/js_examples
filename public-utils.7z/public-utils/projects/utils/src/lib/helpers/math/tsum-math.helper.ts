export namespace TsumMathHelper {
    /**
     * @description Returns random number
     * @example TsumMathHelper.randomNumber(1, 9) // return random number from 1 to 9
     */
    export const randomNumber = (from: number, to: number): number => {
        const innerNumber: number = from + Math.random() * (to + 1 - from);

        return Math.floor(innerNumber);
    };

    /**
     * @description Return unique id
     * @example TsumMathHelper.getUniqueId() // return unique id
     */
    export const getUniqueId = (): string => {
        return '_' + Math.random().toString(36).substr(2, 9);
    };
}
