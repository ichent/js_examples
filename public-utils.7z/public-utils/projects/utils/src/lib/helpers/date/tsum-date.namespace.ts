export namespace TsumDateFields {
    export interface I18DateDictionary {
        monthNames: string[];
        shortMonthNames: string[];
        dayName: string[];
        shortDayName: string[];
        shortDayTrueOrderName: string[];
    }

    export const monthNames = [
        'Январь',
        'Февраль',
        'Март',
        'Апрель',
        'Май',
        'Июнь',
        'Июль',
        'Август',
        'Сентябрь',
        'Октябрь',
        'Ноябрь',
        'Декабрь',
    ];

    export const shortMonthNames = [
        'Янв',
        'Февр',
        'Март',
        'Апр',
        'Май',
        'Июнь',
        'Июль',
        'Авг',
        'Сент',
        'Окт',
        'Нояб',
        'Дек',
    ];

    export const dayName = [
        'Воскресенье',
        'Понедельник',
        'Вторник',
        'Среда',
        'Четверг',
        'Пятница',
        'Суббота',
    ];

    export const shortDayName = [
        'Вс',
        'Пн',
        'Вт',
        'Ср',
        'Чт',
        'Пт',
        'Сб',
    ];

    export const shortDayTrueOrderName = [
        'Пн',
        'Вт',
        'Ср',
        'Чт',
        'Пт',
        'Сб',
        'Вс',
    ];

    export const i18nDictionary: TsumDateFields.I18DateDictionary = {
        monthNames,
        shortMonthNames,
        dayName,
        shortDayName,
        shortDayTrueOrderName,
    };

    export type Accuracy = 'full' | 'year' | 'month' | 'date' | 'monthAndDate' | 'monthAndDateAndYear' | 'hour' | 'minute';

    export type Format = 'mm/dd/yyyy' | 'dd/mm/yyyy' | 'dd / mm / yy';
}
