import { TsumDateFields } from './tsum-date.namespace';

class TsumDateHelper {
    private innerDate: Date;
    private year: number; // Год
    private month: number; // Месяц
    private day: number; // День недели
    private date: number; // День
    private hour: number; // Час
    private minute: number; // Минута
    private timestamp: number;

    /**
     * @description Real month number, js date return month from 0.
     * @description this just adds +1 to month number
     */
    public get realMonthNumber(): number {
        return this.month + 1;
    }

    /**
     * @description full date, with zero, when month is has one symbol
     */
    public get completeDate(): string {
        return this.date > 9 ? this.date.toString() : `0${this.date.toString()}`;
    }

    /**
     * @description full month, with zero, when month is has one symbol
     */
    public get completeMonth(): string {
        return this.realMonthNumber > 9 ? this.realMonthNumber.toString() : `0${this.realMonthNumber.toString()}`;
    }

    constructor(currentDate: Date = new Date()) {
        this.innerDate = currentDate;
        this.year = currentDate.getFullYear();
        this.month = currentDate.getMonth();
        this.day = currentDate.getDay();
        this.date = currentDate.getDate();
        this.hour = currentDate.getHours();
        this.minute = currentDate.getMinutes();
        this.timestamp = +currentDate;
    }

    /**
     * @description returns formatted date, which format you send
     *
     * @example TsumDateHelper(new Date()).format('dd/mm/yyyy')
     * @example returns 20.01.2019 for example
     */
    public format(formatType: TsumDateFields.Format): string {
        if (isNaN(this.month) || isNaN(this.date) || isNaN(this.year)) {
            return this.innerDate.toString();
        }

        switch (formatType) {
            case 'mm/dd/yyyy':
                return `${this.completeMonth}/${this.completeDate}/${this.year}`;

            case 'dd/mm/yyyy':
                return `${this.completeDate}/${this.completeMonth}/${this.year}`;

            case 'dd / mm / yy':
                return `${this.completeDate} / ${this.completeMonth} / ${this.year}`;
        }
    }

    /**
     * @description Check for equal dates
     * @description This method has accuracy, by default if full compare
     * @description You can pass some of accuracy level
     * @description accuracy levels:
     * @description full - full compare via timestamp
     * @description year - compare only by year
     * @description month - compare by month
     * @description date - compare by date
     * @description monthAndDate compare by month and date
     * @description monthAndDateAndYear compare by month and date and year
     * @example TsumDate(new Date()).isSame(new Date()) - returns true
     * @example TsumDate(new Date()).isSame(new Date(), 'year')
     */
    public isSame(date: Date, accuracy: TsumDateFields.Accuracy = 'full'): boolean {
        if (!date) {
            return false;
        }

        if (accuracy === 'full') {
            return +this.innerDate === +date;
        }

        if (accuracy === 'year') {
            return this.year === date.getFullYear();
        }

        if (accuracy === 'month') {
            return this.month === date.getMonth();
        }

        if (accuracy === 'date') {
            return this.date === date.getDate();
        }

        if (accuracy === 'hour') {
            throw Error('Not support');
        }

        if (accuracy === 'minute') {
            throw Error('Not support');
        }

        if (accuracy === 'monthAndDate') {
            return this.month === date.getMonth()
                && this.date === date.getDate();
        }

        if (accuracy === 'monthAndDateAndYear') {
            return this.month === date.getMonth()
                && this.date === date.getDate()
                && this.year === date.getFullYear();
        }

        return false;
    }

    /**
     * @description returns true when date after inner date
     * @description This method has accuracy, by default is full calculate via timestamp
     * @description You can pass some of accuracy level
     * @description accuracy levels:
     * @description full - full calculate via timestamp
     * @description monthAndDateAndYear calculate with month and date and year
     * @example TsumDate(new Date()).isAfter(TsumDate(new Date().getPrevDay()) - returns true
     * @example TsumDate(new Date()).isAfter(TsumDate(new Date().getPrevYear(), 'year') - returns true
     */
    public isAfter(date: Date, accuracy: TsumDateFields.Accuracy = 'full'): boolean {
        if (accuracy === 'date') {
            throw Error('Not support');
        }

        if (accuracy === 'hour') {
            throw Error('Not support');
        }

        if (accuracy === 'minute') {
            throw Error('Not support');
        }

        if (accuracy === 'month') {
            throw Error('Not support');
        }

        if (accuracy === 'year') {
            const currentDateTimestamp = +new Date(this.year, new Date().getMonth(), new Date().getDate());
            const comparedDateTimestamp = + new Date(date.getFullYear(), new Date().getMonth(), new Date().getDate());

            return currentDateTimestamp >= comparedDateTimestamp;
        }

        if (accuracy === 'monthAndDate') {
            throw Error('Not support');
        }

        if (accuracy === 'monthAndDateAndYear') {
            const currentDateTimestamp = +new Date(this.year, this.month, this.date);
            const comparedDateTimestamp = + new Date(date.getFullYear(), date.getMonth(), date.getDate());

            return currentDateTimestamp >= comparedDateTimestamp;
        }

        if (accuracy === 'full') {
            return this.timestamp >= +date;
        }
    }

    /**
     * @description returns true when date is before inner date
     * @description This method has accuracy, by default is full calculate via timestamp
     * @description You can pass some of accuracy level
     * @description accuracy levels:
     * @description full - full calculate via timestamp
     * @description monthAndDateAndYear calculate with month and date and year
     * @example TsumDate(new Date()).isBefore(TsumDate(new Date().getNextDay()) - returns true
     * @example TsumDate(new Date()).isBefore(TsumDate(new Date().getNextYear(), 'year') - returns true
     */
    public isBefore(date: Date, accuracy: TsumDateFields.Accuracy = 'full'): boolean {
        if (accuracy === 'date') {
            throw Error('Not support');
        }

        if (accuracy === 'hour') {
            throw Error('Not support');
        }

        if (accuracy === 'minute') {
            throw Error('Not support');
        }

        if (accuracy === 'month') {
            throw Error('Not support');
        }

        if (accuracy === 'year') {
            throw Error('Not support');
        }

        if (accuracy === 'monthAndDate') {
            throw Error('Not support');
        }

        if (accuracy === 'monthAndDateAndYear') {
            const currentDateTimestamp = +new Date(this.year, this.month, this.date);
            const comparedDateTimestamp = + new Date(date.getFullYear(), date.getMonth(), date.getDate());

            return currentDateTimestamp <= comparedDateTimestamp;
        }

        if (accuracy === 'full') {
            return this.timestamp <= +date;
        }
    }

    /**
     * @description returns true when you date is more than first date(from)
     * @description and less than second date(to)
     * @description This method has accuracy, by default if full between by timestamp
     * @description You can pass some of accuracy level
     * @description accuracy levels:
     * @description full - full between via timestamp
     * @description monthAndDateAndYear between with month and date and year
     * @example TsumDate(new Date()).isBetween(TsumDate(new Date().getPrevDay(), TsumDate(new Date().getNextDay()) // true
     * @example TsumDate(new Date()).isBetween(TsumDate(new Date().getPrevYear(), TsumDate(new Date().getNextYear(), 'year')
     */
    public isBetween(from: Date, to: Date, accuracy: TsumDateFields.Accuracy = 'full'): boolean {
        if (accuracy === 'date') {
            throw Error('Not support');
        }

        if (accuracy === 'hour') {
            throw Error('Not support');
        }

        if (accuracy === 'minute') {
            throw Error('Not support');
        }

        if (accuracy === 'month') {
            throw Error('Not support');
        }

        if (accuracy === 'year') {
            throw Error('Not support');
        }

        if (accuracy === 'monthAndDate') {
            throw Error('Not support');
        }

        if (accuracy === 'monthAndDateAndYear') {
            return this.isAfter(from, 'monthAndDateAndYear') && this.isBefore(to, 'monthAndDateAndYear');
        }

        if (accuracy === 'full') {
            return this.isAfter(from) && this.isBefore(to);
        }
    }

    /**
     * @description Gets previous year of current year
     * @description You can pass 'offset' for get offset for years
     * @description For example you can pass offset = 10 and method return current year - 10
     * @example TsumDate(new Date()).getPrevFullYear()
     */
    public getPrevFullYear(offset: number = 1): Date {
        return new Date(this.year - offset, this.month, this.date);
    }

    /**
     * @description Gets next year of current year
     * @description You can pass 'offset' for get offset for years
     * @description For example you can pass offset = 10 and method return current year + 10
     * @example TsumDate(new Date()).getNextFullYear()
     */
    public getNextFullYear(offset: number = 1): Date {
        return new Date(this.year + offset, this.month, this.date);
    }

    /**
     * @description Gets first month if sended month
     * @example TsumDate(new Date()).getFirstMonthByYear()
     */
    public getFirstMonthByYear(): Date {
        return new Date(this.year, 0, 1);
    }

    /**
     * @description Return years of current date
     * @example TsumDate(new Date()).getFirstMonthByYear()
     */
    public getYear(): number {
        return this.year;
    }

    /**
     * @description Return next month of current date
     * @description You can pass 'offset' for get offset for month
     * @description For example you can pass offset = 10 and method return current month + 10
     * @example TsumDate(new Date()).getNextMonth()
     */
    public getNextMonth(offset: number = 1): Date {
        return new Date(this.year, this.month + offset, this.date);
    }

    /**
     * @description Return previous month of current date
     * @description You can pass 'offset' for get offset for month
     * @description For example you can pass offset = 10 and method return current month - 10
     * @example TsumDate(new Date()).getPrevMonth()
     */
    public getPrevMonth(offset: number = 1): Date {
        return new Date(this.year, this.month - offset, this.date);
    }

    /**
     * @description Return first day of current month
     * @example TsumDate(new Date()).getFirstDayByMonth()
     */
    public getFirstDayByMonth(): Date {
        return new Date(this.year, this.month, 1);
    }

    /**
     * @description Return last day of current month
     * @example TsumDate(new Date()).getLastDayByMonth()
     */
    public getLastDayByMonth(): Date {
        return new Date(this.year, this.month + 1, 0);
    }

    /**
     * @description Return full month name
     * @description You can pass month names dictionary
     * @example TsumDate(new Date()).getMonthName(monthNames)
     */
    public getMonthName(monthNames: string[] = TsumDateFields.monthNames): string {
        return monthNames[this.month];
    }

    /**
     * @description Return short month name
     * @description You can pass month names dictionary
     * @example TsumDate(new Date()).getShortMonthName(shortMonthNames)
     */
    public getShortMonthName(shortMonthNames: string[] = TsumDateFields.shortMonthNames): string {
        return shortMonthNames[this.month];
    }

    /**
     * @description Return next day of current date
     * @description You can pass 'offset' for get offset for day
     * @description For example you can pass offset = 10 and method return current day + 10
     * @example TsumDate(new Date()).getNextDay()
     */
    public getNextDay(offset: number = 1): Date {
        return new Date(this.year, this.month, this.date + offset);
    }

    /**
     * @description Return previous day of current date
     * @description You can pass 'offset' for get offset for day
     * @description For example you can pass offset = 10 and method return current day - 10
     * @example TsumDate(new Date()).getNextDay()
     */
    public getPrevDay(offset: number = 1): Date {
        return new Date(this.year, this.month, this.date - offset);
    }

    /**
     * @description Return day of week name
     * @description You can pass day names dictionary
     * @example TsumDate(new Date()).getDayName()
     */
    public getDayName(dayName: string[] = TsumDateFields.dayName): string {
        return dayName[this.day];
    }

    /**
     * @description Return date
     * @example TsumDate(new Date()).getDate()
     */
    public getDate(): number {
        return this.date;
    }
}

/**
 * @description It's date helper
 * @description you have lots of method for mange you date
 * @description it's work in pure js date
 * @description You should pass js date to this helper and after it you can use methods
 * @example TsumDate(new Date()).getPrevDay()
 */
export const TsumDate = (innerDate: Date | number = new Date()): TsumDateHelper => {
    try {
        const date: Date = typeof innerDate === 'object' && innerDate !== null
            ? innerDate
            : (typeof innerDate === 'number'
                ? new Date(innerDate)
                : new Date());

        return new TsumDateHelper(date);
    } catch (e) {
        throw Error('Something wrong with date');
    }
};
