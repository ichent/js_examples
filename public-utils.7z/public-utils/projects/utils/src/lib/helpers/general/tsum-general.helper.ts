export namespace TsumGeneralHelper {
    export type ObjectPredicate<T, K extends keyof T> = (this: T, value: T[K], key: K) => boolean;
    /**
     * @description Check if input is active
     * @example TsumGeneralHelper.isPropertyActive('') // returns true
     * @example TsumGeneralHelper.isPropertyActive(1) // returns false
     */
    export function isPropertyActive(prop: string | boolean): boolean {
        return (prop === '' || prop === true);
    }

    /**
     * @description Invert you number
     * @example TsumGeneralHelper.invertNumber(-3) - returns 3
     * @example TsumGeneralHelper.invertNumber(5) - returns -5
     */
    export function invertNumber(digit: number): number {
        if (digit === 0) {
            return 0;
        }

        return digit * -1;
    }

    /**
     * @description Convert from/to to array with your range
     * @example TsumGeneralHelper.rangeArray(3, 6) - returns [3, 4, 5]
     * @example TsumGeneralHelper.rangeArray(3) - returns [0, 1, 2]
     * @example TsumGeneralHelper.rangeArray(-3) - returns [0, -1, -2]
     * @example TsumGeneralHelper.rangeArray(0, 4) - returns [0, 1, 2, 3]
     * @example TsumGeneralHelper.rangeArray(0, -4) - returns [0, -1, -2, -3]
     */
    export function rangeArray(from: number, to: number = null): number[] {
        if (to === null) {
            if (from < 0) {
                return Array(invertNumber(from)).fill(from).map((_, i) => invertNumber(i));
            }

            return Array(from).fill(from).map((_, i) => i);
        }

        if (to < 0) {
            return Array(invertNumber(to)).fill(from).map((_, i) => invertNumber(i));
        }

        return Array(to - from).fill(from).map((fromPosition: number, index: number) => {
            return fromPosition + index;
        });
    }

    /**
     * Проверяет является ли значение на `undefined` и `null`.
     */
    export function isNullish(value: any): boolean {
        return value === undefined || value === null;
    }

    /**
     * @description Check value if not null
     * @example TsumGeneralHelper.isNotNull(1) // returns true
     * @example TsumGeneralHelper.isNotNUll(null) // returns false
     */
    export function isNotNull(value: any): boolean {
        return value !== null;
    }

    /**
     * @description Check value is object
     * @example TsumGeneralHelper.isObject(1) // returns false
     * @example TsumGeneralHelper.isObject(null) // returns false
     * @example TsumGeneralHelper.isObject({}) // returns true
     */
    export function isObject(value: any): boolean {
        return typeof value === 'object' && value !== null;
    }

    /**
     * @description Проверяет объекты A и B на полное совпадение.
     * @description Значения проверяются в строгом соответствии.
     *
     * @example TsumGeneralHelper.isEqual({a:1}, {a:1}); // returns true
     * @example TsumGeneralHelper.isEqual({a:1}, {b:2}); // returns false
     * @example TsumGeneralHelper.isEqual({a:1, b:2}, {a:1}); // returns false
     * @example TsumGeneralHelper.isEqual([1,2,3], [1,2,3]); // returns true
     * @example TsumGeneralHelper.isEqual(null, null); // returns true
     * @example TsumGeneralHelper.isEqual(null, undefined); // returns false
     *
     */
    export function isEqual(a: any, b: any): boolean {
        if (a === b) {
            return true;
        } else if (isObject(a) && isObject(b)) {
            return (
                Object.keys(a).length === Object.keys(b).length
                && isMatch(a, b)
            );
        } else {
            return false;
        }
    }

    /**
     * @description Проверяет вхождение объекта B в объект A
     * @description Значения проверяются в строгом соответствии.
     *
     * @example TsumGeneralHelper.isMatch({a: 1, b: 2, c: 3}, {b: 2, c: 3}); // returns true
     * @example TsumGeneralHelper.isMatch({a: 1, b: 2, c: 3}, {d: 4}); // returns false
     * @example TsumGeneralHelper.isMatch({a: 1, b: 2, c: 3}, {c: 3, d: 4}); // returns false
     *
     */
    export function isMatch(a: object, b: object): boolean {
        for (const key of Object.keys(b)) {
            if (
                !(key in a)
                || a[key] !== b[key]
            ) {
                return false;
            }
        }

        return true;
    }

    /**
     * @description Sequentially applies functions to the passed argument.
     * Arguments must be unary
     *
     * @example
     *
     *      const f = pipe(Math.ceil, Math.sqrt);
     *
     *      f(15.2); // 4
     * @symb pipe(f, g, h)(a) = h(g(f(a)))
     */
    export function pipe(...fns) {
        return function(value: any) {
            return fns.reduce((acc, func) => func(acc), value);
        };
    }


    /**
     * @description Является ли значенеи строки числом
     * @example TsumGeneralHelper.isInString('12'); // returns true
     */
    export function isIntString(value: string): boolean {
        return /^\d+$/.test(value);
    }


    /**
     * @description Проверяет является ли значение массиво подобным
     * @example
     *  function testArguments() {
     *    return TsumGeneralHelper.isArrayLike(arguments)
     *   }
     *
     *  testArguments() //return true
     */
    export function isArrayLike(value: any): value is ArrayLike<any> {
        return isObject(value) && 'length' in value;
    }

    /**
     * @description Проверяет является ли значение пуст массивом, массиво подобным, set, map, oject, строкой
     * @example TsumGeneralHelper.isEmpty('массив'); // returns false
     * @example TsumGeneralHelper.isEmpty([]); // returns true
     * @example TsumGeneralHelper.isEmpty({x: 17}); // returns false
     * @example TsumGeneralHelper.isEmpty(new Set()); // returns true
     * @example TsumGeneralHelper.isEmpty(new Map()); // returns true
     */
    export function isEmpty(src: string | any[] | ArrayLike<any> | Set<any> | Map<any, any> | object): boolean {
        if (isNullish(src)) {
            return true;
        }

        if (typeof src === 'string' || isArrayLike(src)) {
            return src.length === 0;
        }

        if (src instanceof Set || src instanceof Map) {
            return src.size === 0;
        }

        if (isObject(src)) {
            for (const key in src) {
                if (src.hasOwnProperty(key)) {
                    return false;
                }
            }

            return true;
        }

        return false;
    }

    /**
     * @description При отсутствующем значении возвращает дефолтное
     * @example
     *  let someOne;
     *  defaultTo(someOne, 'default') // returns 'default'
     *
     *  someOne = 16;
     *  defaultTo(someOne, 'default') // returns 16
     */
    export function defaultTo<T, U>(value: T, defaultValue: U): T extends (null | undefined) ? U : T {
        return (isNullish(value) ? defaultValue : value) as any;
    }

    /**
     * @description Удаление из объекта значений удовлетворяющих предикату, возвращает новый объект
     * @example
     *  const src = { a: undefined, b: 13 };
     *  omitBy(src, value => value === undefined); //  returns { b: 13 }
     */
    export function omitBy<T, K extends keyof T, U extends Partial<T>>(src: T, predicate: ObjectPredicate<T, K>): U {
        return Object.entries(src).reduce((dest, [key, value]) => {
            if (!predicate.call(src, value, key)) {
                dest[key] = value;
            }
            return dest;
        }, {} as U);
    }

    /**
     * @description Возвращает новый объект без полей со значением undefined
     * @example
     *  const src = { a: undefined; b: 13 };
     *  omitBy(src, value => value === undefined); //  returns { b: 13 }
     */
    export function omitUndefined<T, U extends Partial<T>>(src: T): U {
        return omitBy(src, value => value === undefined);
    }
}
