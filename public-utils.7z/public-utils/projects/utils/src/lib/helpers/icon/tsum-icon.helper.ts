export namespace TsumIconHelper {
    /*
     * @description pure function for generating map with all icons from ui-kit
     * @example TsumIconHelper.generateIconsCollection(TsumIcon)
     */
    export function generateIconsCollection(
        iconsNameSpace: Record<string, any>,
        discardedKeys: string[]
    ): Map<string, string> {
        const nameSpaceEnums: Record<any, string>[] = Object
            .keys(iconsNameSpace)
            .filter(key => (discardedKeys.indexOf(key) === -1))
            .map(key => iconsNameSpace[key]);

        const iconsNames: Array<string> = nameSpaceEnums
            .map(iconsEnum => Object.keys(iconsEnum).map(k => iconsEnum[k]))
            .reduce((prev: string[], cur: string[]): string[] => prev.concat(cur));

        const iconsEntries: Array<[string, string]> = iconsNames.map(name => [name, name]);

        return new Map<string, string>(iconsEntries);
    }

    /**
     *  @description set of icons contains in ui-kit
     */
    export const getIcons = (
        iconsNameSpace: Record<string, any>,
    ): Map<string, string> => generateIconsCollection(iconsNameSpace, ['Color']);
}
