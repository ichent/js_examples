import { MonoTypeOperatorFunction, Observable, Subject } from 'rxjs';

export namespace TsumRxHelper {
    /**
     * Используется для изменения сабжектов по загрузке
     * @example
     * this.getCard
     *     .pipe(
     *           loadingTo(this.visiblePreloader$)
     *    ).subscribe() // при завершении загрузки изменится статус отображения карточки прелоадера.
     */
    export function loadingTo<T>(state: Subject<boolean>): MonoTypeOperatorFunction<T> {
        // tslint:disable-next-line:no-shadowed-variable
        return function loadingToOperator<T>(source: Observable<T>): Observable<T> {
            return new Observable(subscriber => {
                state.next(true);

                return source.subscribe({
                    next(value: T) {
                        subscriber.next(value);
                    },
                    error(err: any) {
                        state.next(false);
                        subscriber.error(err);
                    },
                    complete() {
                        state.next(false);
                        subscriber.complete();
                    }
                });
            });
        };
    }
}
