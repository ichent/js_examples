export class TsumValidatorHelper {
    public static checkHasValues(value: object | string | null, key: string): boolean {
        return value && value[key] !== undefined;
    }
}
