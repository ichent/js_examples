import { TsumRxHelper, TsumGeneralHelper } from 'projects/utils/src';
import { BehaviorSubject } from 'rxjs';
import { tap, filter } from 'rxjs/operators';

describe('Rx helper', () => {
    it('loadingTo', (done: Function) => {
        const loadingTo = TsumRxHelper.loadingTo;
        const someLoading$ = new BehaviorSubject<boolean>(false);
        const someVisible$ = new BehaviorSubject<boolean>(null);

        someLoading$.pipe(
            loadingTo(someVisible$),
        ).subscribe();

        someVisible$.pipe(
            filter(x => TsumGeneralHelper.isNotNull(x)),
            tap(x => expect(x).toBeTruthy()),
            tap(() => done())
        ).subscribe();

        someLoading$.next(true);
    });
});
