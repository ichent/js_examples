import { TsumGeneralHelper } from 'projects/utils/src';

describe('Tsum general helper', () => {
    it('should correct work isPropertyActive', () => {
        expect(TsumGeneralHelper.isPropertyActive('')).toEqual(true);
        expect(TsumGeneralHelper.isPropertyActive(true)).toEqual(true);
        expect(TsumGeneralHelper.isPropertyActive('asd')).toEqual(false);
        expect(TsumGeneralHelper.isPropertyActive(false)).toEqual(false);
    });

    it('should correct work rangeArray with single argument', () => {
        expect(TsumGeneralHelper.rangeArray(-4)).toEqual([0, -1, -2, -3]);
        expect(TsumGeneralHelper.rangeArray(0).length).toEqual(0);
        expect(TsumGeneralHelper.rangeArray(2).length).toEqual(2);
    });

    it('should correct work rangeArray with double argument', () => {
        expect(TsumGeneralHelper.rangeArray(0, -4)).toEqual([0, -1, -2, -3]);
        expect(TsumGeneralHelper.rangeArray(0, 0).length).toEqual(0);
        expect(TsumGeneralHelper.rangeArray(0, 1).length).toEqual(1);
        expect(TsumGeneralHelper.rangeArray(3, 6)).toEqual([3, 4, 5]);
    });

    it('should correct work invertNumber', () => {
        expect(TsumGeneralHelper.invertNumber(1)).toEqual(-1);
        expect(TsumGeneralHelper.invertNumber(0)).toEqual(0);
        expect(TsumGeneralHelper.invertNumber(-1)).toEqual(1);
    });

    it('should is equal correct work', () => {
        const isEqualHelper = TsumGeneralHelper.isEqual;

        expect(isEqualHelper({ a: 1 }, { a: 1 })).toEqual(true);
        expect(isEqualHelper({ a: 1 }, { b: 2 })).toEqual(false);
        expect(isEqualHelper({ a: 1, b: 2 }, { a: 1 })).toEqual(false);
        expect(isEqualHelper([1, 2, 3], [1, 2, 3])).toEqual(true);
        expect(isEqualHelper(null, null)).toEqual(true);
        expect(isEqualHelper(null, undefined)).toEqual(false);
        expect(isEqualHelper(1, 1)).toEqual(true);
        expect(isEqualHelper('test', 'test')).toEqual(true);
        expect(isEqualHelper(true, true)).toEqual(true);
    });

    it('should is match correct work', () => {
        const isMathHelper = TsumGeneralHelper.isMatch;

        expect(isMathHelper({ a: 1, b: 2, c: 3 }, { b: 2, c: 3 })).toEqual(true);
        expect(isMathHelper({ a: 1, b: 2, c: 3 }, { d: 4 })).toEqual(false);
        expect(isMathHelper({ a: 1, b: 2, c: 3 }, { c: 3, d: 4 })).toEqual(false);
    });

    it('should is not null correct work', () => {
        const isNotNullHelper = TsumGeneralHelper.isNotNull;

        expect(isNotNullHelper('true')).toEqual(true);
        expect(isNotNullHelper('null')).toEqual(true);
        expect(isNotNullHelper(1)).toEqual(true);
        expect(isNotNullHelper(-1)).toEqual(true);
        expect(isNotNullHelper(undefined)).toEqual(true);
        expect(isNotNullHelper(true)).toEqual(true);
        expect(isNotNullHelper(false)).toEqual(true);
        expect(isNotNullHelper(null)).toEqual(false);
    });

    it('should is object correct work', () => {
        const isObjectHelper = TsumGeneralHelper.isObject;

        expect(isObjectHelper('1')).toEqual(false);
        expect(isObjectHelper(1)).toEqual(false);
        expect(isObjectHelper(undefined)).toEqual(false);
        expect(isObjectHelper(null)).toEqual(false);
        expect(isObjectHelper({ a: 1 })).toEqual(true);
    });

    it('should pipe correct work', () => {
        const powAndSqrt = TsumGeneralHelper.pipe(Math.ceil, Math.sqrt);

        expect(powAndSqrt(15.2)).toEqual(4);
    });

    it('should  isIntString correct work', () => {
        const isIntString = TsumGeneralHelper.isIntString;

        expect(isIntString('12')).toBeTruthy();
        expect(isIntString('someString')).toBeFalsy();
    });

    it('should isArrayLike correct work', () => {
        const isArrayLike = TsumGeneralHelper.isArrayLike;

        function testArguments() {
            expect(isArrayLike(arguments)).toBeTruthy();
        }

        testArguments();

        expect(isArrayLike(new Set())).toBeFalsy();
    });

    it('should isEmpty correct work', () => {
        const isEmpty = TsumGeneralHelper.isEmpty;

        expect(isEmpty(new Set())).toBeTruthy();
        expect(isEmpty(new Map())).toBeTruthy();
        expect(isEmpty({a: '2'})).toBeFalsy();
        expect(isEmpty('someString')).toBeFalsy();
        expect(isEmpty([])).toBeTruthy();
    });

    it('should defaultTo correct work', () => {
        const defaultTo = TsumGeneralHelper.defaultTo;
        let someOne;

        expect(defaultTo(someOne, 'default')).toEqual('default');

        someOne = 42;
        expect(defaultTo(someOne, 'default')).toEqual(42);
    });

    it('should omitBy correct work', () => {
        const omitBy = TsumGeneralHelper.omitBy;
        const src = { a: undefined, b: 13 };

        expect(omitBy(src, value => value === 13)).toEqual({a: undefined});
    });

    it('should omitUndefined correct work', () => {
        const omitUndefined = TsumGeneralHelper.omitUndefined;
        const src = { a: undefined, b: 13 };

        expect(omitUndefined(src)).toEqual({b: 13});
    });
});
