import { Component, ChangeDetectionStrategy } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { TsumFormHelper } from 'projects/utils/src/lib/helpers/form/tsum-form.helper';
import { TsumMathHelper } from 'projects/utils/src/lib/helpers/math/tsum-math.helper';

@Component({
    template: `
        <input
            [formControl]="control"
            placeholder="Default Tsum input placeholder"
            required />

        <p *ngIf="controlValue$ | async" class="control-value-observable">Значение: {{controlValue$ | async}}</p>

        <div [formGroup]="form">
            <input
                formControlName="name"
                placeholder="Default Tsum input placeholder"
                required />
            <p *ngIf="form.get('name').dirty" class="dirty">dirty</p>
            <button (click)="markAsDirty($event)" class="dirty-btn">markAsDirty</button>
        </div>

        <input
                [formControl]="controlWithError"
                placeholder="Default Tsum input placeholder"
            />
        <button (click)="addErrors($event)" class="add-error-btn">add Errors</button>
    `,
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TsumFormHelperTestComponent {
    public control = new FormControl();
    public controlValue$ = TsumFormHelper.controlValueObservable(this.control);

    public form = new FormGroup({
        name: new FormControl(''),
    });

    public controlWithError =  new FormControl();
    public markAsDirty(event: MouseEvent): void {
        TsumFormHelper.controlForEach(this.form, control => control.markAsDirty(), -1);
    }

    public addErrors(event: MouseEvent): void {
        TsumFormHelper.addControlErrors(this.controlWithError, { error: `Error: ${TsumMathHelper.getUniqueId()}` });
        this.controlWithError.markAsDirty();
    }
}
