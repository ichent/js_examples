import { Spectator, createComponentFactory } from '@ngneat/spectator';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { TsumFormHelperTestComponent } from './tsum-form.helper.test.components';

describe('TsumInput Active directive', () => {
    let spectator: Spectator<TsumFormHelperTestComponent>;
    const CONTROL_VALUE_OBSERVABLE = '.control-value-observable';
    const DIRTY = '.dirty';
    const DIRTY_BTN = '.dirty-btn';
    const ADD_ERROR_BTN = '.add-error-btn';

    const createComponent = createComponentFactory({
        component: TsumFormHelperTestComponent,
        imports: [
            CommonModule,
            FormsModule,
            ReactiveFormsModule,
        ],
    });

    beforeEach(() => spectator = createComponent());
    beforeEach(() => spectator.detectChanges());

    it('control value observable', () => {
        expect(spectator.query(CONTROL_VALUE_OBSERVABLE)).toBeFalsy();

        spectator.component.control.setValue('someString');
        spectator.detectChanges();

        expect(spectator.query(CONTROL_VALUE_OBSERVABLE)).toBeTruthy();
    });

    it('control for each', () => {
        expect(spectator.query(DIRTY)).toBeFalsy();

        spectator.query(DIRTY_BTN).dispatchEvent(new MouseEvent('click'));
        spectator.detectChanges();

        expect(spectator.query(DIRTY)).toBeTruthy();
    });

    it('add control errors example', () => {
        expect(spectator.component.controlWithError.invalid).toBeFalsy();

        spectator.query(ADD_ERROR_BTN).dispatchEvent(new MouseEvent('click'));
        spectator.detectChanges();

        expect(spectator.component.controlWithError.hasError('error')).toBeTruthy();
    });
});
