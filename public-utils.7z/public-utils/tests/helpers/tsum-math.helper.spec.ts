import { TsumMathHelper } from 'projects/utils/src';

describe('Math helper', () => {
    it('should getUniqueId correct work', () => {
        const getUniqueId = TsumMathHelper.getUniqueId;

        expect(getUniqueId().length).toEqual(10);
        expect(getUniqueId()[0]).toEqual('_');
    });

    it('should is randomNumber correct work', () => {
        const randomNumber = TsumMathHelper.randomNumber;

        expect(typeof randomNumber(1, 2)).toEqual('number');
    });
});
