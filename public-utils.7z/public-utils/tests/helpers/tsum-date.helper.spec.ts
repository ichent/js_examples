import { TsumDate } from 'projects/utils/src';

describe('Tsum date helper', () => {
    const MONTH_NAMES = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

    it('should correct work isAfter Full calculate', () => {
        expect(
            TsumDate(new Date())
                .isAfter(
                    TsumDate(new Date()).getPrevDay(),
                    'full',
                )
        ).toEqual(true);

        expect(
            TsumDate(new Date())
                .isAfter(
                    TsumDate(new Date()).getPrevMonth(),
                    'full',
                )
        ).toEqual(true);

        expect(
            TsumDate(new Date())
                .isAfter(
                    TsumDate(new Date()).getNextDay(),
                    'full',
                )
        ).toEqual(false);

        expect(
            TsumDate(new Date())
                .isAfter(
                    TsumDate(new Date()).getNextMonth(),
                    'full',
                )
        ).toEqual(false);
    });

    it('should correct work isAfter monthAndDateAndYear calculate', () => {
        expect(
            TsumDate(new Date())
                .isAfter(
                    TsumDate(new Date()).getPrevFullYear(),
                    'monthAndDateAndYear',
                )
        ).toEqual(true);

        expect(
            TsumDate(new Date())
                .isAfter(
                    TsumDate(new Date()).getPrevDay(),
                    'monthAndDateAndYear',
                )
        ).toEqual(true);

        expect(
            TsumDate(new Date())
                .isAfter(
                    TsumDate(new Date()).getPrevMonth(),
                    'monthAndDateAndYear',
                )
        ).toEqual(true);

        expect(
            TsumDate(new Date())
                .isAfter(
                    TsumDate(new Date()).getNextFullYear(),
                    'monthAndDateAndYear',
                )
        ).toEqual(false);

        expect(
            TsumDate(new Date())
                .isAfter(
                    TsumDate(new Date()).getNextDay(),
                    'monthAndDateAndYear',
                )
        ).toEqual(false);

        expect(
            TsumDate(new Date())
                .isAfter(
                    TsumDate(new Date()).getNextMonth(),
                    'monthAndDateAndYear',
                )
        ).toEqual(false);
    });

    it('should correct work isBefore Full calculate', () => {
        expect(
            TsumDate(new Date())
                .isBefore(
                    TsumDate(new Date()).getNextDay(),
                    'full',
                )
        ).toEqual(true);

        expect(
            TsumDate(new Date())
                .isBefore(
                    TsumDate(new Date()).getNextMonth(),
                    'full',
                )
        ).toEqual(true);

        expect(
            TsumDate(new Date())
                .isBefore(
                    TsumDate(new Date()).getPrevDay(),
                    'full',
                )
        ).toEqual(false);

        expect(
            TsumDate(new Date())
                .isBefore(
                    TsumDate(new Date()).getPrevMonth(),
                    'full',
                )
        ).toEqual(false);
    });

    it('should correct work isAfter monthAndDateAndYear calculate', () => {
        expect(
            TsumDate(new Date())
                .isBefore(
                    TsumDate(new Date()).getNextFullYear(),
                    'monthAndDateAndYear',
                )
        ).toEqual(true);

        expect(
            TsumDate(new Date())
                .isBefore(
                    TsumDate(new Date()).getNextDay(),
                    'monthAndDateAndYear',
                )
        ).toEqual(true);

        expect(
            TsumDate(new Date())
                .isBefore(
                    TsumDate(new Date()).getNextMonth(),
                    'monthAndDateAndYear',
                )
        ).toEqual(true);

        expect(
            TsumDate(new Date())
                .isBefore(
                    TsumDate(new Date()).getPrevFullYear(),
                    'monthAndDateAndYear',
                )
        ).toEqual(false);

        expect(
            TsumDate(new Date())
                .isBefore(
                    TsumDate(new Date()).getPrevDay(),
                    'monthAndDateAndYear',
                )
        ).toEqual(false);

        expect(
            TsumDate(new Date())
                .isBefore(
                    TsumDate(new Date()).getPrevMonth(),
                    'monthAndDateAndYear',
                )
        ).toEqual(false);
    });

    it('should correct work realMonthNumber', () => {
        const monthNumber = new Date().getMonth();
        const nextMonth = TsumDate().getNextMonth().getMonth();

        expect(TsumDate(new Date()).realMonthNumber).toEqual(monthNumber + 1);
        expect(TsumDate(new Date()).realMonthNumber).not.toEqual(monthNumber);
        expect(TsumDate().getNextMonth().getMonth()).toEqual(nextMonth);
        expect(TsumDate().getNextMonth().getMonth()).not.toEqual(nextMonth + 1);
    });

    it('should correct work completeDate', () => {
        const firstDate = TsumDate(TsumDate().getFirstDayByMonth());
        const lastDate = TsumDate(TsumDate().getLastDayByMonth());

        expect(firstDate.completeDate).toEqual('01');
        expect(lastDate.completeDate).not.toEqual(lastDate.completeDate[0] === '0');
    });

    it('should correct work format', () => {
        const timestamp = 1574868070936;

        expect(TsumDate(timestamp).format('dd/mm/yyyy')).toEqual('27/11/2019');
        expect(TsumDate(timestamp).format('mm/dd/yyyy')).toEqual('11/27/2019');
    });

    it('should correct work isSame', () => {
        const timestamp = 1574868070936;

        expect(TsumDate(timestamp).isSame(new Date(timestamp))).toEqual(true);
        expect(TsumDate(timestamp).isSame(TsumDate(timestamp).getNextMonth())).toEqual(false);

        expect(TsumDate(timestamp).isSame(new Date(timestamp), 'date')).toEqual(true);
        expect(TsumDate(timestamp).isSame(TsumDate(timestamp).getNextDay(), 'date')).toEqual(false);

        expect(TsumDate(timestamp).isSame(new Date(timestamp), 'year')).toEqual(true);
        expect(TsumDate(timestamp).isSame(TsumDate(timestamp).getNextFullYear(), 'year')).toEqual(false);

        expect(TsumDate(timestamp).isSame(new Date(timestamp), 'month')).toEqual(true);
        expect(TsumDate(timestamp).isSame(TsumDate(timestamp).getNextMonth(), 'month')).toEqual(false);

        expect(TsumDate(timestamp).isSame(new Date(timestamp), 'monthAndDate')).toEqual(true);
        expect(TsumDate(timestamp).isSame(TsumDate(timestamp).getNextMonth(), 'monthAndDate')).toEqual(false);

        expect(TsumDate(timestamp).isSame(new Date(timestamp), 'monthAndDateAndYear')).toEqual(true);
        expect(TsumDate(timestamp).isSame(TsumDate(timestamp).getNextMonth(), 'monthAndDateAndYear')).toEqual(false);

        expect(TsumDate(null).isSame(TsumDate(timestamp).getNextMonth(), 'monthAndDateAndYear')).toEqual(false);
        expect(TsumDate(null).isSame(TsumDate(timestamp).getNextMonth(), 'date')).toEqual(false);
        expect(TsumDate(null).isSame(TsumDate(timestamp).getNextMonth(), 'full')).toEqual(false);
    });

    it('should correct work isBetween', () => {
        const timestamp = 1574868070936;

        expect(TsumDate(timestamp).isBetween(
            TsumDate(timestamp).getPrevDay(),
            TsumDate(timestamp).getNextDay(),
        )).toEqual(true);

        expect(TsumDate(timestamp).isBetween(
            TsumDate(timestamp).getNextDay(),
            TsumDate(timestamp).getNextDay(2),
        )).toEqual(false);

        expect(TsumDate(timestamp).isBetween(
            TsumDate(timestamp).getPrevDay(),
            TsumDate(timestamp).getNextDay(),
            'monthAndDateAndYear',
        )).toEqual(true);

        expect(TsumDate(timestamp).isBetween(
            TsumDate(timestamp).getNextDay(),
            TsumDate(timestamp).getNextDay(2),
            'monthAndDateAndYear',
        )).toEqual(false);
    });

    it('should correct work getPrevFullYear', () => {
        const timestamp = 1574868070936;

        expect(TsumDate(timestamp).getPrevFullYear().getFullYear()).toEqual(2018);
        expect(TsumDate(timestamp).getPrevFullYear().getFullYear()).not.toEqual(2019);
    });

    it('should correct work getNextFullYear', () => {
        const timestamp = 1574868070936;

        expect(TsumDate(timestamp).getNextFullYear().getFullYear()).toEqual(2020);
        expect(TsumDate(timestamp).getNextFullYear().getFullYear()).not.toEqual(2019);
    });

    it('should correct work getFirstMonthByYear', () => {
        const timestamp = 1574868070936;

        expect(TsumDate(timestamp).getFirstMonthByYear().getMonth()).toEqual(0);
    });

    it('should correct work getYear', () => {
        const timestamp = 1574868070936;

        expect(TsumDate(timestamp).getYear()).toEqual(2019);
    });

    it('should correct work getNextMonth', () => {
        const timestamp = 1574868070936;

        expect(TsumDate(timestamp).getNextMonth().getMonth()).toEqual(11);
        expect(TsumDate(timestamp).getNextMonth(2).getMonth()).toEqual(0);
        expect(TsumDate(timestamp).getNextMonth(3).getMonth()).not.toEqual(0);
    });

    it('should correct work getPrevMonth', () => {
        const timestamp = 1574868070936;

        expect(TsumDate(timestamp).getPrevMonth().getMonth()).toEqual(9);
        expect(TsumDate(timestamp).getPrevMonth(2).getMonth()).toEqual(8);
        expect(TsumDate(timestamp).getPrevMonth(3).getMonth()).not.toEqual(8);
    });

    it('should correct work getFirstDayByMonth', () => {
        const timestamp = 1574868070936;

        expect(TsumDate(timestamp).getFirstDayByMonth().getDate()).toEqual(1);
        expect(TsumDate(timestamp).getFirstDayByMonth().getMonth()).toEqual(10);
    });

    it('should correct work getLastDayByMonth', () => {
        const timestamp = 1574868070936;

        expect(TsumDate(timestamp).getLastDayByMonth().getDate()).toEqual(30);
        expect(TsumDate(TsumDate(timestamp).getNextMonth()).getLastDayByMonth().getDate()).toEqual(31);
    });

    it('should correct work getMonthName', () => {
        const timestamp = 1574868070936;

        expect(TsumDate(timestamp).getMonthName()).toEqual('Ноябрь');
    });

    it('should correct work getMonthName with i18n', () => {
        const timestamp = 1574868070936;

        expect(TsumDate(timestamp).getMonthName(MONTH_NAMES)).toEqual('Nov');
    });

    it('should correct work getShortMonthName', () => {
        const timestamp = 1574868070936;

        expect(TsumDate(timestamp).getShortMonthName()).toEqual('Нояб');
    });

    it('should correct work getShortMonthName with i18n', () => {
        const timestamp = 1574868070936;

        expect(TsumDate(timestamp).getShortMonthName(MONTH_NAMES)).toEqual('Nov');
    });

    it('should correct work getNextDay', () => {
        const timestamp = 1574868070936;

        expect(TsumDate(timestamp).getNextDay().getDate()).toEqual(28);
        expect(TsumDate(timestamp).getNextDay(2).getDate()).toEqual(29);
    });

    it('should correct work getPrevDay', () => {
        const timestamp = 1574868070936;

        expect(TsumDate(timestamp).getPrevDay().getDate()).toEqual(26);
        expect(TsumDate(timestamp).getPrevDay(2).getDate()).toEqual(25);
    });

    it('should correct work getDayName', () => {
        const timestamp = 1574868070936;

        expect(TsumDate(timestamp).getDayName()).toEqual('Среда');
    });

    it('should correct work getDayName with i18n', () => {
        const timestamp = 1574868070936;

        expect(TsumDate(timestamp).getDayName(['1', '2', '3', '4', '5', '6', '7'])).toEqual('4');
    });

    it('should correct work getDate', () => {
        const timestamp = 1574868070936;

        expect(TsumDate(timestamp).getDate()).toEqual(27);
    });
});
