import { TsumIconHelper } from 'projects/utils/src';

export namespace TsumIcon {
    export enum Color {
        Primary = '#ed722d',
        Secondary = '#1b1b1b',
        Success = '#00ad17',
        Danger = '#d30000',
        Warning = '#ed722d',
        Info = '#3478b0',

        PrimaryActive = '#cb5411',
        Gray = '#dadce1',
        DarkGray = '#99a0ad',
        LightGray = '#fafafa',
        LightWhite = '#fefefe',
        White = '#ffffff',
        None = 'none',
    }

    export enum Arrows {
        Down = 'arrows-down',
        Up = 'arrows-up',
        Left = 'arrows-left',
        Right = 'arrows-right',
        ListDown = 'arrows-list-down',
        ListUp = 'arrows-list-up',
        ListLeft = 'arrows-list-left',
        ListRight = 'arrows-list-right',
        MoreDown = 'arrows-more-down',
        MoreUp = 'arrows-more-up',
        FlatRight = 'arrows-flat-arrow-right',
        ShiftLeft = 'arrows-shift-left',
        ShiftRight = 'arrows-shift-right',
        ShiftUp = 'arrows-shift-up',
        ShiftDown = 'arrows-shift-down',
    }

    export enum Actions {
        Close = 'actions-close',
        QuadrateAdd = 'actions-quadrate-add',
        Drag= 'actions-drag-normal',
        Edit = 'actions-edit',
        QuadrateDone = 'actions-quadrate-done',
        Add = 'actions-add',
        Settings = 'actions-settings',
        TrashBin = 'actions-trash-bin',
        Copy = 'actions-copy',
        Download = 'actions-download',
        Send = 'actions-send',
        Attach = 'actions-attach',
        Volume = 'actions-volume',
        CatalogOpen = 'actions-catalog-open',
        CatalogNormal = 'actions-catalog-normal',
        ViewTable = 'actions-view-table',
        ViewCards = 'actions-view-cards',
        Look = 'actions-look',
        Favorite = 'actions-favorite',
        EyeHidden = 'actions-eye-hidden',
        EyeShow = 'actions-eye-show',
        List = 'actions-list',
        Filter = 'actions-filter',
        Minus = 'actions-minus',
        MoreHorizontal = 'actions-more-horizontal',
        MoreVertical = 'actions-more-vertical',
        Email = 'actions-email',
        Password = 'actions-password',
        Done = 'actions-done',
        SidepanelDrag = 'actions-sidepanel-drag',
        ParentList = 'actions-parent-list',

        // Circle
        ScrollUp = 'actions-circle-scroll-up',
        CircleQuestion = 'actions-circle-question',
        CirclePrevious = 'actions-circle-previous',
        CircleDelete = 'actions-circle-delete',
        CircleAdd = 'actions-circle-add',
        CircleOnInfo = 'actions-circle-on-info',
        CircleMinus = 'actions-circle-minus',
        CircleDone = 'actions-circle-done',
    }

    export enum Notifications {
        Error = 'notification-error',
        Warning = 'notification-warning',
        Success = 'notification-success',
        Info = 'notification-info',
        TriangleWarning = 'notification-triangle-warning',
        TriangleError = 'notification-triangle-error',
        HollowError = 'notification-hollow-error',
        HollowWarning = 'notification-hollow-warning',
        HollowSuccess = 'notification-hollow-success',
        HollowInfo = 'notification-hollow-info',
    }

    export enum Indicators {
        Circle = 'indicator-circle',
    }

    export enum Navigation {
        Bag = 'navigation-bag',
        Calendar = 'navigation-calendar',
        Settings = 'navigation-settings',
        Geo = 'navigation-geo',
        Info = 'navigation-info',
        Search = 'navigation-search',
        Apps = 'navigation-apps',
        DefaultProfile = 'navigation-default-profile',
        Bell = 'navigation-bell',
        Card = 'navigation-card',
    }

    export enum Socials {
        Chat = 'social-chat',
        Facebook = 'social-facebook',
        Message = 'social-message',
        OneClass = 'social-one-class',
        Telegram = 'social-telegram',
        Phone = 'social-phone',
        Viber = 'social-viber',
        Vk = 'social-vk',
        WhatsApp = 'social-whatsapp',
    }
}

describe('Icon helper', () => {
    it('should correct get icons names from source', () => {
        const source: Record<string, any> = {
            FirstEnum: {
                IconName: 'icon1'
            },
            SecondEnum: {
                IconName: 'icon2'
            }
        };

        const result = TsumIconHelper.generateIconsCollection(source, []);
        const iconsList: string[] = Array.from(result.values());

        expect(result.size).toBe(2);
        expect(iconsList).toStrictEqual(['icon1', 'icon2']);
    });

    it('should correct drop discarded keys', () => {
        const discardedKey: string = 'Color';
        const source: Record<string, any> = {...TsumIcon};
        const sourceWithDiscard: Record<string, any> = {...source};

        delete sourceWithDiscard[discardedKey];

        const fromSource: Map<string, string> = TsumIconHelper.generateIconsCollection(source, [discardedKey]);
        const fromCuttedSource: Map<string, string> = TsumIconHelper.generateIconsCollection(sourceWithDiscard, []);

        expect(discardedKey in source).toBe(true);
        expect(fromSource.size).toBe(fromCuttedSource.size);
    });
});
