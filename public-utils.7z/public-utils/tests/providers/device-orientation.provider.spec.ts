import { TsumDeviceOrientation, TsumDeviceOrientationProviders } from 'projects/utils/src';

describe('TsumDeviceOrientation', () => {
    const matchMedia = window.matchMedia;

    afterEach(() => {
        jest.restoreAllMocks();

        delete (window as any).orientation;
        delete (screen as any).orientation;
        window.matchMedia = matchMedia;
    });

    it('by static value', () => {
        const orientation = TsumDeviceOrientation.Portrait;
        const provider = TsumDeviceOrientationProviders.createStaticProvider(orientation);

        expect(provider.get()).toBe(orientation);
    });

    it('by screen orientation', () => {
        const orientations: [string, TsumDeviceOrientation][] = [
            ['landscape-primary', TsumDeviceOrientation.Landscape],
            ['landscape-secondary', TsumDeviceOrientation.Landscape],
            ['portrait-primary', TsumDeviceOrientation.Portrait],
            ['portrait-secondary', TsumDeviceOrientation.Portrait],
            ['unknown', TsumDeviceOrientation.Landscape],
        ];
        let mocked = '';
        let expected;

        expect(typeof screen.orientation).toBe('undefined');

        Object.defineProperty(screen, 'orientation', {
            value: {
                get type() {
                    return mocked;
                }
            }
        });

        const provider = TsumDeviceOrientationProviders.createBrowserProvider();

        for ([mocked, expected] of orientations) {
            expect(provider.get()).toBe(expected);
        }
    });

    it('by window orientation', () => {
        const orientations: [number, TsumDeviceOrientation][] = [
            [0, TsumDeviceOrientation.Landscape],
            [180, TsumDeviceOrientation.Landscape],
            [90, TsumDeviceOrientation.Portrait],
            [-90, TsumDeviceOrientation.Portrait],
            [100500, TsumDeviceOrientation.Landscape],
        ];
        let mocked = 0;
        let expected;

        Object.defineProperty(window, 'orientation', {
            get() {
                return mocked;
            }
        });

        const provider = TsumDeviceOrientationProviders.createBrowserProvider();

        for ([mocked, expected] of orientations) {
            expect(provider.get()).toBe(expected);
        }
    });

    it('by match media', () => {
        const orientations: [string, TsumDeviceOrientation][] = [
            ['landscape', TsumDeviceOrientation.Landscape],
            ['portrait', TsumDeviceOrientation.Portrait],
            ['unknown', TsumDeviceOrientation.Landscape],
        ];
        let mocked = '';
        let expected;

        Object.defineProperty(window, 'matchMedia', {
            value: function fakeMatchMedia(query: string) {
                const match = query.match(/^\(orientation:\s*([a-z]+)\)$/);
                return {
                    matches: match === null ? false : match[1] === mocked,
                };
            }
        });

        const provider = TsumDeviceOrientationProviders.createBrowserProvider();

        for ([mocked, expected] of orientations) {
            expect(provider.get()).toBe(expected);
        }
    });

    it('by window size', () => {
        const orientations: [Partial<Window>, TsumDeviceOrientation][] = [
            [{innerWidth: 200, innerHeight: 100}, TsumDeviceOrientation.Landscape],
            [{innerWidth: 100, innerHeight: 200}, TsumDeviceOrientation.Portrait],
            [{innerWidth: 200, innerHeight: 200}, TsumDeviceOrientation.Landscape],
        ];
        let mocked: Partial<Window> = {};
        let expected;

        Object.defineProperties(window, {
            innerWidth: {
                get() {
                    return mocked.innerWidth;
                }
            },
            innerHeight: {
                get() {
                    return mocked.innerHeight;
                }
            },
        });

        const provider = TsumDeviceOrientationProviders.createBrowserProvider();

        for ([mocked, expected] of orientations) {
            expect(provider.get()).toBe(expected);
        }
    });
});
