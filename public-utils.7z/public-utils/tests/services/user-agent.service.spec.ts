import {
    TsumUserAgentService,
    TsumUserAgentOS,
    TsumUserAgentDevice,
    TsumUserAgentBrowser,
} from 'projects/utils/src';


interface TestCase {
    description: string;
    userAgent: string;
    expected: TestCaseExpectations;
}

interface TestCaseExpectations {
    os: TsumUserAgentOS;
    device: TsumUserAgentDevice;
    browser?: TsumUserAgentBrowser;
}

const LINUX_DESKTOP: TestCaseExpectations = {
    os: TsumUserAgentOS.Linux,
    device: TsumUserAgentDevice.Desktop,
};

const WINDOWS_DESKTOP: TestCaseExpectations = {
    os: TsumUserAgentOS.Windows,
    device: TsumUserAgentDevice.Desktop,
};

const MACOS_DESKTOP: TestCaseExpectations = {
    os: TsumUserAgentOS.MacOS,
    device: TsumUserAgentDevice.Desktop,
};

const IPHONE: TestCaseExpectations = {
    os: TsumUserAgentOS.iOS,
    device: TsumUserAgentDevice.Phone,
};

const ANDROID_PHONE: TestCaseExpectations = {
    os: TsumUserAgentOS.Android,
    device: TsumUserAgentDevice.Phone,
};

const IPAD: TestCaseExpectations = {
    os: TsumUserAgentOS.iOS,
    device: TsumUserAgentDevice.Tablet,
};

const ANDROID_TABLET: TestCaseExpectations = {
    os: TsumUserAgentOS.Android,
    device: TsumUserAgentDevice.Tablet,
};

// tslint:disable:max-line-length
const tests: TestCase[] = [
    //
    // DESKTOP
    {
        description: 'Desktop, Linux (Ubuntu 16.04), Opera 55',
        userAgent: 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36 OPR/55.0.2994.56',
        expected: {...LINUX_DESKTOP, browser: TsumUserAgentBrowser.Opera},
    },
    {
        description: 'Desktop, Linux, Opera 12',
        userAgent: 'Opera/9.80 (Linux armv7l) Presto/2.12.407 Version/12.51 , D50u-D1-UHD/V1.5.16-UHD (Vizio, D50u-D1, Wireless)',
        expected: {...LINUX_DESKTOP, browser: TsumUserAgentBrowser.Opera},
    },
    {
        description: 'Desktop, Windows, IE 11',
        userAgent: 'Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko',
        expected: {...WINDOWS_DESKTOP, browser: TsumUserAgentBrowser.IE},
    },
    {
        description: 'Desktop, Windows, IE 9',
        userAgent: 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)',
        expected: {...WINDOWS_DESKTOP, browser: TsumUserAgentBrowser.IE},
    },
    {
        description: 'Desktop, Windows, YandexBrowser',
        userAgent: 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 YaBrowser/18.3.1.1232 Yowser/2.5 Safari/537.36',
        expected: {...WINDOWS_DESKTOP, browser: TsumUserAgentBrowser.YandexBrowser},
    },
    {
        description: 'Desktop, Windows, Firefox',
        userAgent: 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0',
        expected: {...WINDOWS_DESKTOP, browser: TsumUserAgentBrowser.Firefox},
    },
    {
        description: 'Desktop, Windows, Edge',
        userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18362',
        expected: {...WINDOWS_DESKTOP, browser: TsumUserAgentBrowser.Edge},
    },
    {
        description: 'Desktop, MacOs, Safari',
        userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/12.1.1 Safari/605.1.15',
        expected: {...MACOS_DESKTOP, browser: TsumUserAgentBrowser.Safari},
    },

    //
    // PHONE
    {
        description: 'Iphone, CriOS',
        userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 10_3 like Mac OS X) AppleWebKit/602.1.50 (KHTML, like Gecko) CriOS/56.0.2924.75 Mobile/14E5239e Safari/602.1',
        expected: {...IPHONE, browser: TsumUserAgentBrowser.CriOS},
    },
    {
        description: 'Phone (iPhone X), iOS 11.0, Mobile Safari',
        userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1',
        expected: {...IPHONE, browser: TsumUserAgentBrowser.MobileSafari},
    },
    {
        description: 'Phone (iPod touch), iOS 9.2, Mobile Safari',
        userAgent: 'Mozilla/5.0 (iPod touch; CPU iPhone OS 9_2 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13C75 Safari/601.1',
        expected: {...IPHONE, browser: TsumUserAgentBrowser.MobileSafari},
    },
    {
        description: 'Phone (Samsung Galaxy S5 / SM-G900P), Android 5.0, Mobile Chrome 68',
        userAgent: 'Mozilla/5.0 (Linux; Android 5.0; SM-G900P Build/LRX21T) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Mobile Safari/537.36',
        expected: {...ANDROID_PHONE, browser: TsumUserAgentBrowser.Chrome},
    },
    {
        description: 'Phone (Samsung Galaxy S1 / SM-I9000), Android 2.1, Android Browser)',
        userAgent: 'Mozilla/5.0 (Linux; U; Android 2.1-update1; fr-fr; GT-I9000 Build/ECLAIR) AppleWebKit/530.17 (KHTML, like Gecko) Version/4.0 Mobile Safari/530.17',
        expected: {...ANDROID_PHONE, browser: TsumUserAgentBrowser.Android},
    },
    {
        description: 'Phone (Xiaomi MI A1), Android 8.1, Mobile Chrome 69',
        userAgent: 'Mozilla/5.0 (Linux; Android 8.1.0; Mi A1 Build/OPM1.171019.026) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36',
        expected: {...ANDROID_PHONE, browser: TsumUserAgentBrowser.Chrome},
    },
    {
        description: 'Phone (Xiaomi MI MAX 3), Android 8.1, Mobile Chrome 67',
        userAgent: 'Mozilla/5.0 (Linux; Android 8.1.0; MI MAX 3 Build/OPM1.171019.019) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.123 Mobile Safari/537.36 EdgA/42.0.0.2549',
        expected: {...ANDROID_PHONE, browser: TsumUserAgentBrowser.Chrome},
    },
    {
        description: 'Phone (Xiaomi Redmi 6 Pro), Android 8.1, Mobile Chrome 66',
        userAgent: 'Mozilla/5.0 (Linux; Android 8.1; Redmi 6 Pro Build/OPM1.171019.019) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.158 Mobile Safari/537.36',
        expected: {...ANDROID_PHONE, browser: TsumUserAgentBrowser.Chrome},
    },
    {
        description: 'Phone (Xiaomi Redmi / HM 1S), Android 4.4, UC Browser 9',
        userAgent: 'Mozilla/5.0 (Linux; U; Android 4.4.4; en-us; HM 1S Build/KTU84P) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/9.9.3.478 U3/0.8.0 Mobile Safari/534.30',
        expected: ANDROID_PHONE,
    },
    {
        description: 'Phone (Huawei P20 Pro / CLT-L29), Android 8.1, Mobile Chrome 65',
        userAgent: 'Mozilla/5.0 (Linux; Android 8.1; CLT-L29 Build/HUAWEICLT-L29) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.109 Mobile Safari/537.36',
        expected: {...ANDROID_PHONE, browser: TsumUserAgentBrowser.Chrome},
    },
    {
        description: 'Phone (ZTE Axon 7 Mini / B2017G), Android 6.0, Mobile Chrome 56',
        userAgent: 'Mozilla/5.0 (Linux; Android 6.0; ZTE B2017G Build/MMB29M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Mobile Safari/537.36',
        expected: {...ANDROID_PHONE, browser: TsumUserAgentBrowser.Chrome},
    },
    {
        description: 'Phone (Asus ZenFone 6 / ZS630KL I01WD), Android 9, Mobile Chrome 72',
        userAgent: 'User Agent: Mozilla/5.0 (Linux; Android 9; ASUS_I01WD) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Mobile Safari/537.36',
        expected: {...ANDROID_PHONE, browser: TsumUserAgentBrowser.Chrome},
    },
    {
        description: 'Phone (LG G8 ThinQ / LM-G820V), Android 9, Mobile Chrome 72',
        userAgent: 'Mozilla/5.0 (Linux; Android 9; LM-G820V) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.105 Mobile Safari/537.36',
        expected: {...ANDROID_PHONE, browser: TsumUserAgentBrowser.Chrome},
    },
    {
        description: 'Phone (Google Pixel 3 XL), Android 9, Mobile Chrome 68',
        userAgent: 'Mozilla/5.0 (Linux; Android 9; Pixel 3 XL Build/PD1A.180720.025) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.91 Mobile Safari/537.36 ',
        expected: {...ANDROID_PHONE, browser: TsumUserAgentBrowser.Chrome},
    },
    {
        description: 'Phone (Google nexus 6), Android 5.0, Mobile Chrome 37',
        userAgent: 'Mozilla/5.0 (Linux; Android 5.0; Nexus 6 Build/LRX21D) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/37.0.0.0 Mobile Safari/537.36',
        expected: {...ANDROID_PHONE, browser: TsumUserAgentBrowser.Chrome},
    },
    {
        description: 'Phone (OnePlus 6 / A6003), Android 9, Mobile Chrome 70',
        userAgent: 'Mozilla/5.0 (Linux; Android 9; ONEPLUS A6003) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Mobile Safari/537.36',
        expected: {...ANDROID_PHONE, browser: TsumUserAgentBrowser.Chrome},
    },

    //
    // TABLET
    {
        description: 'Tablet (iPad), iOS 11.0, Mobile Safari',
        userAgent: 'Mozilla/5.0 (iPad; CPU OS 11_0 like Mac OS X) AppleWebKit/604.1.34 (KHTML, like Gecko) Version/11.0 Mobile/15A5341f Safari/604.1',
        expected: {...IPAD, browser: TsumUserAgentBrowser.MobileSafari},
    },
    {
        description: 'Tablet (Samsung Galaxy Tab A 10.5 / SM-590), Android 8.1, Samsung Browser 9.2',
        userAgent: 'Mozilla/5.0 (Linux; Android 8.1.0; SAMSUNG SM-T590 Build/M1AJQ) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/9.2 Chrome/67.0.3396.87 Safari/537.36',
        expected: ANDROID_TABLET,
    },
    {
        description: 'Tablet (Xiaomi MI PAD 4), Android 8.1, Mobile Chrome 61',
        userAgent: 'Mozilla/5.0 (Linux; Android 8.1; MI PAD 4 Build/OPM1.171019.019) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/61.0.3163.128 Safari/537.36',
        expected: ANDROID_TABLET,
    },
    {
        description: 'Tablet (Huawei MediaPad M3 Lite 10), Android 7.0, Mobile Chrome 70',
        userAgent: 'Mozilla/5.0 (Linux; Android 7.0; BAH-L09) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.80 Safari/537.36',
        expected: ANDROID_TABLET,
    },
    {
        description: 'Tablet (Asus ZenPad 10 / P021), Android 5.0, Mobile Chrome 43',
        userAgent: 'Mozilla/5.0 (Linux; Android 5.0; P021 Build/LRX22G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.93 Safari/537.36',
        expected: ANDROID_TABLET,
    },
    {
        description: 'Tablet (LG G Pad 8.3 LTE / VK810), Android 4.4, Mobile Chrome 47',
        userAgent: 'Mozilla/5.0 (Linux; Android 4.4.2; VK810 4G Build/KOT49I.VK81024A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.83 Safari/537.36',
        expected: ANDROID_TABLET,
    },
    {
        description: 'Tablet (Google Pixel C), Android 8.0, Mobile Chrome 60',
        userAgent: 'Mozilla/5.0 (Linux; Android 8.0.0; Pixel C Build/OPR1.170623.026) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.116 Safari/537.36',
        expected: ANDROID_TABLET,
    },
];
// tslint:enable:max-line-length


describe('TsumUserAgentService', () => {
    tests.forEach(test => {
        it(test.description, () => {
            const service = new TsumUserAgentService({get: () => test.userAgent});

            expect(service.os.value).toBe(test.expected.os);
            expect(service.device.value).toBe(test.expected.device);

            if ('browser' in test.expected) {
                expect(service.browser.value).toBe(test.expected.browser);
            }
        });
    });
});
