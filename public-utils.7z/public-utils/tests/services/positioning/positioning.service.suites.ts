import { TsumPositioningServiceNamespace } from './positioning.service.namespace';

import MockedWindow = TsumPositioningServiceNamespace.MockedWindow;
import AMPLE_SPACE = TsumPositioningServiceNamespace.AMPLE_SPACE;
import TOOLTIP_WIDTH = TsumPositioningServiceNamespace.TOOLTIP_WIDTH;
import TOOLTIP_HEIGHT = TsumPositioningServiceNamespace.TOOLTIP_HEIGHT;
import TOOLTIP_SOURCE_WIDTH = TsumPositioningServiceNamespace.TOOLTIP_SOURCE_WIDTH;
import TOOLTIP_SOURCE_HEIGHT = TsumPositioningServiceNamespace.TOOLTIP_SOURCE_HEIGHT;
import TOOLTIP_SOURCE_ID = TsumPositioningServiceNamespace.TOOLTIP_SOURCE_ID;
import TOOLTIP_ID = TsumPositioningServiceNamespace.TOOLTIP_ID;
import CONTAINER_ID = TsumPositioningServiceNamespace.CONTAINER_ID;
import INSUFFICIENT_SPACE = TsumPositioningServiceNamespace.INSUFFICIENT_SPACE;
import TOOLTIP_OFFSET = TsumPositioningServiceNamespace.TOOLTIP_OFFSET;
import { TsumPositioning } from '../../../projects/utils/src/lib/services/positioning/positioning.namespace';

declare var jest: any;

/**
 * Приватные функции для работы внутри модуля
 */

// Создает нужный HTML для тестирования
const create = (mockedWindow: MockedWindow): void => {
    // создание тэгов
    const container: HTMLDivElement = document.createElement('div');
    const tooltipSource: HTMLButtonElement = document.createElement('button');
    const tooltip: HTMLDivElement = document.createElement('div');

    const defaultRect: ClientRect = {
        left: 0,
        right: 0,
        bottom: 0,
        top: 0,
        width: 0,
        height: 0,
    };

    // добавление уникальных идентификаторов
    tooltipSource.id = TOOLTIP_SOURCE_ID;
    tooltip.id = TOOLTIP_ID;
    container.id = CONTAINER_ID;

    // добавление размеров
    tooltipSource.getBoundingClientRect = () => (({
        ...defaultRect,
        height: TOOLTIP_SOURCE_HEIGHT,
        width: TOOLTIP_SOURCE_WIDTH,

    }) as any);

    tooltip.getBoundingClientRect = () => (({
        ...defaultRect,
        height: TOOLTIP_HEIGHT,
        width: TOOLTIP_WIDTH,
    }) as any);

    // помещение в DOM
    mockedWindow.document.body.appendChild(container);

    container.appendChild(tooltipSource);
    container.appendChild(tooltip);
};

/**
 * Публичные функции для запуска в тестах
 */

// Получить ссылку на тултип и другие данные
export const getTooltip = (window: MockedWindow): HTMLElement => window.document.getElementById(TOOLTIP_ID);
export const getTooltipRect = (window: MockedWindow): ClientRect => {
    return window.document.getElementById(TOOLTIP_ID).getBoundingClientRect();
};

// Получить ссылку на опорный элемент
export const getTooltipSource = (window: MockedWindow): HTMLElement => window.document.getElementById(TOOLTIP_SOURCE_ID);
export const getTooltipSourceRect = (window: MockedWindow): ClientRect => {
    return window.document.getElementById(TOOLTIP_SOURCE_ID).getBoundingClientRect();
};

// Создание тултипа с гарантированно СВОБОДНЫМ местом с любой стороны
export const createFreeAllSides = (mockedWindow: MockedWindow): void => {
    create(mockedWindow);

    const tooltip: HTMLElement = getTooltip(mockedWindow);
    const tooltipRect = getTooltipRect(mockedWindow);

    const tooltipSource: HTMLElement = getTooltipSource(mockedWindow);
    const tooltipSourceRect = getTooltipSourceRect(mockedWindow);

    // Установка таких размеров экрана, чтобы тултип в центре мог быть выровнен в любую сторону
    mockedWindow.innerWidth = 2 * AMPLE_SPACE;
    mockedWindow.innerHeight = 2 * AMPLE_SPACE;

    // Установка опорного элемента и тултипа в центре экрана
    tooltip.getBoundingClientRect = () => (({
        ...tooltipRect,
        left: AMPLE_SPACE,
        top: AMPLE_SPACE,
        right: AMPLE_SPACE,
        bottom: AMPLE_SPACE,
    }) as any);
    tooltipSource.getBoundingClientRect = () => (({
        ...tooltipSourceRect,
        left: AMPLE_SPACE,
        top: AMPLE_SPACE,
        right: AMPLE_SPACE,
        bottom: AMPLE_SPACE,
    }) as any);
};

// Создание тултипов с гарантированно НЕСВОБОДНЫМ местом с любой стороны
export const createNotFreeAllSides = (mockedWindow: MockedWindow): void => {
    create(mockedWindow);

    // Установка таких размеров экрана, чтобы тултип нигде не мог быть выровнен
    mockedWindow.innerWidth = INSUFFICIENT_SPACE;
    mockedWindow.innerHeight = INSUFFICIENT_SPACE;
};

// Очищение DOM
export const clear = (mockedWindow: MockedWindow): void => {
    const container: HTMLElement = mockedWindow.document.getElementById(CONTAINER_ID);

    container.remove();
};

// Удаление свободного места справа
export const clearRight = (mockedWindow: MockedWindow): void => {
    mockedWindow.innerWidth = 0;
};

// Удаление свободного места сверху
export const clearTop = (mockedWindow: MockedWindow): void => {
    const tooltipSource: HTMLElement = getTooltipSource(mockedWindow);
    const cuttedBottomClientRect: ClientRect = tooltipSource.getBoundingClientRect();

    tooltipSource.getBoundingClientRect = () => (({
        ...cuttedBottomClientRect,
        top: 0,
    }) as any);
};

// Удаление свободного места снизу
export const clearBottom = (mockedWindow: MockedWindow): void => {
    mockedWindow.innerHeight = INSUFFICIENT_SPACE;
};

// Создание базового объекта PositionData с предпочтительной позицией
export const createPositionData = (
        mockedWindow: MockedWindow,
        preferablePositions: TsumPositioning.Direction[]
    ): TsumPositioning.PositionSetup => {
    return {
        popup: getTooltip(mockedWindow),
        parent: getTooltipSource(mockedWindow),
        offset: TOOLTIP_OFFSET,
        borderRadius: 0,
        arrowWidth: 0,
        preferablePositions,
        after: jest.fn((direction: TsumPositioning.Direction) => { }),
    };
};
