export namespace TsumPositioningServiceNamespace {
    /**
     * @description задача эмулировать поведение экрана в тестовой среде
     */
    export class MockedWindow extends Window {
        private width: number = 0;
        private height: number = 0;

        public get innerWidth(): number {
            return this.width;
        }

        public set innerWidth(resizedWidth: number) {
            this.width = resizedWidth;
            this.dispatchEvent(new Event('resize'));
        }

        public get innerHeight(): number {
            return this.height;
        }

        public set innerHeight(resizedHeight: number) {
            this.height = resizedHeight;
            this.dispatchEvent(new Event('resize'));
        }

        constructor(options) {
            // @ts-ignore
            super(options);
        }
    }

    export type HasPlace = (tooltipRect: ClientRect, parentRect: ClientRect, offset: number) => boolean;

    // Расстояние для стороны при котором для подсказки гарантированно БУДЕТ СВОБОДНОЕ место
    export const AMPLE_SPACE = 1000;

    // Расстояние для стороны при котором для подсказки гарантированно НЕ БУДЕТ СВОБОДНОГО места
    export const INSUFFICIENT_SPACE = 10;

    // Отступ между опорным элементом и тултипом
    export const TOOLTIP_OFFSET = 10;

    // длина тултипа
    export const TOOLTIP_WIDTH = 300;
    // высота тултипа
    export const TOOLTIP_HEIGHT = 300;

    // длина опорного элемента
    export const TOOLTIP_SOURCE_WIDTH = 80;
    // высота опорного элемента
    export const TOOLTIP_SOURCE_HEIGHT = 36;

    // Id опорного элемента
    export const TOOLTIP_SOURCE_ID = 'TooltipSource';
    // Id тултипа
    export const TOOLTIP_ID = 'Tooltip';
    // Id контейнера
    export const CONTAINER_ID = 'Container';
}
