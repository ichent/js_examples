
import { TsumPositioningServiceNamespace } from './positioning.service.namespace';

import MockedWindow = TsumPositioningServiceNamespace.MockedWindow;

import HasPlace = TsumPositioningServiceNamespace.HasPlace;
import TOOLTIP_OFFSET = TsumPositioningServiceNamespace.TOOLTIP_OFFSET;
import {
    clear,
    createFreeAllSides,
    getTooltip,
    getTooltipRect,
    getTooltipSourceRect,
    createNotFreeAllSides,
    createPositionData,
    clearBottom,
    clearTop,
    clearRight
} from './positioning.service.suites';
import { TsumPositioning } from '../../../projects/utils/src/lib/services/positioning/positioning.namespace';
import { TsumPositioningService } from '../../../projects/utils/src/lib/services/positioning/positioning.service';

declare let window: MockedWindow;
// подмена оригинального конструкторв Window на моковый с целью получить возможность менять readonly свойства
Object.defineProperty(global, 'Window', {value: MockedWindow});

describe('TsumUtilsPositioning', () => {
    let serviceExample: TsumPositioningService;
    let hasPlaceInBottom: HasPlace;
    let hasPlaceInTop: HasPlace;
    let hasPlaceInRight: HasPlace;
    let hasPlaceInLeft: HasPlace;
    let testAllPlaces: (tooltipRect: ClientRect, tooltipSourceRect: ClientRect, supposedResult: boolean) => void;

    beforeEach(() => {
        const directionAdjustment = TsumPositioning.DIRECTION_ADJUSTMENT;
        serviceExample = new TsumPositioningService();;

        hasPlaceInBottom = jest.fn(directionAdjustment['bottom']);
        hasPlaceInTop = jest.fn(directionAdjustment['top']);
        hasPlaceInRight = jest.fn(directionAdjustment['right']);
        hasPlaceInLeft = jest.fn(directionAdjustment['left']);

        testAllPlaces = (tooltipRect: ClientRect, tooltipSourceRect: ClientRect, supposedResult: boolean) => {
            expect(hasPlaceInBottom(tooltipRect, tooltipSourceRect, TOOLTIP_OFFSET)).toEqual(supposedResult);
            expect(hasPlaceInTop(tooltipRect, tooltipSourceRect, TOOLTIP_OFFSET)).toEqual(supposedResult);
            expect(hasPlaceInRight(tooltipRect, tooltipSourceRect, TOOLTIP_OFFSET)).toEqual(supposedResult);
            expect(hasPlaceInLeft(tooltipRect, tooltipSourceRect, TOOLTIP_OFFSET)).toEqual(supposedResult);
        };
    });

    afterEach(() => {
        serviceExample = null;

        jest.restoreAllMocks();

        clear(window);
    });

    it('should have free space from all sides', () => {
        createFreeAllSides(window);

        const tooltip: HTMLElement = getTooltip(window);
        const tooltipRect: ClientRect = getTooltipRect(window);

        const tooltipSourceRect: ClientRect = getTooltipSourceRect(window);

        expect(tooltip).not.toBeNull();
        testAllPlaces(tooltipRect, tooltipSourceRect, true);
    });

    it('should have no free space from all sides', () => {
        createNotFreeAllSides(window);

        const tooltip: HTMLElement = getTooltip(window);
        const tooltipRect: ClientRect = getTooltipRect(window);

        const tooltipSourceRect: ClientRect = getTooltipSourceRect(window);

        expect(tooltip).not.toBeNull();
        testAllPlaces(tooltipRect, tooltipSourceRect, false);
    });

    it('should align by preferable position if has free place', () => {
        createFreeAllSides(window);

        const positionData: TsumPositioning.PositionSetup = createPositionData(window, [TsumPositioning.Direction.Bottom]);

        serviceExample.positioning(positionData);

        expect(positionData.after).toHaveBeenCalled();
        expect(positionData.after).toHaveBeenCalledWith('bottom');
    });

    it('should change position after resize if has no free place', () => {
        createFreeAllSides(window);

        const positionData: TsumPositioning.PositionSetup = createPositionData(window, [TsumPositioning.Direction.Bottom]);

        clearBottom(window);
        serviceExample.positioning(positionData);

        expect(positionData.after).toHaveBeenLastCalledWith('top');

        clearTop(window);
        serviceExample.positioning(positionData);

        expect(positionData.after).toHaveBeenLastCalledWith('right');

        clearRight(window);
        serviceExample.positioning(positionData);

        expect(positionData.after).toHaveBeenLastCalledWith('left');
    });

    it('should throw error id position invalid', () => {
        const invalidPosition: TsumPositioning.Direction = 'INVALID' as any;

        createFreeAllSides(window);

        const positionData: TsumPositioning.PositionSetup = createPositionData(window, [invalidPosition]);

        const test = (): void => {
            serviceExample.positioning(positionData);
        };

        expect(test).toThrow(Error);
    });
});
