import { TsumDummyBrowserEventsService } from 'projects/utils/src/lib/services/browser-event/dummy-browser-events.service';
import { isEmpty } from 'rxjs/operators';

describe('TsumBrowserEventsService', () => {
    let service: TsumDummyBrowserEventsService;

    beforeEach(() => {
        service = new TsumDummyBrowserEventsService();
    });

    it('resized', done => {
        service.resize$.pipe(isEmpty()).subscribe(x => {
            expect(x).toBeTruthy();
            done();
        });
    });

    it('delay Resized', done => {
        service.delayResize$.pipe(isEmpty()).subscribe(x => {
            expect(x).toBeTruthy();
            done();
        });
    });

    it('scrolled', done => {
        service.scroll$.pipe(isEmpty()).subscribe(x => {
            expect(x).toBeTruthy();
            done();
        });
    });

    it('delay Scrolled', done => {
        service.delayScroll$.pipe(isEmpty()).subscribe(x=> {
            expect(x).toBeTruthy();
            done();
        });
    });
});
