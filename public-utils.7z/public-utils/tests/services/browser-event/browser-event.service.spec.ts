import { TsumBrowserEventsService } from 'projects/utils/src/lib/services/browser-event/browser-events.service';
import { fakeAsync, tick } from '@angular/core/testing';

function resized(window: Window,  height: number): void {
    Object.defineProperty(window, 'innerHeight', {value: height});
    window.dispatchEvent(new Event('resize'));
}

function scrolled(window: Window): void {
    Object.defineProperty(window, 'scroll', { value:{ x: 10, y: 12 }, writable: true });
    window.dispatchEvent(new Event('scroll'));
}

describe('TsumBrowserEventsService', () => {
    const DELAY_TIME = 10;
    let service: TsumBrowserEventsService;

    beforeEach(() => {
        service = new TsumBrowserEventsService(DELAY_TIME);
    });

    it('resized', done => {
        service.resize$.subscribe(x => {
            expect(x).toBeTruthy();
            done();
        });
        resized(window, 10);

    });

    it('delay Resized', fakeAsync(() => {
        let actuallyDone = false;

        service.delayResize$.subscribe(() => {
            actuallyDone = true;
        });
        resized(window, 10);
        tick(DELAY_TIME);
        expect(actuallyDone).toEqual(true);
    }));

    it('scrolled', done => {
        service.scroll$.subscribe(x => {
            expect(x).toBeTruthy();
            done();
        });
        scrolled(window);
    });

    it('delay Scrolled', fakeAsync(() => {
        let actuallyDone = false;

        service.delayScroll$.subscribe(() => {
            actuallyDone = true;
        });
        scrolled(window);
        tick(DELAY_TIME);
        expect(actuallyDone).toEqual(true);
    }));

});
