import { configure, addParameters, addDecorator, moduleMetadata } from '@storybook/angular';
import { AppModule } from '../src/app/app.module';

import '!style-loader!css-loader!stylus-loader!../src/styles.styl';

addParameters({
    options: {
        theme: {
            brandTitle: 'Tsum Utils',
        },
        enableShortcuts: false,
        storySort: (a, b) => a[1].kind === b[1].kind ? 0 : a[1].id.localeCompare(b[1].id, { numeric: true }),
    },
});

addDecorator(
    moduleMetadata({
        imports: [
            AppModule,
        ],
    })
);

// automatically import all files ending in *.stories.ts
configure(require.context('../src/stories', true, /\.stories\.ts$/), module);
