const path = require('path');
const CopyPlugin = require('copy-webpack-plugin');

module.exports = async ({ config, mode }) => {
    config.module.rules.push({
        test: /\.styl$/,
        use: [
            {
                loader: "style-loader" // creates style nodes from JS strings
            },
            {
                loader: "css-loader" // translates CSS into CommonJS
            },
            {
                loader: "stylus-loader" // compiles Stylus to CSS
            }
        ],
        include: [
            path.resolve(__dirname, "../../src/stories"),
            path.resolve(__dirname, "../../src"),
        ]
    });

    config.plugins = [...config.plugins, ...[
        new CopyPlugin({
            patterns: [
                {
                    from: 'src/stories/**/*.component.ts',
                    to: 'examples/',
                    flatten: true,
                },
                {
                    from: 'src/stories/**/*.example.ts',
                    to: 'examples/',
                    flatten: true,
                },
                {
                    from: 'src/stories/**/*.directive.ts',
                    to: 'examples/',
                    flatten: true,
                },
                {
                    from: 'src/stories/**/*.module.ts',
                    to: 'examples/',
                    flatten: true,
                },
            ],
        }),
    ]];

    config.optimization.minimize = false;
    config.optimization.minimizer = [];

    return config;
};
