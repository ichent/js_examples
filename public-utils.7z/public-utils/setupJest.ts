import 'jest-preset-angular';

// Mock for document.execCommand
Object.defineProperty(document, 'execCommand', {
    value: () => {},
});

Object.defineProperty(window, 'DragEvent', {
    value: class DragEvent {}
});
